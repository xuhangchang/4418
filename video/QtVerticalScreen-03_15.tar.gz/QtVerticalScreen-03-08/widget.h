#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include <QLabel>
#include <QMutex>
#include <QTimer>
#include <QFile>
#include <QMessageBox>
#include <QDateTimeEdit>
#include <QGraphicsScene>
#include <QGraphicsView>
#include <QGraphicsProxyWidget>
#include <QTableWidgetItem>

#include <QSettings>

#include "thread.h"
#include "syszuxim.h"
#include "syszuxpinyin.h"
#include "tg_camera.h"


namespace Ui {
class Widget;
}

class Widget : public QWidget
{
    Q_OBJECT

public:
    explicit Widget(QWidget *parent = 0);
    ~Widget();
    //定时器
    QTimer * display_timer;

    QString dateString;
    QString weekString;
    QString timeString;
    QMap<QString,QString> map;


//成员信息显示界面:查询时无用户信息提示框
    QMessageBox * tip_query;
//用于使消息框3s后消失定时
    QTimer * tipTimer;
//更改用户成功或失败状态提示框
    QMessageBox * tip_ModifyFail;
//    QMessageBox * tip_ModifySucc;
//删除用户成功或失败状态提示框
    QMessageBox * tip_DeleteFail;
//要删除的用户ID
    QString deleteUser;
//成员信息显示界面(modify_msg.cpp)选中的items数目
    int count;
//表格相关的类
    QList<QTableWidgetItem*> items;
    QTableWidgetItem* item;

//输入法
    SyszuxIM *im;

//接收线程
    RecvPthread *recvThread;
//注册线程
    RegisterThread *registerThread;
//验证线程
    CompareThread *compareThread;

private slots:



//界面显示指静脉图片
    void picture_show(QString pic);

    void show_video(const QImage &img);


    void on_captureButton_clicked();

private:
    Ui::Widget *ui;

};

#endif // WIDGET_H

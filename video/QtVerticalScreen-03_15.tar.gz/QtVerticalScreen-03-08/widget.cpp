
/*************************************************************************
 * creator      : @xu
 * Total function:有些操作，只有管理员有权进行操作比如，
 *                查看已注册的用户，查找删除用户操作
 *
 * Date         : 2017/09/19
**************************************************************************/
#include "ui_widget.h"
#include "widget.h"
#include "General.h"


Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);
//隐藏界面上边框
    this->setWindowFlags(Qt::FramelessWindowHint);

    setAttribute(Qt::WA_AcceptTouchEvents);

//密码格式显示
    ui->SuperuserPsw_Input->setEchoMode(QLineEdit::Password);
//按钮按下或抬起背景色设置
    QString StyleBtn = "QPushButton{background-color:rgb(64, 115, 255);color: white;}"
                       "QPushButton:pressed{background-color:rgb(170, 162, 255);color:white;}";

//    ui->menuBtn->setStyleSheet("QPushButton{background-color:black;color: white;}"
//                               "QPushButton:hover{background-color:white; color: black;}"
//                               "QPushButton:pressed{background-color:rgb(85, 170, 255);color:white;}"
//                               );
    //主界面按钮

    ui->menuBtn->setStyleSheet(StyleBtn);
    ui->setBtn->setStyleSheet(StyleBtn);
    ui->pswBtn->setStyleSheet(StyleBtn);
    ui->dellBtn->setStyleSheet(StyleBtn);
    //
    ui->userManageBtn->setStyleSheet(StyleBtn);
    ui->AttendCheckBtn->setStyleSheet(StyleBtn);
    ui->sysInformationBtn->setStyleSheet(StyleBtn);
    ui->newFingerBtn->setStyleSheet(StyleBtn);
    ui->FindUserBtn->setStyleSheet(StyleBtn);

//设置界面
    ui->communcationSet->setStyleSheet(StyleBtn);
    ui->TimeSet->setStyleSheet(StyleBtn);
    ui->logFind->setStyleSheet(StyleBtn);

    ui->IPSetBtn->setStyleSheet(StyleBtn);
    ui->UartSetBtn->setStyleSheet(StyleBtn);
    ui->DetailBtn->setStyleSheet(StyleBtn);

//IP设置界面
    ui->IPsetOkBtn->setStyleSheet(StyleBtn);
    ui->LogQueryBtn->setStyleSheet(StyleBtn);
//表格宽度根据内容自动调节
//    ui->table->horizontalHeader()->setStretchLastSection(true);
//根据内容自动调整某列的列宽
//    ui->table->resizeColumnToContents(0);
//根据内容自动调整某列的列宽
//    ui->table->horizontalHeader()->setResizeMode(0,QHeaderView::ResizeToContents);
//    ui->table->horizontalHeader()->setResizeMode(1,QHeaderView::Stretch);
    ui->table->verticalHeader()->hide();
//关闭表格水平滚动条
    ui->table->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
//表格内容设置为整行选中
    ui->table->setSelectionBehavior(QAbstractItemView::SelectRows);//设置选择行为，以行为单位
    ui->table->setSelectionMode(QAbstractItemView::SingleSelection); //设置选择模式，选择单行

//输入法(软键盘)
//    im = new SyszuxIM();
//    QWSServer::setCurrentInputMethod(im);

//接收数据线程
    recvThread = new RecvPthread();
    recvThread->start();
//注册线程
    registerThread = new RegisterThread();

//验证线程
    compareThread = new CompareThread();
    compareThread->start();

//注册指静脉图片显示
    connect(registerThread,SIGNAL(picture_update(QString)),this,SLOT(picture_show(QString)));

//验证指静脉图片显示
    connect(compareThread,SIGNAL(picture_update(QString)),this,SLOT(picture_show(QString)));

    connect(compareThread,SIGNAL(video_update(const QImage &)),this,SLOT(show_video(const QImage &)));

//    connect(this,SIGNAL(ui->captureButton->click()),compareThread,SLOT(show_video(const QImage &)));


}





/*******************************************
 * creator      : @xu
 * function     : 指静脉图片显示到界面
 * Date         : 2017/06/12
 * parameter    : 无
********************************************/
void Widget::picture_show(QString pic)
{
    QPixmap fingerBmp,bmp;
    fingerBmp.load(pic);
    bmp=fingerBmp.scaled(640,480);
 //      bmp=fingerBmp.scaled(200,100);
 //   bmp=fingerBmp.scaled(800,600);
    //ui->FingerMap->move(330,210);

    QMatrix leftmatrix;
    leftmatrix.rotate(90);
    ui->FingerMap->setPixmap(bmp.transformed(leftmatrix,Qt::SmoothTransformation));
}



void Widget::show_video(const QImage &img)
{
    QMatrix leftmatrix;
    leftmatrix.rotate(90);
//     ui->FingerMap->setPixmap(QPixmap::fromImage(img));
    ui->FingerMap->setPixmap((QPixmap::fromImage(img)).transformed(leftmatrix,Qt::SmoothTransformation));
}


Widget::~Widget()
{

}



void Widget::on_captureButton_clicked()
{
    compareThread->capture_flag = 1;
}

#ifndef DATABASE_H
#define DATABASE_H

#include <QTextCodec>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QTime>
#include <QSqlError>
#include <QtDebug>
#include <QSqlDriver>
#include <QSqlRecord>
#include <QTextCodec>
#include <QDebug>
#include <QString>
/************************************************
 * 数据库VeinDB:
 * 存储已注册的所有用户信息+指静脉特征点
 ************************************************/
class VeinDB
{
public:
    VeinDB();
    ~VeinDB();
//创建一个连接
    bool createConnection();
//创建数据库列表
    bool createTable();
 //向数据库表中插入用户信息
    bool insertByte(int work_num,QString str_name,QString str_department,QString str_authority,int password,QByteArray veinData);
    bool insertUchar(int work_num,QString str_name,QString str_department,QString str_authority,int password,unsigned char* veinData);

//得到数据库中用户个数
    bool get_usersNum(int * usersNum);
//查询所有信息
    bool queryAll();
//查询待注册的用户ID是否与数据库已注册的用户ID重复
    int queryId(QString ID);
//遍历数据库中所有用户，查询管理员
    int queryRoot(int userloc);
//获取已注册成功用户，数据库存入的所有用户的指静脉特征点
    bool getAllData(unsigned char * UcharBuf);
//根据用户工号，更新用户信息（未包含用户指静脉特征点更新）
    bool updateEssentialMsg(int work_num,QString str_name,QString str_department,QString str_authority,int password);
//根据用户工号，更新用户信息（包括用户指静脉特征点的更新）
    bool updateData_Byte(int work_num,QString str_name,QString str_department,QString str_authority,int password,QByteArray veinData);
    bool updateData_Uchar(int work_num,QString str_name,QString str_department,QString str_authority,int password,unsigned char* veinData);

//根据用户工号,删除已注册用户
    bool deleteById(int id);
//排序(待定)
    bool sortById();

private:
    //连接名
    QString connName;
    //数据库名
    QString DBName;
    QSqlDatabase* db;
    QSqlQuery* query;
};

class AttendanceDB{
public:
    AttendanceDB();
    ~AttendanceDB();
//创建一个连接
    bool createConnection();

private:
    QString connName;
    QString DBName;
    QSqlDatabase* db;
    QSqlQuery* query;
};



#endif // DATABASE_H

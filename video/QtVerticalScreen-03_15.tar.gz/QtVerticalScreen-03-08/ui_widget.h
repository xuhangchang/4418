/********************************************************************************
** Form generated from reading UI file 'widget.ui'
**
** Created by: Qt User Interface Compiler version 4.8.7
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_WIDGET_H
#define UI_WIDGET_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QGroupBox>
#include <QtGui/QHBoxLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QPushButton>
#include <QtGui/QRadioButton>
#include <QtGui/QStackedWidget>
#include <QtGui/QTableWidget>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Widget
{
public:
    QWidget *backWidget;
    QStackedWidget *stackedwidget;
    QWidget *mainPage;
    QPushButton *dellBtn;
    QPushButton *pswBtn;
    QPushButton *setBtn;
    QPushButton *menuBtn;
    QLabel *weekLabel;
    QLabel *dateLabel;
    QLabel *timeLabel;
    QLabel *logoLabel;
    QLabel *TitleCLabel;
    QLabel *CStatus;
    QWidget *menuPage;
    QPushButton *userManageBtn;
    QPushButton *menuRetBtn;
    QPushButton *sysInformationBtn;
    QLabel *MenuLabel;
    QPushButton *LogQueryBtn;
    QPushButton *AttendCheckBtn;
    QWidget *userManagePage;
    QPushButton *newFingerBtn;
    QPushButton *userManageRetBtn;
    QPushButton *FindUserBtn;
    QLabel *UMLabel;
    QWidget *registerPage;
    QLabel *FingerMap;
    QLabel *TitleRLabel;
    QLabel *pswLabel;
    QLabel *authorityLabel;
    QLabel *departLabel;
    QLabel *nameLabel;
    QLabel *workNumLabel;
    QPushButton *newFingerRetBtn;
    QPushButton *captureButton;
    QWidget *showTable_page;
    QLineEdit *InputQuery;
    QPushButton *showTableRetBtn;
    QTableWidget *table;
    QLabel *FindLabel;
    QPushButton *DetailBtn;
    QWidget *SuperUser_page;
    QGroupBox *groupBox;
    QLabel *SuperUserstatusLabel;
    QGroupBox *groupBox_3;
    QLineEdit *SuperuserPsw_Input;
    QWidget *Set_page;
    QPushButton *set_retBtn;
    QPushButton *communcationSet;
    QPushButton *logFind;
    QLabel *SetLabel;
    QPushButton *TimeSet;
    QWidget *ComunicateSet_page;
    QPushButton *IPSetBtn;
    QPushButton *UartSetBtn;
    QPushButton *CommuSet_retBtn;
    QLabel *ComunateSetLabel;
    QWidget *page;
    QLabel *TimeSetLabel;
    QPushButton *TimeSet_ret;
    QLabel *DateSetLabel;
    QLabel *SetTimeLabel;
    QPushButton *DateSetBtn;
    QPushButton *TimeSetBtn;
    QWidget *IPSet_page;
    QGroupBox *groupBox_2;
    QRadioButton *deviceIPBtn;
    QRadioButton *serverIPBtn;
    QPushButton *IPsetOkBtn;
    QWidget *layoutWidget;
    QHBoxLayout *horizontalLayout_9;
    QLabel *IPInputlabel;
    QLineEdit *IPInputEdit;
    QPushButton *setIP_retBtn;
    QLabel *IpSetLabel;
    QWidget *DeviceInfor_page;
    QPushButton *DeviceInfor_retBtn;
    QLabel *IDNumberlabel2;
    QLabel *IDNumberlabel;
    QLabel *FWNumberlabel2;
    QLabel *FWNumberlabel;
    QLabel *SNNumberlabel2;
    QLabel *SNNumberlabel;
    QLabel *DeviceNamelabel2;
    QLabel *DeviceNamelabel;
    QWidget *page_2;
    QPushButton *Date_RetBtn;
    QLabel *Datetips;
    QPushButton *YearUpArrow;
    QPushButton *YearDArrow;
    QPushButton *monthUpArrow;
    QPushButton *monthDArrow;
    QPushButton *dateUpArrow;
    QPushButton *dateDArrow;
    QPushButton *pushButton;
    QLabel *YearCount;

    void setupUi(QWidget *Widget)
    {
        if (Widget->objectName().isEmpty())
            Widget->setObjectName(QString::fromUtf8("Widget"));
        Widget->resize(480, 800);
        Widget->setStyleSheet(QString::fromUtf8(""));
        backWidget = new QWidget(Widget);
        backWidget->setObjectName(QString::fromUtf8("backWidget"));
        backWidget->setGeometry(QRect(0, 0, 480, 800));
        backWidget->setStyleSheet(QString::fromUtf8("\n"
"/*\350\203\214\346\231\257\350\211\262*/\n"
"QWidget#backWidget{\n"
"	background: transparent;\n"
"/*	border-image: url(:/Images/backgrd.png);	*/\n"
"   background-color:rgb(120,185,255);   \n"
"			\n"
"}\n"
"\n"
"/*\344\270\273\347\225\214\351\235\242*/\n"
"/*Logo  */\n"
"QLabel#logoLabel{\n"
"	border-image:url(:/Images/TgLogWhite.png);		\n"
"}\n"
"/*\346\227\266\351\227\264*/\n"
"QLabel#timeLabel{\n"
"	color: white;\n"
"}\n"
"/*\346\227\245\346\234\237*/\n"
"QLabel#dateLabel{\n"
"	color: white;\n"
"}\n"
"/*\346\230\237\346\234\237*/\n"
"QLabel#weekLabel{\n"
"	color: white;\n"
"}\n"
"/*\346\223\215\344\275\234\346\217\220\347\244\272*/\n"
"QLabel#TitleCLabel{\n"
"	color: white;\n"
"}\n"
"/*\347\212\266\346\200\201\346\230\276\347\244\272*/\n"
"QLabel#CStatus{\n"
"	color: white;\n"
"}\n"
"QPushButton#Log_pushbtn{\n"
"/*	border-radius: 10px;		\n"
"	border-image:url(://Images/Retbtnbgd.png);     \n"
"   color:white;		\n"
"   background-color:rgb(64,115,255);      */\n"
"                  \n"
"	\n"
"}\n"
"\n"
""
                        "/*\350\217\234\345\215\225\346\214\211\351\222\256*/\n"
"QPushButton#menuBtn{\n"
"/*	border-radius: 10px;		\n"
"	border-image:url(://Images/Retbtnbgd.png);     */\n"
"/*     color:white;		\n"
"  background-color:rgb(64,115,255);                     */\n"
"/*   border: 1px solid rgb(11 , 137 , 234);                   */\n"
"	\n"
"}\n"
"\n"
"QLabel#MenuLabel{\n"
"	color: white;\n"
"}\n"
"/*\350\256\276\347\275\256\346\214\211\351\222\256*/\n"
"QPushButton#setBtn{\n"
"/*	border-radius: 10px;		\n"
"	border-image:url(://Images/Retbtnbgd.png);     \n"
"   color:white;		\n"
"   background-color:rgb(64,115,255);\n"
"   border: 1px solid rgb(11 , 137 , 234);                   */\n"
"	\n"
"}\n"
"\n"
"/*\345\257\206\347\240\201\346\214\211\351\222\256*/\n"
"QPushButton#pswBtn{\n"
"/*	border-radius: 10px;		\n"
"	border-image:url(://Images/Retbtnbgd.png);    \n"
"   color:white;		\n"
"   background-color:rgb(64,115,255);\n"
"   border: 1px solid rgb(11 , 137 , 234);                   */\n"
"	\n"
"}\n"
"\n"
"/*\351\227\250\351"
                        "\223\203\346\214\211\351\222\256*/\n"
"QPushButton#dellBtn{\n"
"/*	border-radius: 10px;		\n"
"	border-image:url(://Images/Retbtnbgd.png);     \n"
"   color:white;		\n"
"   background-color:rgb(64,115,255);\n"
"   border: 1px solid rgb(11 , 137 , 234);                   */\n"
"	\n"
"}\n"
"\n"
"/*\350\217\234\345\215\225\347\225\214\351\235\242*/\n"
"/*\350\217\234\345\215\225\347\225\214\351\235\242\350\277\224\345\233\236\344\270\273\347\225\214\351\235\242\346\214\211\351\222\256*/\n"
"QPushButton#menuRetBtn 	{\n"
"	border-radius: 10px;     \n"
"	border-image:url(://Images/RetBtn2.png);\n"
"}\n"
"\n"
"/*\347\224\250\346\210\267\346\214\207\351\235\231\350\204\211\347\256\241\347\220\206\347\225\214\351\235\242*/\n"
"/*\347\224\250\346\210\267\346\214\207\351\235\231\350\204\211\347\256\241\347\220\206\347\225\214\351\235\242\350\277\224\345\233\236\351\222\256*/\n"
"\n"
"QLabel#UMLabel{\n"
"	color: white;\n"
"}\n"
"QPushButton#userManageRetBtn 	{\n"
"	border-radius: 10px;\n"
"	border-image:url(://Images/RetBt"
                        "n2.png);\n"
"}\n"
"\n"
"QLineEdit#userManageEdit{\n"
"	border-radius: 10px;	\n"
"}\n"
"/*\346\237\245\350\257\242\347\225\214\351\235\242*/\n"
"\n"
"\n"
"\n"
"/*\347\224\250\346\210\267\346\214\207\351\235\231\350\204\211\346\263\250\345\206\214\347\225\214\351\235\242*/\n"
"\n"
"QLabel#NewModifyLabel{\n"
"	color: white;\n"
"}\n"
"QPushButton#newFingerRetBtn 	{\n"
"	border-radius: 10px;\n"
"	border-image:url(://Images/RetBtn2.png);\n"
"}\n"
"QLabel#deviceNumber 	{\n"
"	color:white;\n"
"}\n"
"\n"
"QLineEdit#workNumEdit{\n"
"	border-radius: 10px;	\n"
"}\n"
"QLabel#workNumLabel	{\n"
"	color:white;\n"
"}\n"
"QLineEdit#nameEdit{\n"
"	border-radius: 10px;	\n"
"}\n"
"QLabel#nameLabel{\n"
"	color:white;\n"
"}\n"
"\n"
"QLabel#departLabel{\n"
"	color:white;\n"
"}\n"
"QComboBox#departcomboBox{\n"
"	color:white;\n"
"	border-image:url(://Images/backgroundBtn.png);			\n"
"}\n"
"QLabel#authorityLabel{\n"
"	color:white;\n"
"}\n"
"QComboBox#authoritycomboBox{\n"
"	color:white;\n"
"	border-image:url(://Images/backgroundBtn.png)"
                        ";			\n"
"}\n"
"\n"
"QLabel#pswLabel{\n"
"	color:white;\n"
"}\n"
"QLineEdit#pswEdit{\n"
"	border-radius: 10px;	\n"
"}\n"
"\n"
"\n"
"QLabel#FindLabel{\n"
"	color: white;\n"
"}\n"
"/*\347\212\266\346\200\201\346\230\276\347\244\272*/\n"
"QLabel#TitleRLabel{\n"
"	color: white;\n"
"}\n"
"/*\347\212\266\346\200\201\346\230\276\347\244\272*/\n"
"QLabel#RStatus{\n"
"	color: white;\n"
"}\n"
"/*\350\256\276\347\275\256\347\225\214\351\235\242*/\n"
"\n"
"QLabel#SetLabel{\n"
"	color: white;\n"
"}\n"
"QPushButton#set_retBtn{\n"
"	color:white;\n"
"	border-radius: 10px;\n"
"	border-image:url(://Images/RetBtn2.png);\n"
"}\n"
"QLabel#deviceNumber 	{\n"
"	color:white;\n"
"}\n"
"QPushButton#showTableRetBtn 	{\n"
"	border-radius: 10px;\n"
"	border-image:url(://Images/RetBtn2.png);\n"
"}\n"
"/*\351\200\232\350\256\257\350\256\276\347\275\256\347\225\214\351\235\242*/\n"
"\n"
"QLabel#ComunateSetLabel 	{\n"
"	color:white;\n"
"}\n"
"/*\346\227\266\351\227\264\350\256\276\347\275\256\347\225\214\351\235\242*/\n"
"\n"
"QPushButton#Time"
                        "Set_ret {\n"
"	border-radius: 10px;\n"
"	border-image:url(://Images/RetBtn2.png);\n"
"}\n"
"\n"
"QLabel#DateSetLabel	{\n"
"	color:white;\n"
"}\n"
"QLabel#IpSetLabel 	{\n"
"	color:white;\n"
"}\n"
"\n"
"QLabel#SetTimeLabel	{\n"
"	color:white;\n"
"}\n"
"\n"
"\n"
"QPushButton#CommuSet_retBtn {\n"
"	border-radius: 10px;\n"
"	border-image:url(://Images/RetBtn2.png);\n"
"}\n"
"/*IP\350\256\276\347\275\256\347\225\214\351\235\242*/\n"
"QPushButton#setIP_retBtn 	{\n"
"	border-radius: 10px;\n"
"	border-image:url(://Images/RetBtn2.png);\n"
"}\n"
"/*\350\256\276\347\275\256\346\227\245\346\234\237\347\225\214\351\235\242*/\n"
"\n"
"QPushButton#Date_RetBtn{\n"
"	border-radius: 10px;\n"
"	border-image:url(://Images/RetBtn2.png);\n"
"}\n"
"\n"
"QPushButton#YearUpArrow{\n"
"	border-radius:10px; \n"
"   border:2px groove gray;      \n"
"	padding:2px 4px;\n"
"	border-image:url(://Images/upArrow.jpg);\n"
"}\n"
"\n"
"QPushButton#YearDArrow{\n"
"	border-radius: 10px;\n"
"border:2px groove gray;      \n"
"	padding:2px 4px;\n"
"	bor"
                        "der-image:url(://Images/downArrow.jpg);\n"
"}\n"
"QPushButton#monthUpArrow{\n"
"	border-radius: 10px;\n"
"border:2px groove gray;      \n"
"	padding:2px 4px;\n"
"	border-image:url(://Images/upArrow.jpg);\n"
"}\n"
"QPushButton#monthDArrow{\n"
"	border-radius: 10px;\n"
"border:2px groove gray;      \n"
"	padding:2px 4px;\n"
"	border-image:url(://Images/downArrow.jpg);\n"
"}\n"
"QPushButton#dateUpArrow{\n"
"	border-radius: 10px;\n"
"border:2px groove gray;      \n"
"	padding:2px 4px;\n"
"	border-image:url(://Images/upArrow.jpg);\n"
"}\n"
"QPushButton#dateDArrow{\n"
"	border-radius: 10px;\n"
"border:2px groove gray;      \n"
"	padding:2px 4px;\n"
"	border-image:url(://Images/downArrow.jpg);\n"
"}\n"
"QLabel#Datetips{\n"
"	color:white;\n"
"}\n"
"QLabel#TimeSetLabel{\n"
"	color:white;\n"
"}\n"
"QLineEdit#IPInputEdit{\n"
"	border-radius: 10px;	\n"
"}\n"
"\n"
"/*\347\256\241\347\220\206\345\221\230\351\252\214\350\257\201\347\225\214\351\235\242*/\n"
"\n"
"QLineEdit#SuperuserPsw_Input{\n"
"	border-radius: 10px;	\n"
"}"
                        "\n"
"QLabel#SuperUsertitleLabel{\n"
"	color:white;\n"
"}\n"
"QLabel#SuperUserstatusLabel{\n"
"	color:white;\n"
"}\n"
"\n"
"/*\350\256\276\345\244\207\344\277\241\346\201\257\346\230\276\347\244\272\347\225\214\351\235\242*/\n"
"\n"
"QPushButton#DeviceInfor_retBtn{\n"
"	color:white;\n"
"	border-radius: 10px;\n"
"	border-image:url(://Images/RetBtn2.png);\n"
"}\n"
"\n"
"\n"
""));
        stackedwidget = new QStackedWidget(backWidget);
        stackedwidget->setObjectName(QString::fromUtf8("stackedwidget"));
        stackedwidget->setGeometry(QRect(0, 0, 480, 800));
        QFont font;
        font.setPointSize(10);
        stackedwidget->setFont(font);
        stackedwidget->setFocusPolicy(Qt::NoFocus);
        stackedwidget->setLayoutDirection(Qt::LeftToRight);
        mainPage = new QWidget();
        mainPage->setObjectName(QString::fromUtf8("mainPage"));
        dellBtn = new QPushButton(mainPage);
        dellBtn->setObjectName(QString::fromUtf8("dellBtn"));
        dellBtn->setGeometry(QRect(365, 670, 100, 60));
        dellBtn->setMinimumSize(QSize(100, 60));
        dellBtn->setMaximumSize(QSize(100, 60));
        QFont font1;
        font1.setPointSize(15);
        dellBtn->setFont(font1);
        dellBtn->setFocusPolicy(Qt::NoFocus);
        pswBtn = new QPushButton(mainPage);
        pswBtn->setObjectName(QString::fromUtf8("pswBtn"));
        pswBtn->setGeometry(QRect(250, 670, 100, 60));
        pswBtn->setMinimumSize(QSize(100, 60));
        pswBtn->setMaximumSize(QSize(100, 60));
        pswBtn->setFont(font1);
        pswBtn->setFocusPolicy(Qt::NoFocus);
        setBtn = new QPushButton(mainPage);
        setBtn->setObjectName(QString::fromUtf8("setBtn"));
        setBtn->setGeometry(QRect(135, 670, 100, 60));
        setBtn->setMinimumSize(QSize(100, 60));
        setBtn->setMaximumSize(QSize(100, 60));
        setBtn->setFont(font1);
        setBtn->setFocusPolicy(Qt::NoFocus);
        menuBtn = new QPushButton(mainPage);
        menuBtn->setObjectName(QString::fromUtf8("menuBtn"));
        menuBtn->setGeometry(QRect(20, 670, 100, 60));
        menuBtn->setMinimumSize(QSize(100, 60));
        menuBtn->setMaximumSize(QSize(100, 60));
        menuBtn->setSizeIncrement(QSize(100, 70));
        QFont font2;
        font2.setFamily(QString::fromUtf8("Ubuntu"));
        font2.setPointSize(15);
        menuBtn->setFont(font2);
        menuBtn->setMouseTracking(false);
        menuBtn->setFocusPolicy(Qt::NoFocus);
        weekLabel = new QLabel(mainPage);
        weekLabel->setObjectName(QString::fromUtf8("weekLabel"));
        weekLabel->setGeometry(QRect(265, 325, 100, 40));
        weekLabel->setMinimumSize(QSize(100, 40));
        weekLabel->setMaximumSize(QSize(100, 40));
        QFont font3;
        font3.setFamily(QString::fromUtf8("URW Gothic L"));
        font3.setPointSize(16);
        weekLabel->setFont(font3);
        weekLabel->setStyleSheet(QString::fromUtf8(""));
        weekLabel->setFrameShape(QFrame::NoFrame);
        weekLabel->setAlignment(Qt::AlignCenter);
        dateLabel = new QLabel(mainPage);
        dateLabel->setObjectName(QString::fromUtf8("dateLabel"));
        dateLabel->setGeometry(QRect(120, 325, 140, 40));
        dateLabel->setMinimumSize(QSize(140, 40));
        dateLabel->setMaximumSize(QSize(140, 40));
        dateLabel->setFont(font3);
        dateLabel->setStyleSheet(QString::fromUtf8(""));
        dateLabel->setFrameShape(QFrame::NoFrame);
        dateLabel->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        timeLabel = new QLabel(mainPage);
        timeLabel->setObjectName(QString::fromUtf8("timeLabel"));
        timeLabel->setGeometry(QRect(115, 230, 250, 90));
        timeLabel->setMinimumSize(QSize(250, 80));
        timeLabel->setMaximumSize(QSize(250, 16777215));
        QFont font4;
        font4.setFamily(QString::fromUtf8("Sawasdee"));
        font4.setPointSize(46);
        font4.setItalic(false);
        timeLabel->setFont(font4);
        timeLabel->setFocusPolicy(Qt::NoFocus);
        timeLabel->setStyleSheet(QString::fromUtf8(""));
        timeLabel->setFrameShape(QFrame::NoFrame);
        timeLabel->setAlignment(Qt::AlignCenter);
        logoLabel = new QLabel(mainPage);
        logoLabel->setObjectName(QString::fromUtf8("logoLabel"));
        logoLabel->setGeometry(QRect(25, 75, 429, 100));
        logoLabel->setMinimumSize(QSize(429, 100));
        logoLabel->setMaximumSize(QSize(429, 100));
        logoLabel->setStyleSheet(QString::fromUtf8(""));
        TitleCLabel = new QLabel(mainPage);
        TitleCLabel->setObjectName(QString::fromUtf8("TitleCLabel"));
        TitleCLabel->setGeometry(QRect(120, 390, 240, 50));
        TitleCLabel->setFont(font1);
        TitleCLabel->setLayoutDirection(Qt::LeftToRight);
        TitleCLabel->setAlignment(Qt::AlignCenter);
        CStatus = new QLabel(mainPage);
        CStatus->setObjectName(QString::fromUtf8("CStatus"));
        CStatus->setGeometry(QRect(120, 545, 240, 50));
        CStatus->setFont(font1);
        CStatus->setAlignment(Qt::AlignCenter);
        stackedwidget->addWidget(mainPage);
        menuPage = new QWidget();
        menuPage->setObjectName(QString::fromUtf8("menuPage"));
        userManageBtn = new QPushButton(menuPage);
        userManageBtn->setObjectName(QString::fromUtf8("userManageBtn"));
        userManageBtn->setGeometry(QRect(140, 125, 200, 100));
        userManageBtn->setMinimumSize(QSize(200, 100));
        userManageBtn->setMaximumSize(QSize(200, 100));
        userManageBtn->setFont(font1);
        userManageBtn->setFocusPolicy(Qt::NoFocus);
        menuRetBtn = new QPushButton(menuPage);
        menuRetBtn->setObjectName(QString::fromUtf8("menuRetBtn"));
        menuRetBtn->setGeometry(QRect(15, 15, 70, 60));
        menuRetBtn->setMinimumSize(QSize(70, 60));
        menuRetBtn->setMaximumSize(QSize(70, 60));
        menuRetBtn->setFont(font1);
        menuRetBtn->setFocusPolicy(Qt::NoFocus);
        sysInformationBtn = new QPushButton(menuPage);
        sysInformationBtn->setObjectName(QString::fromUtf8("sysInformationBtn"));
        sysInformationBtn->setGeometry(QRect(140, 505, 200, 100));
        sysInformationBtn->setMinimumSize(QSize(200, 100));
        sysInformationBtn->setMaximumSize(QSize(200, 100));
        sysInformationBtn->setFont(font1);
        sysInformationBtn->setFocusPolicy(Qt::NoFocus);
        MenuLabel = new QLabel(menuPage);
        MenuLabel->setObjectName(QString::fromUtf8("MenuLabel"));
        MenuLabel->setGeometry(QRect(190, 20, 100, 36));
        MenuLabel->setFont(font1);
        MenuLabel->setAlignment(Qt::AlignCenter);
        LogQueryBtn = new QPushButton(menuPage);
        LogQueryBtn->setObjectName(QString::fromUtf8("LogQueryBtn"));
        LogQueryBtn->setGeometry(QRect(140, 380, 200, 100));
        LogQueryBtn->setMinimumSize(QSize(200, 100));
        LogQueryBtn->setMaximumSize(QSize(200, 100));
        LogQueryBtn->setFont(font1);
        LogQueryBtn->setFocusPolicy(Qt::NoFocus);
        AttendCheckBtn = new QPushButton(menuPage);
        AttendCheckBtn->setObjectName(QString::fromUtf8("AttendCheckBtn"));
        AttendCheckBtn->setGeometry(QRect(140, 255, 200, 100));
        AttendCheckBtn->setMinimumSize(QSize(200, 100));
        AttendCheckBtn->setMaximumSize(QSize(200, 100));
        AttendCheckBtn->setFont(font1);
        AttendCheckBtn->setFocusPolicy(Qt::NoFocus);
        stackedwidget->addWidget(menuPage);
        userManagePage = new QWidget();
        userManagePage->setObjectName(QString::fromUtf8("userManagePage"));
        newFingerBtn = new QPushButton(userManagePage);
        newFingerBtn->setObjectName(QString::fromUtf8("newFingerBtn"));
        newFingerBtn->setGeometry(QRect(140, 125, 200, 100));
        newFingerBtn->setMinimumSize(QSize(200, 100));
        newFingerBtn->setMaximumSize(QSize(200, 100));
        newFingerBtn->setFont(font1);
        newFingerBtn->setFocusPolicy(Qt::NoFocus);
        userManageRetBtn = new QPushButton(userManagePage);
        userManageRetBtn->setObjectName(QString::fromUtf8("userManageRetBtn"));
        userManageRetBtn->setGeometry(QRect(15, 15, 70, 60));
        userManageRetBtn->setMinimumSize(QSize(70, 60));
        userManageRetBtn->setMaximumSize(QSize(70, 60));
        userManageRetBtn->setFont(font1);
        userManageRetBtn->setFocusPolicy(Qt::NoFocus);
        FindUserBtn = new QPushButton(userManagePage);
        FindUserBtn->setObjectName(QString::fromUtf8("FindUserBtn"));
        FindUserBtn->setGeometry(QRect(140, 400, 200, 100));
        FindUserBtn->setMinimumSize(QSize(200, 100));
        FindUserBtn->setMaximumSize(QSize(200, 100));
        FindUserBtn->setFont(font1);
        FindUserBtn->setFocusPolicy(Qt::NoFocus);
        UMLabel = new QLabel(userManagePage);
        UMLabel->setObjectName(QString::fromUtf8("UMLabel"));
        UMLabel->setGeometry(QRect(130, 20, 200, 36));
        UMLabel->setFont(font1);
        UMLabel->setAlignment(Qt::AlignCenter);
        stackedwidget->addWidget(userManagePage);
        registerPage = new QWidget();
        registerPage->setObjectName(QString::fromUtf8("registerPage"));
        FingerMap = new QLabel(registerPage);
        FingerMap->setObjectName(QString::fromUtf8("FingerMap"));
        FingerMap->setGeometry(QRect(0, 0, 480, 640));
        FingerMap->setMinimumSize(QSize(64, 160));
        FingerMap->setMaximumSize(QSize(640, 640));
        FingerMap->setLayoutDirection(Qt::LeftToRight);
        FingerMap->setAutoFillBackground(false);
        FingerMap->setFrameShape(QFrame::Box);
        TitleRLabel = new QLabel(registerPage);
        TitleRLabel->setObjectName(QString::fromUtf8("TitleRLabel"));
        TitleRLabel->setGeometry(QRect(275, 295, 200, 50));
        QFont font5;
        font5.setPointSize(11);
        TitleRLabel->setFont(font5);
        pswLabel = new QLabel(registerPage);
        pswLabel->setObjectName(QString::fromUtf8("pswLabel"));
        pswLabel->setGeometry(QRect(15, 345, 55, 45));
        pswLabel->setMinimumSize(QSize(55, 45));
        pswLabel->setMaximumSize(QSize(55, 45));
        pswLabel->setFont(font1);
        authorityLabel = new QLabel(registerPage);
        authorityLabel->setObjectName(QString::fromUtf8("authorityLabel"));
        authorityLabel->setGeometry(QRect(15, 285, 55, 45));
        authorityLabel->setMinimumSize(QSize(55, 45));
        authorityLabel->setMaximumSize(QSize(55, 45));
        authorityLabel->setFont(font1);
        departLabel = new QLabel(registerPage);
        departLabel->setObjectName(QString::fromUtf8("departLabel"));
        departLabel->setGeometry(QRect(15, 220, 55, 45));
        departLabel->setMinimumSize(QSize(55, 45));
        departLabel->setMaximumSize(QSize(55, 45));
        departLabel->setFont(font1);
        nameLabel = new QLabel(registerPage);
        nameLabel->setObjectName(QString::fromUtf8("nameLabel"));
        nameLabel->setGeometry(QRect(15, 150, 55, 45));
        nameLabel->setMinimumSize(QSize(55, 45));
        nameLabel->setMaximumSize(QSize(55, 45));
        nameLabel->setFont(font1);
        workNumLabel = new QLabel(registerPage);
        workNumLabel->setObjectName(QString::fromUtf8("workNumLabel"));
        workNumLabel->setGeometry(QRect(15, 90, 55, 45));
        workNumLabel->setMinimumSize(QSize(55, 45));
        workNumLabel->setMaximumSize(QSize(55, 45));
        workNumLabel->setFont(font1);
        newFingerRetBtn = new QPushButton(registerPage);
        newFingerRetBtn->setObjectName(QString::fromUtf8("newFingerRetBtn"));
        newFingerRetBtn->setGeometry(QRect(15, 15, 70, 60));
        newFingerRetBtn->setMinimumSize(QSize(70, 60));
        newFingerRetBtn->setMaximumSize(QSize(70, 60));
        newFingerRetBtn->setFocusPolicy(Qt::NoFocus);
        captureButton = new QPushButton(registerPage);
        captureButton->setObjectName(QString::fromUtf8("captureButton"));
        captureButton->setGeometry(QRect(127, 696, 201, 61));
        stackedwidget->addWidget(registerPage);
        showTable_page = new QWidget();
        showTable_page->setObjectName(QString::fromUtf8("showTable_page"));
        InputQuery = new QLineEdit(showTable_page);
        InputQuery->setObjectName(QString::fromUtf8("InputQuery"));
        InputQuery->setGeometry(QRect(50, 485, 150, 50));
        InputQuery->setMinimumSize(QSize(150, 50));
        InputQuery->setMaximumSize(QSize(150, 50));
        showTableRetBtn = new QPushButton(showTable_page);
        showTableRetBtn->setObjectName(QString::fromUtf8("showTableRetBtn"));
        showTableRetBtn->setGeometry(QRect(15, 15, 70, 60));
        showTableRetBtn->setMinimumSize(QSize(70, 60));
        showTableRetBtn->setMaximumSize(QSize(70, 60));
        showTableRetBtn->setFocusPolicy(Qt::NoFocus);
        table = new QTableWidget(showTable_page);
        if (table->columnCount() < 4)
            table->setColumnCount(4);
        QTableWidgetItem *__qtablewidgetitem = new QTableWidgetItem();
        table->setHorizontalHeaderItem(0, __qtablewidgetitem);
        QTableWidgetItem *__qtablewidgetitem1 = new QTableWidgetItem();
        table->setHorizontalHeaderItem(1, __qtablewidgetitem1);
        QTableWidgetItem *__qtablewidgetitem2 = new QTableWidgetItem();
        table->setHorizontalHeaderItem(2, __qtablewidgetitem2);
        QTableWidgetItem *__qtablewidgetitem3 = new QTableWidgetItem();
        table->setHorizontalHeaderItem(3, __qtablewidgetitem3);
        table->setObjectName(QString::fromUtf8("table"));
        table->setGeometry(QRect(30, 75, 401, 396));
        table->setMinimumSize(QSize(200, 300));
        table->setMaximumSize(QSize(500, 500));
        table->horizontalHeader()->setStretchLastSection(false);
        FindLabel = new QLabel(showTable_page);
        FindLabel->setObjectName(QString::fromUtf8("FindLabel"));
        FindLabel->setGeometry(QRect(135, 20, 200, 36));
        FindLabel->setFont(font1);
        FindLabel->setAlignment(Qt::AlignCenter);
        DetailBtn = new QPushButton(showTable_page);
        DetailBtn->setObjectName(QString::fromUtf8("DetailBtn"));
        DetailBtn->setGeometry(QRect(305, 485, 120, 50));
        DetailBtn->setFont(font1);
        DetailBtn->setFocusPolicy(Qt::NoFocus);
        stackedwidget->addWidget(showTable_page);
        SuperUser_page = new QWidget();
        SuperUser_page->setObjectName(QString::fromUtf8("SuperUser_page"));
        groupBox = new QGroupBox(SuperUser_page);
        groupBox->setObjectName(QString::fromUtf8("groupBox"));
        groupBox->setGeometry(QRect(115, 115, 251, 456));
        QFont font6;
        font6.setPointSize(13);
        groupBox->setFont(font6);
        groupBox->setFocusPolicy(Qt::NoFocus);
        groupBox->setStyleSheet(QString::fromUtf8(" QGroupBox {\n"
"    /*background-color: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                       stop: 0 #E0E0E0, stop: 1 #FFFFFF);*/\n"
"\n"
"     border: 2px solid grey;\n"
"     border-radius:4px;\n"
"     margin-top: 1ex; /* leave space at the top for the title */\n"
"	 margin-bottom: 1ex\n"
" }\n"
"\n"
"QGroupBox::title {\n"
"	 /*text-align: left;*/\n"
"   subcontrol-origin: margin ;\n"
"    subcontrol-position: top left; /*position at the top\n"
" center */ \n"
"    /* margin-left: 1ex;*/\n"
"     padding:  0 0 0 0px;\n"
"	color:white;\n"
" }\n"
""));
        SuperUserstatusLabel = new QLabel(groupBox);
        SuperUserstatusLabel->setObjectName(QString::fromUtf8("SuperUserstatusLabel"));
        SuperUserstatusLabel->setGeometry(QRect(25, 335, 200, 50));
        SuperUserstatusLabel->setMinimumSize(QSize(200, 50));
        SuperUserstatusLabel->setMaximumSize(QSize(200, 50));
        SuperUserstatusLabel->setFont(font1);
        SuperUserstatusLabel->setStyleSheet(QString::fromUtf8(""));
        SuperUserstatusLabel->setFrameShape(QFrame::NoFrame);
        SuperUserstatusLabel->setAlignment(Qt::AlignCenter);
        groupBox_3 = new QGroupBox(groupBox);
        groupBox_3->setObjectName(QString::fromUtf8("groupBox_3"));
        groupBox_3->setGeometry(QRect(20, 90, 211, 121));
        groupBox_3->setFont(font6);
        SuperuserPsw_Input = new QLineEdit(groupBox_3);
        SuperuserPsw_Input->setObjectName(QString::fromUtf8("SuperuserPsw_Input"));
        SuperuserPsw_Input->setGeometry(QRect(5, 35, 200, 50));
        SuperuserPsw_Input->setMinimumSize(QSize(200, 50));
        SuperuserPsw_Input->setMaximumSize(QSize(200, 50));
        SuperuserPsw_Input->setFont(font1);
        stackedwidget->addWidget(SuperUser_page);
        Set_page = new QWidget();
        Set_page->setObjectName(QString::fromUtf8("Set_page"));
        set_retBtn = new QPushButton(Set_page);
        set_retBtn->setObjectName(QString::fromUtf8("set_retBtn"));
        set_retBtn->setGeometry(QRect(15, 15, 70, 60));
        set_retBtn->setMinimumSize(QSize(70, 60));
        set_retBtn->setMaximumSize(QSize(70, 60));
        set_retBtn->setFocusPolicy(Qt::NoFocus);
        communcationSet = new QPushButton(Set_page);
        communcationSet->setObjectName(QString::fromUtf8("communcationSet"));
        communcationSet->setGeometry(QRect(140, 125, 200, 100));
        communcationSet->setMinimumSize(QSize(200, 100));
        communcationSet->setMaximumSize(QSize(200, 100));
        communcationSet->setFont(font1);
        communcationSet->setFocusPolicy(Qt::NoFocus);
        logFind = new QPushButton(Set_page);
        logFind->setObjectName(QString::fromUtf8("logFind"));
        logFind->setGeometry(QRect(140, 405, 200, 100));
        logFind->setMinimumSize(QSize(200, 100));
        logFind->setMaximumSize(QSize(200, 100));
        logFind->setFont(font1);
        logFind->setFocusPolicy(Qt::NoFocus);
        SetLabel = new QLabel(Set_page);
        SetLabel->setObjectName(QString::fromUtf8("SetLabel"));
        SetLabel->setGeometry(QRect(140, 20, 200, 36));
        SetLabel->setFont(font1);
        SetLabel->setAlignment(Qt::AlignCenter);
        TimeSet = new QPushButton(Set_page);
        TimeSet->setObjectName(QString::fromUtf8("TimeSet"));
        TimeSet->setGeometry(QRect(140, 270, 200, 100));
        TimeSet->setMinimumSize(QSize(200, 100));
        TimeSet->setMaximumSize(QSize(200, 100));
        TimeSet->setFont(font1);
        TimeSet->setFocusPolicy(Qt::NoFocus);
        stackedwidget->addWidget(Set_page);
        ComunicateSet_page = new QWidget();
        ComunicateSet_page->setObjectName(QString::fromUtf8("ComunicateSet_page"));
        IPSetBtn = new QPushButton(ComunicateSet_page);
        IPSetBtn->setObjectName(QString::fromUtf8("IPSetBtn"));
        IPSetBtn->setGeometry(QRect(140, 125, 200, 100));
        IPSetBtn->setMinimumSize(QSize(200, 100));
        IPSetBtn->setMaximumSize(QSize(200, 100));
        IPSetBtn->setFont(font1);
        IPSetBtn->setFocusPolicy(Qt::NoFocus);
        UartSetBtn = new QPushButton(ComunicateSet_page);
        UartSetBtn->setObjectName(QString::fromUtf8("UartSetBtn"));
        UartSetBtn->setGeometry(QRect(140, 400, 200, 100));
        UartSetBtn->setMinimumSize(QSize(200, 100));
        UartSetBtn->setMaximumSize(QSize(200, 100));
        UartSetBtn->setFont(font1);
        UartSetBtn->setFocusPolicy(Qt::NoFocus);
        CommuSet_retBtn = new QPushButton(ComunicateSet_page);
        CommuSet_retBtn->setObjectName(QString::fromUtf8("CommuSet_retBtn"));
        CommuSet_retBtn->setGeometry(QRect(15, 15, 70, 60));
        CommuSet_retBtn->setMinimumSize(QSize(70, 60));
        CommuSet_retBtn->setMaximumSize(QSize(70, 60));
        CommuSet_retBtn->setFocusPolicy(Qt::NoFocus);
        ComunateSetLabel = new QLabel(ComunicateSet_page);
        ComunateSetLabel->setObjectName(QString::fromUtf8("ComunateSetLabel"));
        ComunateSetLabel->setGeometry(QRect(140, 20, 200, 36));
        ComunateSetLabel->setFont(font1);
        ComunateSetLabel->setAlignment(Qt::AlignCenter);
        stackedwidget->addWidget(ComunicateSet_page);
        page = new QWidget();
        page->setObjectName(QString::fromUtf8("page"));
        TimeSetLabel = new QLabel(page);
        TimeSetLabel->setObjectName(QString::fromUtf8("TimeSetLabel"));
        TimeSetLabel->setGeometry(QRect(140, 20, 200, 36));
        TimeSetLabel->setFont(font1);
        TimeSetLabel->setAlignment(Qt::AlignCenter);
        TimeSet_ret = new QPushButton(page);
        TimeSet_ret->setObjectName(QString::fromUtf8("TimeSet_ret"));
        TimeSet_ret->setGeometry(QRect(15, 15, 70, 60));
        TimeSet_ret->setMinimumSize(QSize(70, 60));
        TimeSet_ret->setMaximumSize(QSize(70, 60));
        TimeSet_ret->setFocusPolicy(Qt::NoFocus);
        DateSetLabel = new QLabel(page);
        DateSetLabel->setObjectName(QString::fromUtf8("DateSetLabel"));
        DateSetLabel->setGeometry(QRect(70, 130, 100, 45));
        DateSetLabel->setFont(font1);
        DateSetLabel->setAlignment(Qt::AlignCenter);
        SetTimeLabel = new QLabel(page);
        SetTimeLabel->setObjectName(QString::fromUtf8("SetTimeLabel"));
        SetTimeLabel->setGeometry(QRect(70, 260, 100, 45));
        SetTimeLabel->setFont(font1);
        SetTimeLabel->setAlignment(Qt::AlignCenter);
        DateSetBtn = new QPushButton(page);
        DateSetBtn->setObjectName(QString::fromUtf8("DateSetBtn"));
        DateSetBtn->setGeometry(QRect(195, 130, 150, 45));
        DateSetBtn->setFont(font6);
        TimeSetBtn = new QPushButton(page);
        TimeSetBtn->setObjectName(QString::fromUtf8("TimeSetBtn"));
        TimeSetBtn->setGeometry(QRect(195, 265, 150, 45));
        TimeSetBtn->setFont(font6);
        stackedwidget->addWidget(page);
        IPSet_page = new QWidget();
        IPSet_page->setObjectName(QString::fromUtf8("IPSet_page"));
        groupBox_2 = new QGroupBox(IPSet_page);
        groupBox_2->setObjectName(QString::fromUtf8("groupBox_2"));
        groupBox_2->setGeometry(QRect(20, 80, 441, 711));
        groupBox_2->setStyleSheet(QString::fromUtf8("QGroupBox {\n"
"    /*background-color: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                       stop: 0 #E0E0E0, stop: 1 #FFFFFF);*/\n"
"\n"
"     border: 2px solid grey;\n"
"     border-radius:4px;\n"
"     margin-top: 1ex; /* leave space at the top for the title */\n"
"	 margin-bottom: 1ex\n"
" }\n"
"\n"
"QGroupBox::title {\n"
"	 /*text-align: left;*/\n"
"   subcontrol-origin: margin ;\n"
"    subcontrol-position: top left; /*position at the top\n"
" center */ \n"
"    /* margin-left: 1ex;*/\n"
"     padding:  0 0 0 0px;\n"
"	color:white;\n"
" }\n"
""));
        deviceIPBtn = new QRadioButton(groupBox_2);
        deviceIPBtn->setObjectName(QString::fromUtf8("deviceIPBtn"));
        deviceIPBtn->setGeometry(QRect(95, 260, 150, 30));
        QFont font7;
        font7.setPointSize(12);
        deviceIPBtn->setFont(font7);
        deviceIPBtn->setFocusPolicy(Qt::NoFocus);
        deviceIPBtn->setStyleSheet(QString::fromUtf8(""));
        serverIPBtn = new QRadioButton(groupBox_2);
        serverIPBtn->setObjectName(QString::fromUtf8("serverIPBtn"));
        serverIPBtn->setGeometry(QRect(95, 305, 150, 30));
        serverIPBtn->setFont(font7);
        serverIPBtn->setFocusPolicy(Qt::NoFocus);
        serverIPBtn->setStyleSheet(QString::fromUtf8(""));
        IPsetOkBtn = new QPushButton(groupBox_2);
        IPsetOkBtn->setObjectName(QString::fromUtf8("IPsetOkBtn"));
        IPsetOkBtn->setGeometry(QRect(135, 395, 150, 50));
        IPsetOkBtn->setMinimumSize(QSize(150, 50));
        IPsetOkBtn->setMaximumSize(QSize(150, 50));
        IPsetOkBtn->setFocusPolicy(Qt::NoFocus);
        layoutWidget = new QWidget(groupBox_2);
        layoutWidget->setObjectName(QString::fromUtf8("layoutWidget"));
        layoutWidget->setGeometry(QRect(90, 165, 266, 52));
        horizontalLayout_9 = new QHBoxLayout(layoutWidget);
        horizontalLayout_9->setSpacing(6);
        horizontalLayout_9->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_9->setObjectName(QString::fromUtf8("horizontalLayout_9"));
        horizontalLayout_9->setContentsMargins(0, 0, 0, 0);
        IPInputlabel = new QLabel(layoutWidget);
        IPInputlabel->setObjectName(QString::fromUtf8("IPInputlabel"));
        IPInputlabel->setMinimumSize(QSize(100, 50));
        IPInputlabel->setMaximumSize(QSize(100, 50));
        IPInputlabel->setFont(font6);
        IPInputlabel->setStyleSheet(QString::fromUtf8(""));
        IPInputlabel->setAlignment(Qt::AlignCenter);

        horizontalLayout_9->addWidget(IPInputlabel);

        IPInputEdit = new QLineEdit(layoutWidget);
        IPInputEdit->setObjectName(QString::fromUtf8("IPInputEdit"));
        IPInputEdit->setMinimumSize(QSize(150, 50));
        IPInputEdit->setMaximumSize(QSize(150, 50));
        IPInputEdit->setFocusPolicy(Qt::StrongFocus);

        horizontalLayout_9->addWidget(IPInputEdit);

        setIP_retBtn = new QPushButton(IPSet_page);
        setIP_retBtn->setObjectName(QString::fromUtf8("setIP_retBtn"));
        setIP_retBtn->setGeometry(QRect(15, 15, 70, 60));
        setIP_retBtn->setMinimumSize(QSize(70, 60));
        setIP_retBtn->setMaximumSize(QSize(70, 60));
        setIP_retBtn->setFocusPolicy(Qt::NoFocus);
        IpSetLabel = new QLabel(IPSet_page);
        IpSetLabel->setObjectName(QString::fromUtf8("IpSetLabel"));
        IpSetLabel->setGeometry(QRect(140, 15, 200, 36));
        IpSetLabel->setFont(font1);
        IpSetLabel->setAlignment(Qt::AlignCenter);
        stackedwidget->addWidget(IPSet_page);
        DeviceInfor_page = new QWidget();
        DeviceInfor_page->setObjectName(QString::fromUtf8("DeviceInfor_page"));
        DeviceInfor_retBtn = new QPushButton(DeviceInfor_page);
        DeviceInfor_retBtn->setObjectName(QString::fromUtf8("DeviceInfor_retBtn"));
        DeviceInfor_retBtn->setGeometry(QRect(15, 15, 70, 60));
        DeviceInfor_retBtn->setMinimumSize(QSize(70, 60));
        DeviceInfor_retBtn->setMaximumSize(QSize(70, 60));
        DeviceInfor_retBtn->setFocusPolicy(Qt::NoFocus);
        IDNumberlabel2 = new QLabel(DeviceInfor_page);
        IDNumberlabel2->setObjectName(QString::fromUtf8("IDNumberlabel2"));
        IDNumberlabel2->setGeometry(QRect(140, 550, 200, 50));
        IDNumberlabel2->setMinimumSize(QSize(200, 50));
        IDNumberlabel2->setMaximumSize(QSize(200, 50));
        IDNumberlabel2->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 255);"));
        IDNumberlabel2->setFrameShape(QFrame::Box);
        IDNumberlabel2->setAlignment(Qt::AlignCenter);
        IDNumberlabel = new QLabel(DeviceInfor_page);
        IDNumberlabel->setObjectName(QString::fromUtf8("IDNumberlabel"));
        IDNumberlabel->setGeometry(QRect(70, 555, 70, 50));
        IDNumberlabel->setMinimumSize(QSize(70, 50));
        IDNumberlabel->setMaximumSize(QSize(70, 50));
        QFont font8;
        font8.setPointSize(14);
        IDNumberlabel->setFont(font8);
        IDNumberlabel->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 255);"));
        IDNumberlabel->setAlignment(Qt::AlignCenter);
        FWNumberlabel2 = new QLabel(DeviceInfor_page);
        FWNumberlabel2->setObjectName(QString::fromUtf8("FWNumberlabel2"));
        FWNumberlabel2->setGeometry(QRect(140, 430, 200, 50));
        FWNumberlabel2->setMinimumSize(QSize(200, 50));
        FWNumberlabel2->setMaximumSize(QSize(200, 50));
        FWNumberlabel2->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 255);"));
        FWNumberlabel2->setFrameShape(QFrame::Box);
        FWNumberlabel2->setAlignment(Qt::AlignCenter);
        FWNumberlabel = new QLabel(DeviceInfor_page);
        FWNumberlabel->setObjectName(QString::fromUtf8("FWNumberlabel"));
        FWNumberlabel->setGeometry(QRect(65, 430, 70, 50));
        FWNumberlabel->setMinimumSize(QSize(70, 50));
        FWNumberlabel->setMaximumSize(QSize(70, 50));
        FWNumberlabel->setFont(font8);
        FWNumberlabel->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 255);"));
        FWNumberlabel->setAlignment(Qt::AlignCenter);
        SNNumberlabel2 = new QLabel(DeviceInfor_page);
        SNNumberlabel2->setObjectName(QString::fromUtf8("SNNumberlabel2"));
        SNNumberlabel2->setGeometry(QRect(145, 295, 200, 50));
        SNNumberlabel2->setMinimumSize(QSize(200, 50));
        SNNumberlabel2->setMaximumSize(QSize(200, 50));
        SNNumberlabel2->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 255);"));
        SNNumberlabel2->setFrameShape(QFrame::Box);
        SNNumberlabel2->setAlignment(Qt::AlignCenter);
        SNNumberlabel = new QLabel(DeviceInfor_page);
        SNNumberlabel->setObjectName(QString::fromUtf8("SNNumberlabel"));
        SNNumberlabel->setGeometry(QRect(60, 295, 70, 50));
        SNNumberlabel->setMinimumSize(QSize(70, 50));
        SNNumberlabel->setMaximumSize(QSize(70, 50));
        SNNumberlabel->setFont(font8);
        SNNumberlabel->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 255);"));
        SNNumberlabel->setAlignment(Qt::AlignCenter);
        DeviceNamelabel2 = new QLabel(DeviceInfor_page);
        DeviceNamelabel2->setObjectName(QString::fromUtf8("DeviceNamelabel2"));
        DeviceNamelabel2->setGeometry(QRect(140, 175, 200, 50));
        DeviceNamelabel2->setMinimumSize(QSize(200, 50));
        DeviceNamelabel2->setMaximumSize(QSize(200, 50));
        DeviceNamelabel2->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 255);"));
        DeviceNamelabel2->setFrameShape(QFrame::Box);
        DeviceNamelabel2->setAlignment(Qt::AlignCenter);
        DeviceNamelabel = new QLabel(DeviceInfor_page);
        DeviceNamelabel->setObjectName(QString::fromUtf8("DeviceNamelabel"));
        DeviceNamelabel->setGeometry(QRect(65, 175, 70, 50));
        DeviceNamelabel->setMinimumSize(QSize(0, 0));
        DeviceNamelabel->setFont(font8);
        DeviceNamelabel->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 255);"));
        DeviceNamelabel->setAlignment(Qt::AlignCenter);
        stackedwidget->addWidget(DeviceInfor_page);
        page_2 = new QWidget();
        page_2->setObjectName(QString::fromUtf8("page_2"));
        Date_RetBtn = new QPushButton(page_2);
        Date_RetBtn->setObjectName(QString::fromUtf8("Date_RetBtn"));
        Date_RetBtn->setGeometry(QRect(15, 15, 70, 60));
        Date_RetBtn->setMinimumSize(QSize(70, 60));
        Date_RetBtn->setMaximumSize(QSize(70, 60));
        Date_RetBtn->setFocusPolicy(Qt::NoFocus);
        Datetips = new QLabel(page_2);
        Datetips->setObjectName(QString::fromUtf8("Datetips"));
        Datetips->setGeometry(QRect(140, 15, 200, 36));
        Datetips->setFont(font1);
        Datetips->setAlignment(Qt::AlignCenter);
        YearUpArrow = new QPushButton(page_2);
        YearUpArrow->setObjectName(QString::fromUtf8("YearUpArrow"));
        YearUpArrow->setGeometry(QRect(95, 130, 30, 30));
        YearDArrow = new QPushButton(page_2);
        YearDArrow->setObjectName(QString::fromUtf8("YearDArrow"));
        YearDArrow->setGeometry(QRect(100, 250, 30, 30));
        monthUpArrow = new QPushButton(page_2);
        monthUpArrow->setObjectName(QString::fromUtf8("monthUpArrow"));
        monthUpArrow->setGeometry(QRect(210, 130, 30, 30));
        monthDArrow = new QPushButton(page_2);
        monthDArrow->setObjectName(QString::fromUtf8("monthDArrow"));
        monthDArrow->setGeometry(QRect(210, 250, 30, 30));
        dateUpArrow = new QPushButton(page_2);
        dateUpArrow->setObjectName(QString::fromUtf8("dateUpArrow"));
        dateUpArrow->setGeometry(QRect(335, 130, 30, 30));
        dateDArrow = new QPushButton(page_2);
        dateDArrow->setObjectName(QString::fromUtf8("dateDArrow"));
        dateDArrow->setGeometry(QRect(335, 250, 30, 30));
        pushButton = new QPushButton(page_2);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(375, 30, 61, 41));
        pushButton->setFont(font6);
        YearCount = new QLabel(page_2);
        YearCount->setObjectName(QString::fromUtf8("YearCount"));
        YearCount->setGeometry(QRect(75, 185, 96, 36));
        YearCount->setFocusPolicy(Qt::NoFocus);
        YearCount->setFrameShape(QFrame::Box);
        YearCount->setAlignment(Qt::AlignCenter);
        stackedwidget->addWidget(page_2);

        retranslateUi(Widget);

        stackedwidget->setCurrentIndex(3);


        QMetaObject::connectSlotsByName(Widget);
    } // setupUi

    void retranslateUi(QWidget *Widget)
    {
        Widget->setWindowTitle(QApplication::translate("Widget", "Widget", 0, QApplication::UnicodeUTF8));
        dellBtn->setText(QApplication::translate("Widget", "\351\227\250\351\223\203", 0, QApplication::UnicodeUTF8));
        pswBtn->setText(QApplication::translate("Widget", "\345\257\206\347\240\201", 0, QApplication::UnicodeUTF8));
        setBtn->setText(QApplication::translate("Widget", "\350\256\276\347\275\256", 0, QApplication::UnicodeUTF8));
        menuBtn->setText(QApplication::translate("Widget", "\350\217\234\345\215\225", 0, QApplication::UnicodeUTF8));
        weekLabel->setText(QApplication::translate("Widget", "\346\230\237\346\234\237\344\270\200", 0, QApplication::UnicodeUTF8));
        dateLabel->setText(QApplication::translate("Widget", "05\346\234\21011\346\227\245", 0, QApplication::UnicodeUTF8));
        timeLabel->setText(QApplication::translate("Widget", "17:40", 0, QApplication::UnicodeUTF8));
        logoLabel->setText(QString());
        TitleCLabel->setText(QString());
        CStatus->setText(QString());
        userManageBtn->setText(QApplication::translate("Widget", "\347\224\250\346\210\267\347\256\241\347\220\206", 0, QApplication::UnicodeUTF8));
        menuRetBtn->setText(QString());
        sysInformationBtn->setText(QApplication::translate("Widget", "\350\256\276\345\244\207\344\277\241\346\201\257", 0, QApplication::UnicodeUTF8));
        MenuLabel->setText(QApplication::translate("Widget", "\344\270\273\350\217\234\345\215\225", 0, QApplication::UnicodeUTF8));
        LogQueryBtn->setText(QApplication::translate("Widget", "\346\227\245\345\277\227\346\237\245\350\257\242", 0, QApplication::UnicodeUTF8));
        AttendCheckBtn->setText(QApplication::translate("Widget", "\350\200\203\345\213\244\350\256\260\345\275\225", 0, QApplication::UnicodeUTF8));
        newFingerBtn->setText(QApplication::translate("Widget", "\346\226\260\345\242\236\346\214\207\351\235\231\350\204\211\347\224\250\346\210\267", 0, QApplication::UnicodeUTF8));
        userManageRetBtn->setText(QString());
        FindUserBtn->setText(QApplication::translate("Widget", "\346\237\245\350\257\242\346\214\207\351\235\231\350\204\211\347\224\250\346\210\267", 0, QApplication::UnicodeUTF8));
        UMLabel->setText(QApplication::translate("Widget", "\347\224\250\346\210\267\347\256\241\347\220\206", 0, QApplication::UnicodeUTF8));
        FingerMap->setText(QApplication::translate("Widget", "fingerMap", 0, QApplication::UnicodeUTF8));
        TitleRLabel->setText(QString());
        pswLabel->setText(QApplication::translate("Widget", "\345\257\206\347\240\201", 0, QApplication::UnicodeUTF8));
        authorityLabel->setText(QApplication::translate("Widget", "\346\235\203\351\231\220", 0, QApplication::UnicodeUTF8));
        departLabel->setText(QApplication::translate("Widget", "\351\203\250\351\227\250", 0, QApplication::UnicodeUTF8));
        nameLabel->setText(QApplication::translate("Widget", "\345\247\223\345\220\215", 0, QApplication::UnicodeUTF8));
        workNumLabel->setText(QApplication::translate("Widget", "\345\267\245\345\217\267", 0, QApplication::UnicodeUTF8));
        newFingerRetBtn->setText(QString());
        captureButton->setText(QApplication::translate("Widget", "capture", 0, QApplication::UnicodeUTF8));
        showTableRetBtn->setText(QString());
        QTableWidgetItem *___qtablewidgetitem = table->horizontalHeaderItem(0);
        ___qtablewidgetitem->setText(QApplication::translate("Widget", "\345\267\245\345\217\267", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem1 = table->horizontalHeaderItem(1);
        ___qtablewidgetitem1->setText(QApplication::translate("Widget", "\345\247\223 \345\220\215", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem2 = table->horizontalHeaderItem(2);
        ___qtablewidgetitem2->setText(QApplication::translate("Widget", "\351\203\250  \351\227\250", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem3 = table->horizontalHeaderItem(3);
        ___qtablewidgetitem3->setText(QApplication::translate("Widget", "\346\235\203\351\231\220", 0, QApplication::UnicodeUTF8));
        FindLabel->setText(QApplication::translate("Widget", "\346\237\245\350\257\242\346\214\207\351\235\231\350\204\211\347\224\250\346\210\267", 0, QApplication::UnicodeUTF8));
        DetailBtn->setText(QApplication::translate("Widget", "\350\257\246\347\273\206", 0, QApplication::UnicodeUTF8));
        groupBox->setTitle(QApplication::translate("Widget", "\350\257\267\351\252\214\350\257\201\347\256\241\347\220\206\345\221\230", 0, QApplication::UnicodeUTF8));
        SuperUserstatusLabel->setText(QApplication::translate("Widget", "\347\256\241\347\220\206\345\221\230\351\252\214\350\257\201\347\212\266\346\200\201", 0, QApplication::UnicodeUTF8));
        groupBox_3->setTitle(QApplication::translate("Widget", "\345\257\206\347\240\201\351\252\214\350\257\201", 0, QApplication::UnicodeUTF8));
        SuperuserPsw_Input->setText(QString());
        set_retBtn->setText(QString());
        communcationSet->setText(QApplication::translate("Widget", "\351\200\232\350\256\257\350\256\276\347\275\256", 0, QApplication::UnicodeUTF8));
        logFind->setText(QApplication::translate("Widget", "\346\227\245\345\277\227\346\237\245\350\257\242", 0, QApplication::UnicodeUTF8));
        SetLabel->setText(QApplication::translate("Widget", "\350\256\276\347\275\256", 0, QApplication::UnicodeUTF8));
        TimeSet->setText(QApplication::translate("Widget", "\346\227\266\351\227\264\350\256\276\347\275\256", 0, QApplication::UnicodeUTF8));
        IPSetBtn->setText(QApplication::translate("Widget", "\347\275\221\347\273\234IP\350\256\276\347\275\256", 0, QApplication::UnicodeUTF8));
        UartSetBtn->setText(QApplication::translate("Widget", "\344\270\262\345\217\243\350\256\276\347\275\256", 0, QApplication::UnicodeUTF8));
        CommuSet_retBtn->setText(QString());
        ComunateSetLabel->setText(QApplication::translate("Widget", "\351\200\232\350\256\257\350\256\276\347\275\256", 0, QApplication::UnicodeUTF8));
        TimeSetLabel->setText(QApplication::translate("Widget", "\346\227\266\351\227\264\350\256\276\347\275\256", 0, QApplication::UnicodeUTF8));
        TimeSet_ret->setText(QString());
        DateSetLabel->setText(QApplication::translate("Widget", "\350\256\276\347\275\256\346\227\245\346\234\237", 0, QApplication::UnicodeUTF8));
        SetTimeLabel->setText(QApplication::translate("Widget", "\350\256\276\347\275\256\346\227\266\351\227\264", 0, QApplication::UnicodeUTF8));
        DateSetBtn->setText(QApplication::translate("Widget", "2017-10-24", 0, QApplication::UnicodeUTF8));
        TimeSetBtn->setText(QApplication::translate("Widget", "11:02:16", 0, QApplication::UnicodeUTF8));
        groupBox_2->setTitle(QApplication::translate("Widget", "\350\256\276\347\275\256IP", 0, QApplication::UnicodeUTF8));
        deviceIPBtn->setText(QApplication::translate("Widget", "\346\234\254\345\234\260IP", 0, QApplication::UnicodeUTF8));
        serverIPBtn->setText(QApplication::translate("Widget", "\346\234\215\345\212\241\345\231\250IP", 0, QApplication::UnicodeUTF8));
        IPsetOkBtn->setText(QApplication::translate("Widget", "\347\241\256\345\256\232", 0, QApplication::UnicodeUTF8));
        IPInputlabel->setText(QApplication::translate("Widget", "\350\257\267\350\276\223\345\205\245IP", 0, QApplication::UnicodeUTF8));
        IPInputEdit->setText(QString());
        setIP_retBtn->setText(QString());
        IpSetLabel->setText(QApplication::translate("Widget", "\350\256\276\347\275\256IP", 0, QApplication::UnicodeUTF8));
        DeviceInfor_retBtn->setText(QString());
        IDNumberlabel2->setText(QString());
        IDNumberlabel->setText(QApplication::translate("Widget", "ID\345\217\267", 0, QApplication::UnicodeUTF8));
        FWNumberlabel2->setText(QString());
        FWNumberlabel->setText(QApplication::translate("Widget", "FW\345\217\267", 0, QApplication::UnicodeUTF8));
        SNNumberlabel2->setText(QString());
        SNNumberlabel->setText(QApplication::translate("Widget", "SN\345\217\267", 0, QApplication::UnicodeUTF8));
        DeviceNamelabel2->setText(QString());
        DeviceNamelabel->setText(QApplication::translate("Widget", "\350\256\276\345\244\207", 0, QApplication::UnicodeUTF8));
        Date_RetBtn->setText(QString());
        Datetips->setText(QApplication::translate("Widget", "\350\256\276\347\275\256\346\227\245\346\234\237", 0, QApplication::UnicodeUTF8));
        YearUpArrow->setText(QString());
        YearDArrow->setText(QString());
        monthUpArrow->setText(QString());
        monthDArrow->setText(QString());
        dateUpArrow->setText(QString());
        dateDArrow->setText(QString());
        pushButton->setText(QApplication::translate("Widget", "\347\241\256\345\256\232", 0, QApplication::UnicodeUTF8));
        YearCount->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class Widget: public Ui_Widget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_WIDGET_H

#ifndef TGIMAGEENCRYPTDECRYPT_H
#define TGIMAGEENCRYPTDECRYPT_H


void TGImageEncryptDecrypt(unsigned char *image,int length);

#endif

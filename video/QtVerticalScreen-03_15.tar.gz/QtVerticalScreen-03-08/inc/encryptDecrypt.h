#ifndef ENCRYPTDECRYPT_H
#define ENCRYPTDECRYPT_H

int encryptDecrypt(unsigned char * registerData,int flag);

#endif
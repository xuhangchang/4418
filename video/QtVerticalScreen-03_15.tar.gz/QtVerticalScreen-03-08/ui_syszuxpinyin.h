/********************************************************************************
** Form generated from reading UI file 'syszuxpinyin.ui'
**
** Created by: Qt User Interface Compiler version 4.8.7
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SYSZUXPINYIN_H
#define UI_SYSZUXPINYIN_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QDialog>
#include <QtGui/QFrame>
#include <QtGui/QGridLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QLineEdit>
#include <QtGui/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_Dialog
{
public:
    QLineEdit *lineEdit_window;
    QFrame *gridFrame;
    QGridLayout *gridLayout_4;
    QPushButton *pushButton_right;
    QPushButton *pushButton_quote;
    QPushButton *pushButton_h;
    QPushButton *pushButton_f;
    QPushButton *pushButton_hanzi_right;
    QPushButton *pushButton_semicolon;
    QPushButton *pushButton_g;
    QPushButton *pushButton_hanzi_2;
    QPushButton *pushButton_hanzi_6;
    QPushButton *pushButton_j;
    QPushButton *pushButton_hanzi_left;
    QPushButton *pushButton_m;
    QPushButton *pushButton_zuokuo;
    QPushButton *pushButton_is_hanzi;
    QPushButton *pushButton_t;
    QPushButton *pushButton_k;
    QPushButton *pushButton_n1;
    QPushButton *pushButton_n;
    QPushButton *pushButton_x;
    QPushButton *pushButton_l;
    QPushButton *pushButton_a;
    QPushButton *pushButton_z;
    QPushButton *pushButton_v;
    QPushButton *pushButton_u;
    QPushButton *pushButton_hanzi_8;
    QPushButton *pushButton_s;
    QPushButton *pushButton_o;
    QPushButton *pushButton_d;
    QPushButton *pushButton_n2;
    QPushButton *pushButton_hanzi_7;
    QPushButton *pushButton_n9;
    QPushButton *pushButton_b;
    QPushButton *pushButton_comma;
    QPushButton *pushButton_hanzi_4;
    QPushButton *pushButton_period;
    QPushButton *pushButton_splash;
    QPushButton *pushButton_n7;
    QPushButton *pushButton_n8;
    QPushButton *pushButton_n0;
    QPushButton *pushButton_n5;
    QPushButton *pushButton_n4;
    QPushButton *pushButton_n6;
    QPushButton *pushButton_n3;
    QPushButton *pushButton_w;
    QPushButton *pushButton_deng;
    QPushButton *pushButton_hanzi_5;
    QPushButton *pushButton_q;
    QPushButton *pushButton_r;
    QPushButton *pushButton_backspace;
    QPushButton *pushButton_y;
    QPushButton *pushButton_e;
    QPushButton *pushButton_backsplash;
    QPushButton *pushButton_i;
    QPushButton *pushButton_hanzi_3;
    QPushButton *pushButton_youkuo;
    QPushButton *pushButton_p;
    QPushButton *pushButton_up;
    QPushButton *pushButton_shift;
    QPushButton *pushButton_enter;
    QPushButton *pushButton_down;
    QPushButton *pushButton_ok;
    QPushButton *pushButton_c;
    QPushButton *pushButton_whitespace;
    QPushButton *pushButton_left;
    QPushButton *pushButton_hanzi_1;
    QPushButton *pushButton_gang;
    QLineEdit *lineEdit_pinyin;

    void setupUi(QDialog *Dialog)
    {
        if (Dialog->objectName().isEmpty())
            Dialog->setObjectName(QString::fromUtf8("Dialog"));
        Dialog->resize(476, 222);
        Dialog->setMinimumSize(QSize(476, 222));
        Dialog->setMaximumSize(QSize(476, 222));
        lineEdit_window = new QLineEdit(Dialog);
        lineEdit_window->setObjectName(QString::fromUtf8("lineEdit_window"));
        lineEdit_window->setGeometry(QRect(0, 0, 480, 35));
        QSizePolicy sizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(lineEdit_window->sizePolicy().hasHeightForWidth());
        lineEdit_window->setSizePolicy(sizePolicy);
        QFont font;
        font.setPointSize(21);
        font.setBold(true);
        font.setWeight(75);
        lineEdit_window->setFont(font);
        lineEdit_window->setFrame(false);
        gridFrame = new QFrame(Dialog);
        gridFrame->setObjectName(QString::fromUtf8("gridFrame"));
        gridFrame->setGeometry(QRect(0, 30, 480, 191));
        gridLayout_4 = new QGridLayout(gridFrame);
        gridLayout_4->setSpacing(0);
        gridLayout_4->setObjectName(QString::fromUtf8("gridLayout_4"));
        gridLayout_4->setContentsMargins(0, 0, 0, 0);
        pushButton_right = new QPushButton(gridFrame);
        pushButton_right->setObjectName(QString::fromUtf8("pushButton_right"));
        QSizePolicy sizePolicy1(QSizePolicy::Minimum, QSizePolicy::Expanding);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(pushButton_right->sizePolicy().hasHeightForWidth());
        pushButton_right->setSizePolicy(sizePolicy1);
        QFont font1;
        font1.setPointSize(20);
        font1.setBold(true);
        font1.setWeight(75);
        pushButton_right->setFont(font1);

        gridLayout_4->addWidget(pushButton_right, 3, 13, 1, 1);

        pushButton_quote = new QPushButton(gridFrame);
        pushButton_quote->setObjectName(QString::fromUtf8("pushButton_quote"));
        sizePolicy1.setHeightForWidth(pushButton_quote->sizePolicy().hasHeightForWidth());
        pushButton_quote->setSizePolicy(sizePolicy1);
        QPalette palette;
        QBrush brush(QColor(85, 170, 255, 255));
        brush.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Button, brush);
        palette.setBrush(QPalette::Inactive, QPalette::Button, brush);
        palette.setBrush(QPalette::Disabled, QPalette::Button, brush);
        pushButton_quote->setPalette(palette);
        pushButton_quote->setFont(font1);

        gridLayout_4->addWidget(pushButton_quote, 3, 10, 1, 1);

        pushButton_h = new QPushButton(gridFrame);
        pushButton_h->setObjectName(QString::fromUtf8("pushButton_h"));
        sizePolicy1.setHeightForWidth(pushButton_h->sizePolicy().hasHeightForWidth());
        pushButton_h->setSizePolicy(sizePolicy1);
        QPalette palette1;
        palette1.setBrush(QPalette::Active, QPalette::Button, brush);
        palette1.setBrush(QPalette::Inactive, QPalette::Button, brush);
        palette1.setBrush(QPalette::Disabled, QPalette::Button, brush);
        pushButton_h->setPalette(palette1);
        pushButton_h->setFont(font1);

        gridLayout_4->addWidget(pushButton_h, 3, 5, 1, 1);

        pushButton_f = new QPushButton(gridFrame);
        pushButton_f->setObjectName(QString::fromUtf8("pushButton_f"));
        sizePolicy1.setHeightForWidth(pushButton_f->sizePolicy().hasHeightForWidth());
        pushButton_f->setSizePolicy(sizePolicy1);
        QPalette palette2;
        palette2.setBrush(QPalette::Active, QPalette::Button, brush);
        palette2.setBrush(QPalette::Inactive, QPalette::Button, brush);
        palette2.setBrush(QPalette::Disabled, QPalette::Button, brush);
        pushButton_f->setPalette(palette2);
        pushButton_f->setFont(font1);

        gridLayout_4->addWidget(pushButton_f, 3, 3, 1, 1);

        pushButton_hanzi_right = new QPushButton(gridFrame);
        pushButton_hanzi_right->setObjectName(QString::fromUtf8("pushButton_hanzi_right"));
        sizePolicy1.setHeightForWidth(pushButton_hanzi_right->sizePolicy().hasHeightForWidth());
        pushButton_hanzi_right->setSizePolicy(sizePolicy1);
        QPalette palette3;
        palette3.setBrush(QPalette::Active, QPalette::Button, brush);
        palette3.setBrush(QPalette::Inactive, QPalette::Button, brush);
        palette3.setBrush(QPalette::Disabled, QPalette::Button, brush);
        pushButton_hanzi_right->setPalette(palette3);
        pushButton_hanzi_right->setFont(font1);

        gridLayout_4->addWidget(pushButton_hanzi_right, 0, 9, 1, 1);

        pushButton_semicolon = new QPushButton(gridFrame);
        pushButton_semicolon->setObjectName(QString::fromUtf8("pushButton_semicolon"));
        sizePolicy1.setHeightForWidth(pushButton_semicolon->sizePolicy().hasHeightForWidth());
        pushButton_semicolon->setSizePolicy(sizePolicy1);
        QPalette palette4;
        palette4.setBrush(QPalette::Active, QPalette::Button, brush);
        palette4.setBrush(QPalette::Inactive, QPalette::Button, brush);
        palette4.setBrush(QPalette::Disabled, QPalette::Button, brush);
        pushButton_semicolon->setPalette(palette4);
        pushButton_semicolon->setFont(font1);

        gridLayout_4->addWidget(pushButton_semicolon, 3, 9, 1, 1);

        pushButton_g = new QPushButton(gridFrame);
        pushButton_g->setObjectName(QString::fromUtf8("pushButton_g"));
        sizePolicy1.setHeightForWidth(pushButton_g->sizePolicy().hasHeightForWidth());
        pushButton_g->setSizePolicy(sizePolicy1);
        QPalette palette5;
        palette5.setBrush(QPalette::Active, QPalette::Button, brush);
        palette5.setBrush(QPalette::Inactive, QPalette::Button, brush);
        palette5.setBrush(QPalette::Disabled, QPalette::Button, brush);
        pushButton_g->setPalette(palette5);
        pushButton_g->setFont(font1);

        gridLayout_4->addWidget(pushButton_g, 3, 4, 1, 1);

        pushButton_hanzi_2 = new QPushButton(gridFrame);
        pushButton_hanzi_2->setObjectName(QString::fromUtf8("pushButton_hanzi_2"));
        sizePolicy1.setHeightForWidth(pushButton_hanzi_2->sizePolicy().hasHeightForWidth());
        pushButton_hanzi_2->setSizePolicy(sizePolicy1);
        QPalette palette6;
        palette6.setBrush(QPalette::Active, QPalette::Button, brush);
        palette6.setBrush(QPalette::Inactive, QPalette::Button, brush);
        palette6.setBrush(QPalette::Disabled, QPalette::Button, brush);
        pushButton_hanzi_2->setPalette(palette6);
        QFont font2;
        font2.setPointSize(15);
        font2.setBold(true);
        font2.setWeight(75);
        pushButton_hanzi_2->setFont(font2);

        gridLayout_4->addWidget(pushButton_hanzi_2, 0, 1, 1, 1);

        pushButton_hanzi_6 = new QPushButton(gridFrame);
        pushButton_hanzi_6->setObjectName(QString::fromUtf8("pushButton_hanzi_6"));
        sizePolicy1.setHeightForWidth(pushButton_hanzi_6->sizePolicy().hasHeightForWidth());
        pushButton_hanzi_6->setSizePolicy(sizePolicy1);
        QPalette palette7;
        palette7.setBrush(QPalette::Active, QPalette::Button, brush);
        palette7.setBrush(QPalette::Inactive, QPalette::Button, brush);
        palette7.setBrush(QPalette::Disabled, QPalette::Button, brush);
        pushButton_hanzi_6->setPalette(palette7);
        pushButton_hanzi_6->setFont(font2);

        gridLayout_4->addWidget(pushButton_hanzi_6, 0, 5, 1, 1);

        pushButton_j = new QPushButton(gridFrame);
        pushButton_j->setObjectName(QString::fromUtf8("pushButton_j"));
        sizePolicy1.setHeightForWidth(pushButton_j->sizePolicy().hasHeightForWidth());
        pushButton_j->setSizePolicy(sizePolicy1);
        QPalette palette8;
        palette8.setBrush(QPalette::Active, QPalette::Button, brush);
        palette8.setBrush(QPalette::Inactive, QPalette::Button, brush);
        palette8.setBrush(QPalette::Disabled, QPalette::Button, brush);
        pushButton_j->setPalette(palette8);
        pushButton_j->setFont(font1);

        gridLayout_4->addWidget(pushButton_j, 3, 6, 1, 1);

        pushButton_hanzi_left = new QPushButton(gridFrame);
        pushButton_hanzi_left->setObjectName(QString::fromUtf8("pushButton_hanzi_left"));
        sizePolicy1.setHeightForWidth(pushButton_hanzi_left->sizePolicy().hasHeightForWidth());
        pushButton_hanzi_left->setSizePolicy(sizePolicy1);
        QPalette palette9;
        QBrush brush1(QColor(0, 0, 0, 255));
        brush1.setStyle(Qt::SolidPattern);
        palette9.setBrush(QPalette::Active, QPalette::WindowText, brush1);
        palette9.setBrush(QPalette::Active, QPalette::Button, brush);
        QBrush brush2(QColor(255, 255, 255, 255));
        brush2.setStyle(Qt::SolidPattern);
        palette9.setBrush(QPalette::Active, QPalette::Light, brush2);
        palette9.setBrush(QPalette::Active, QPalette::Midlight, brush2);
        QBrush brush3(QColor(127, 127, 127, 255));
        brush3.setStyle(Qt::SolidPattern);
        palette9.setBrush(QPalette::Active, QPalette::Dark, brush3);
        QBrush brush4(QColor(170, 170, 170, 255));
        brush4.setStyle(Qt::SolidPattern);
        palette9.setBrush(QPalette::Active, QPalette::Mid, brush4);
        palette9.setBrush(QPalette::Active, QPalette::Text, brush1);
        palette9.setBrush(QPalette::Active, QPalette::BrightText, brush2);
        palette9.setBrush(QPalette::Active, QPalette::ButtonText, brush1);
        palette9.setBrush(QPalette::Active, QPalette::Base, brush2);
        palette9.setBrush(QPalette::Active, QPalette::Window, brush2);
        palette9.setBrush(QPalette::Active, QPalette::Shadow, brush1);
        palette9.setBrush(QPalette::Active, QPalette::AlternateBase, brush2);
        QBrush brush5(QColor(255, 255, 220, 255));
        brush5.setStyle(Qt::SolidPattern);
        palette9.setBrush(QPalette::Active, QPalette::ToolTipBase, brush5);
        palette9.setBrush(QPalette::Active, QPalette::ToolTipText, brush1);
        palette9.setBrush(QPalette::Inactive, QPalette::WindowText, brush1);
        palette9.setBrush(QPalette::Inactive, QPalette::Button, brush);
        palette9.setBrush(QPalette::Inactive, QPalette::Light, brush2);
        palette9.setBrush(QPalette::Inactive, QPalette::Midlight, brush2);
        palette9.setBrush(QPalette::Inactive, QPalette::Dark, brush3);
        palette9.setBrush(QPalette::Inactive, QPalette::Mid, brush4);
        palette9.setBrush(QPalette::Inactive, QPalette::Text, brush1);
        palette9.setBrush(QPalette::Inactive, QPalette::BrightText, brush2);
        palette9.setBrush(QPalette::Inactive, QPalette::ButtonText, brush1);
        palette9.setBrush(QPalette::Inactive, QPalette::Base, brush2);
        palette9.setBrush(QPalette::Inactive, QPalette::Window, brush2);
        palette9.setBrush(QPalette::Inactive, QPalette::Shadow, brush1);
        palette9.setBrush(QPalette::Inactive, QPalette::AlternateBase, brush2);
        palette9.setBrush(QPalette::Inactive, QPalette::ToolTipBase, brush5);
        palette9.setBrush(QPalette::Inactive, QPalette::ToolTipText, brush1);
        palette9.setBrush(QPalette::Disabled, QPalette::WindowText, brush3);
        palette9.setBrush(QPalette::Disabled, QPalette::Button, brush);
        palette9.setBrush(QPalette::Disabled, QPalette::Light, brush2);
        palette9.setBrush(QPalette::Disabled, QPalette::Midlight, brush2);
        palette9.setBrush(QPalette::Disabled, QPalette::Dark, brush3);
        palette9.setBrush(QPalette::Disabled, QPalette::Mid, brush4);
        palette9.setBrush(QPalette::Disabled, QPalette::Text, brush3);
        palette9.setBrush(QPalette::Disabled, QPalette::BrightText, brush2);
        palette9.setBrush(QPalette::Disabled, QPalette::ButtonText, brush3);
        palette9.setBrush(QPalette::Disabled, QPalette::Base, brush2);
        palette9.setBrush(QPalette::Disabled, QPalette::Window, brush2);
        palette9.setBrush(QPalette::Disabled, QPalette::Shadow, brush1);
        palette9.setBrush(QPalette::Disabled, QPalette::AlternateBase, brush2);
        palette9.setBrush(QPalette::Disabled, QPalette::ToolTipBase, brush5);
        palette9.setBrush(QPalette::Disabled, QPalette::ToolTipText, brush1);
        pushButton_hanzi_left->setPalette(palette9);
        pushButton_hanzi_left->setFont(font1);

        gridLayout_4->addWidget(pushButton_hanzi_left, 0, 8, 1, 1);

        pushButton_m = new QPushButton(gridFrame);
        pushButton_m->setObjectName(QString::fromUtf8("pushButton_m"));
        sizePolicy1.setHeightForWidth(pushButton_m->sizePolicy().hasHeightForWidth());
        pushButton_m->setSizePolicy(sizePolicy1);
        QPalette palette10;
        palette10.setBrush(QPalette::Active, QPalette::Button, brush);
        palette10.setBrush(QPalette::Inactive, QPalette::Button, brush);
        palette10.setBrush(QPalette::Disabled, QPalette::Button, brush);
        pushButton_m->setPalette(palette10);
        pushButton_m->setFont(font1);

        gridLayout_4->addWidget(pushButton_m, 4, 6, 1, 1);

        pushButton_zuokuo = new QPushButton(gridFrame);
        pushButton_zuokuo->setObjectName(QString::fromUtf8("pushButton_zuokuo"));
        sizePolicy1.setHeightForWidth(pushButton_zuokuo->sizePolicy().hasHeightForWidth());
        pushButton_zuokuo->setSizePolicy(sizePolicy1);
        QPalette palette11;
        palette11.setBrush(QPalette::Active, QPalette::Button, brush);
        palette11.setBrush(QPalette::Inactive, QPalette::Button, brush);
        palette11.setBrush(QPalette::Disabled, QPalette::Button, brush);
        pushButton_zuokuo->setPalette(palette11);
        pushButton_zuokuo->setFont(font1);

        gridLayout_4->addWidget(pushButton_zuokuo, 2, 10, 1, 1);

        pushButton_is_hanzi = new QPushButton(gridFrame);
        pushButton_is_hanzi->setObjectName(QString::fromUtf8("pushButton_is_hanzi"));
        sizePolicy1.setHeightForWidth(pushButton_is_hanzi->sizePolicy().hasHeightForWidth());
        pushButton_is_hanzi->setSizePolicy(sizePolicy1);
        QPalette palette12;
        palette12.setBrush(QPalette::Active, QPalette::Button, brush);
        palette12.setBrush(QPalette::Inactive, QPalette::Button, brush);
        palette12.setBrush(QPalette::Disabled, QPalette::Button, brush);
        pushButton_is_hanzi->setPalette(palette12);
        QFont font3;
        font3.setPointSize(10);
        font3.setBold(true);
        font3.setWeight(75);
        pushButton_is_hanzi->setFont(font3);

        gridLayout_4->addWidget(pushButton_is_hanzi, 4, 11, 1, 1);

        pushButton_t = new QPushButton(gridFrame);
        pushButton_t->setObjectName(QString::fromUtf8("pushButton_t"));
        sizePolicy1.setHeightForWidth(pushButton_t->sizePolicy().hasHeightForWidth());
        pushButton_t->setSizePolicy(sizePolicy1);
        QPalette palette13;
        palette13.setBrush(QPalette::Active, QPalette::Button, brush);
        palette13.setBrush(QPalette::Inactive, QPalette::Button, brush);
        palette13.setBrush(QPalette::Disabled, QPalette::Button, brush);
        pushButton_t->setPalette(palette13);
        pushButton_t->setFont(font1);

        gridLayout_4->addWidget(pushButton_t, 2, 4, 1, 1);

        pushButton_k = new QPushButton(gridFrame);
        pushButton_k->setObjectName(QString::fromUtf8("pushButton_k"));
        sizePolicy1.setHeightForWidth(pushButton_k->sizePolicy().hasHeightForWidth());
        pushButton_k->setSizePolicy(sizePolicy1);
        QPalette palette14;
        palette14.setBrush(QPalette::Active, QPalette::Button, brush);
        palette14.setBrush(QPalette::Inactive, QPalette::Button, brush);
        palette14.setBrush(QPalette::Disabled, QPalette::Button, brush);
        pushButton_k->setPalette(palette14);
        pushButton_k->setFont(font1);

        gridLayout_4->addWidget(pushButton_k, 3, 7, 1, 1);

        pushButton_n1 = new QPushButton(gridFrame);
        pushButton_n1->setObjectName(QString::fromUtf8("pushButton_n1"));
        sizePolicy1.setHeightForWidth(pushButton_n1->sizePolicy().hasHeightForWidth());
        pushButton_n1->setSizePolicy(sizePolicy1);
        QPalette palette15;
        palette15.setBrush(QPalette::Active, QPalette::Button, brush);
        palette15.setBrush(QPalette::Inactive, QPalette::Button, brush);
        palette15.setBrush(QPalette::Disabled, QPalette::Button, brush);
        pushButton_n1->setPalette(palette15);
        pushButton_n1->setFont(font1);
        pushButton_n1->setFocusPolicy(Qt::ClickFocus);

        gridLayout_4->addWidget(pushButton_n1, 1, 0, 1, 1);

        pushButton_n = new QPushButton(gridFrame);
        pushButton_n->setObjectName(QString::fromUtf8("pushButton_n"));
        sizePolicy1.setHeightForWidth(pushButton_n->sizePolicy().hasHeightForWidth());
        pushButton_n->setSizePolicy(sizePolicy1);
        QPalette palette16;
        palette16.setBrush(QPalette::Active, QPalette::Button, brush);
        palette16.setBrush(QPalette::Inactive, QPalette::Button, brush);
        palette16.setBrush(QPalette::Disabled, QPalette::Button, brush);
        pushButton_n->setPalette(palette16);
        pushButton_n->setFont(font1);

        gridLayout_4->addWidget(pushButton_n, 4, 5, 1, 1);

        pushButton_x = new QPushButton(gridFrame);
        pushButton_x->setObjectName(QString::fromUtf8("pushButton_x"));
        sizePolicy1.setHeightForWidth(pushButton_x->sizePolicy().hasHeightForWidth());
        pushButton_x->setSizePolicy(sizePolicy1);
        QPalette palette17;
        palette17.setBrush(QPalette::Active, QPalette::Button, brush);
        palette17.setBrush(QPalette::Inactive, QPalette::Button, brush);
        palette17.setBrush(QPalette::Disabled, QPalette::Button, brush);
        pushButton_x->setPalette(palette17);
        pushButton_x->setFont(font1);

        gridLayout_4->addWidget(pushButton_x, 4, 1, 1, 1);

        pushButton_l = new QPushButton(gridFrame);
        pushButton_l->setObjectName(QString::fromUtf8("pushButton_l"));
        sizePolicy1.setHeightForWidth(pushButton_l->sizePolicy().hasHeightForWidth());
        pushButton_l->setSizePolicy(sizePolicy1);
        QPalette palette18;
        palette18.setBrush(QPalette::Active, QPalette::Button, brush);
        palette18.setBrush(QPalette::Inactive, QPalette::Button, brush);
        palette18.setBrush(QPalette::Disabled, QPalette::Button, brush);
        pushButton_l->setPalette(palette18);
        pushButton_l->setFont(font1);

        gridLayout_4->addWidget(pushButton_l, 3, 8, 1, 1);

        pushButton_a = new QPushButton(gridFrame);
        pushButton_a->setObjectName(QString::fromUtf8("pushButton_a"));
        sizePolicy1.setHeightForWidth(pushButton_a->sizePolicy().hasHeightForWidth());
        pushButton_a->setSizePolicy(sizePolicy1);
        QPalette palette19;
        palette19.setBrush(QPalette::Active, QPalette::Button, brush);
        palette19.setBrush(QPalette::Inactive, QPalette::Button, brush);
        palette19.setBrush(QPalette::Disabled, QPalette::Button, brush);
        pushButton_a->setPalette(palette19);
        pushButton_a->setFont(font1);

        gridLayout_4->addWidget(pushButton_a, 3, 0, 1, 1);

        pushButton_z = new QPushButton(gridFrame);
        pushButton_z->setObjectName(QString::fromUtf8("pushButton_z"));
        sizePolicy1.setHeightForWidth(pushButton_z->sizePolicy().hasHeightForWidth());
        pushButton_z->setSizePolicy(sizePolicy1);
        QPalette palette20;
        palette20.setBrush(QPalette::Active, QPalette::Button, brush);
        palette20.setBrush(QPalette::Inactive, QPalette::Button, brush);
        palette20.setBrush(QPalette::Disabled, QPalette::Button, brush);
        pushButton_z->setPalette(palette20);
        pushButton_z->setFont(font1);

        gridLayout_4->addWidget(pushButton_z, 4, 0, 1, 1);

        pushButton_v = new QPushButton(gridFrame);
        pushButton_v->setObjectName(QString::fromUtf8("pushButton_v"));
        sizePolicy1.setHeightForWidth(pushButton_v->sizePolicy().hasHeightForWidth());
        pushButton_v->setSizePolicy(sizePolicy1);
        QPalette palette21;
        palette21.setBrush(QPalette::Active, QPalette::Button, brush);
        palette21.setBrush(QPalette::Inactive, QPalette::Button, brush);
        palette21.setBrush(QPalette::Disabled, QPalette::Button, brush);
        pushButton_v->setPalette(palette21);
        pushButton_v->setFont(font1);

        gridLayout_4->addWidget(pushButton_v, 4, 3, 1, 1);

        pushButton_u = new QPushButton(gridFrame);
        pushButton_u->setObjectName(QString::fromUtf8("pushButton_u"));
        sizePolicy1.setHeightForWidth(pushButton_u->sizePolicy().hasHeightForWidth());
        pushButton_u->setSizePolicy(sizePolicy1);
        QPalette palette22;
        palette22.setBrush(QPalette::Active, QPalette::Button, brush);
        palette22.setBrush(QPalette::Inactive, QPalette::Button, brush);
        palette22.setBrush(QPalette::Disabled, QPalette::Button, brush);
        pushButton_u->setPalette(palette22);
        pushButton_u->setFont(font1);

        gridLayout_4->addWidget(pushButton_u, 2, 6, 1, 1);

        pushButton_hanzi_8 = new QPushButton(gridFrame);
        pushButton_hanzi_8->setObjectName(QString::fromUtf8("pushButton_hanzi_8"));
        sizePolicy1.setHeightForWidth(pushButton_hanzi_8->sizePolicy().hasHeightForWidth());
        pushButton_hanzi_8->setSizePolicy(sizePolicy1);
        QPalette palette23;
        palette23.setBrush(QPalette::Active, QPalette::Button, brush);
        palette23.setBrush(QPalette::Inactive, QPalette::Button, brush);
        palette23.setBrush(QPalette::Disabled, QPalette::Button, brush);
        pushButton_hanzi_8->setPalette(palette23);
        pushButton_hanzi_8->setFont(font2);

        gridLayout_4->addWidget(pushButton_hanzi_8, 0, 7, 1, 1);

        pushButton_s = new QPushButton(gridFrame);
        pushButton_s->setObjectName(QString::fromUtf8("pushButton_s"));
        sizePolicy1.setHeightForWidth(pushButton_s->sizePolicy().hasHeightForWidth());
        pushButton_s->setSizePolicy(sizePolicy1);
        QPalette palette24;
        palette24.setBrush(QPalette::Active, QPalette::Button, brush);
        palette24.setBrush(QPalette::Inactive, QPalette::Button, brush);
        palette24.setBrush(QPalette::Disabled, QPalette::Button, brush);
        pushButton_s->setPalette(palette24);
        pushButton_s->setFont(font1);

        gridLayout_4->addWidget(pushButton_s, 3, 1, 1, 1);

        pushButton_o = new QPushButton(gridFrame);
        pushButton_o->setObjectName(QString::fromUtf8("pushButton_o"));
        sizePolicy1.setHeightForWidth(pushButton_o->sizePolicy().hasHeightForWidth());
        pushButton_o->setSizePolicy(sizePolicy1);
        QPalette palette25;
        palette25.setBrush(QPalette::Active, QPalette::Button, brush);
        palette25.setBrush(QPalette::Inactive, QPalette::Button, brush);
        palette25.setBrush(QPalette::Disabled, QPalette::Button, brush);
        pushButton_o->setPalette(palette25);
        pushButton_o->setFont(font1);

        gridLayout_4->addWidget(pushButton_o, 2, 8, 1, 1);

        pushButton_d = new QPushButton(gridFrame);
        pushButton_d->setObjectName(QString::fromUtf8("pushButton_d"));
        sizePolicy1.setHeightForWidth(pushButton_d->sizePolicy().hasHeightForWidth());
        pushButton_d->setSizePolicy(sizePolicy1);
        QPalette palette26;
        palette26.setBrush(QPalette::Active, QPalette::Button, brush);
        palette26.setBrush(QPalette::Inactive, QPalette::Button, brush);
        palette26.setBrush(QPalette::Disabled, QPalette::Button, brush);
        pushButton_d->setPalette(palette26);
        pushButton_d->setFont(font1);

        gridLayout_4->addWidget(pushButton_d, 3, 2, 1, 1);

        pushButton_n2 = new QPushButton(gridFrame);
        pushButton_n2->setObjectName(QString::fromUtf8("pushButton_n2"));
        sizePolicy1.setHeightForWidth(pushButton_n2->sizePolicy().hasHeightForWidth());
        pushButton_n2->setSizePolicy(sizePolicy1);
        QPalette palette27;
        palette27.setBrush(QPalette::Active, QPalette::Button, brush);
        palette27.setBrush(QPalette::Inactive, QPalette::Button, brush);
        palette27.setBrush(QPalette::Disabled, QPalette::Button, brush);
        pushButton_n2->setPalette(palette27);
        pushButton_n2->setFont(font1);
        pushButton_n2->setFocusPolicy(Qt::ClickFocus);

        gridLayout_4->addWidget(pushButton_n2, 1, 1, 1, 1);

        pushButton_hanzi_7 = new QPushButton(gridFrame);
        pushButton_hanzi_7->setObjectName(QString::fromUtf8("pushButton_hanzi_7"));
        sizePolicy1.setHeightForWidth(pushButton_hanzi_7->sizePolicy().hasHeightForWidth());
        pushButton_hanzi_7->setSizePolicy(sizePolicy1);
        QPalette palette28;
        palette28.setBrush(QPalette::Active, QPalette::Button, brush);
        palette28.setBrush(QPalette::Inactive, QPalette::Button, brush);
        palette28.setBrush(QPalette::Disabled, QPalette::Button, brush);
        pushButton_hanzi_7->setPalette(palette28);
        pushButton_hanzi_7->setFont(font2);

        gridLayout_4->addWidget(pushButton_hanzi_7, 0, 6, 1, 1);

        pushButton_n9 = new QPushButton(gridFrame);
        pushButton_n9->setObjectName(QString::fromUtf8("pushButton_n9"));
        sizePolicy1.setHeightForWidth(pushButton_n9->sizePolicy().hasHeightForWidth());
        pushButton_n9->setSizePolicy(sizePolicy1);
        QPalette palette29;
        palette29.setBrush(QPalette::Active, QPalette::Button, brush);
        palette29.setBrush(QPalette::Inactive, QPalette::Button, brush);
        palette29.setBrush(QPalette::Disabled, QPalette::Button, brush);
        pushButton_n9->setPalette(palette29);
        pushButton_n9->setFont(font1);

        gridLayout_4->addWidget(pushButton_n9, 1, 8, 1, 1);

        pushButton_b = new QPushButton(gridFrame);
        pushButton_b->setObjectName(QString::fromUtf8("pushButton_b"));
        sizePolicy1.setHeightForWidth(pushButton_b->sizePolicy().hasHeightForWidth());
        pushButton_b->setSizePolicy(sizePolicy1);
        QPalette palette30;
        palette30.setBrush(QPalette::Active, QPalette::Button, brush);
        palette30.setBrush(QPalette::Inactive, QPalette::Button, brush);
        palette30.setBrush(QPalette::Disabled, QPalette::Button, brush);
        pushButton_b->setPalette(palette30);
        pushButton_b->setFont(font1);

        gridLayout_4->addWidget(pushButton_b, 4, 4, 1, 1);

        pushButton_comma = new QPushButton(gridFrame);
        pushButton_comma->setObjectName(QString::fromUtf8("pushButton_comma"));
        sizePolicy1.setHeightForWidth(pushButton_comma->sizePolicy().hasHeightForWidth());
        pushButton_comma->setSizePolicy(sizePolicy1);
        QPalette palette31;
        palette31.setBrush(QPalette::Active, QPalette::Button, brush);
        palette31.setBrush(QPalette::Inactive, QPalette::Button, brush);
        palette31.setBrush(QPalette::Disabled, QPalette::Button, brush);
        pushButton_comma->setPalette(palette31);
        pushButton_comma->setFont(font1);

        gridLayout_4->addWidget(pushButton_comma, 4, 7, 1, 1);

        pushButton_hanzi_4 = new QPushButton(gridFrame);
        pushButton_hanzi_4->setObjectName(QString::fromUtf8("pushButton_hanzi_4"));
        sizePolicy1.setHeightForWidth(pushButton_hanzi_4->sizePolicy().hasHeightForWidth());
        pushButton_hanzi_4->setSizePolicy(sizePolicy1);
        QPalette palette32;
        palette32.setBrush(QPalette::Active, QPalette::Button, brush);
        palette32.setBrush(QPalette::Inactive, QPalette::Button, brush);
        palette32.setBrush(QPalette::Disabled, QPalette::Button, brush);
        pushButton_hanzi_4->setPalette(palette32);
        pushButton_hanzi_4->setFont(font2);

        gridLayout_4->addWidget(pushButton_hanzi_4, 0, 3, 1, 1);

        pushButton_period = new QPushButton(gridFrame);
        pushButton_period->setObjectName(QString::fromUtf8("pushButton_period"));
        sizePolicy1.setHeightForWidth(pushButton_period->sizePolicy().hasHeightForWidth());
        pushButton_period->setSizePolicy(sizePolicy1);
        QPalette palette33;
        palette33.setBrush(QPalette::Active, QPalette::Button, brush);
        palette33.setBrush(QPalette::Inactive, QPalette::Button, brush);
        palette33.setBrush(QPalette::Disabled, QPalette::Button, brush);
        pushButton_period->setPalette(palette33);
        pushButton_period->setFont(font1);

        gridLayout_4->addWidget(pushButton_period, 4, 8, 1, 1);

        pushButton_splash = new QPushButton(gridFrame);
        pushButton_splash->setObjectName(QString::fromUtf8("pushButton_splash"));
        sizePolicy1.setHeightForWidth(pushButton_splash->sizePolicy().hasHeightForWidth());
        pushButton_splash->setSizePolicy(sizePolicy1);
        QPalette palette34;
        palette34.setBrush(QPalette::Active, QPalette::Button, brush);
        palette34.setBrush(QPalette::Inactive, QPalette::Button, brush);
        palette34.setBrush(QPalette::Disabled, QPalette::Button, brush);
        pushButton_splash->setPalette(palette34);
        pushButton_splash->setFont(font1);

        gridLayout_4->addWidget(pushButton_splash, 4, 9, 1, 1);

        pushButton_n7 = new QPushButton(gridFrame);
        pushButton_n7->setObjectName(QString::fromUtf8("pushButton_n7"));
        sizePolicy1.setHeightForWidth(pushButton_n7->sizePolicy().hasHeightForWidth());
        pushButton_n7->setSizePolicy(sizePolicy1);
        QPalette palette35;
        palette35.setBrush(QPalette::Active, QPalette::Button, brush);
        palette35.setBrush(QPalette::Inactive, QPalette::Button, brush);
        palette35.setBrush(QPalette::Disabled, QPalette::Button, brush);
        pushButton_n7->setPalette(palette35);
        pushButton_n7->setFont(font1);

        gridLayout_4->addWidget(pushButton_n7, 1, 6, 1, 1);

        pushButton_n8 = new QPushButton(gridFrame);
        pushButton_n8->setObjectName(QString::fromUtf8("pushButton_n8"));
        sizePolicy1.setHeightForWidth(pushButton_n8->sizePolicy().hasHeightForWidth());
        pushButton_n8->setSizePolicy(sizePolicy1);
        QPalette palette36;
        palette36.setBrush(QPalette::Active, QPalette::Button, brush);
        palette36.setBrush(QPalette::Inactive, QPalette::Button, brush);
        palette36.setBrush(QPalette::Disabled, QPalette::Button, brush);
        pushButton_n8->setPalette(palette36);
        pushButton_n8->setFont(font1);

        gridLayout_4->addWidget(pushButton_n8, 1, 7, 1, 1);

        pushButton_n0 = new QPushButton(gridFrame);
        pushButton_n0->setObjectName(QString::fromUtf8("pushButton_n0"));
        sizePolicy1.setHeightForWidth(pushButton_n0->sizePolicy().hasHeightForWidth());
        pushButton_n0->setSizePolicy(sizePolicy1);
        QPalette palette37;
        palette37.setBrush(QPalette::Active, QPalette::Button, brush);
        palette37.setBrush(QPalette::Inactive, QPalette::Button, brush);
        palette37.setBrush(QPalette::Disabled, QPalette::Button, brush);
        pushButton_n0->setPalette(palette37);
        pushButton_n0->setFont(font1);

        gridLayout_4->addWidget(pushButton_n0, 1, 9, 1, 1);

        pushButton_n5 = new QPushButton(gridFrame);
        pushButton_n5->setObjectName(QString::fromUtf8("pushButton_n5"));
        sizePolicy1.setHeightForWidth(pushButton_n5->sizePolicy().hasHeightForWidth());
        pushButton_n5->setSizePolicy(sizePolicy1);
        QPalette palette38;
        palette38.setBrush(QPalette::Active, QPalette::Button, brush);
        palette38.setBrush(QPalette::Inactive, QPalette::Button, brush);
        palette38.setBrush(QPalette::Disabled, QPalette::Button, brush);
        pushButton_n5->setPalette(palette38);
        pushButton_n5->setFont(font1);

        gridLayout_4->addWidget(pushButton_n5, 1, 4, 1, 1);

        pushButton_n4 = new QPushButton(gridFrame);
        pushButton_n4->setObjectName(QString::fromUtf8("pushButton_n4"));
        sizePolicy1.setHeightForWidth(pushButton_n4->sizePolicy().hasHeightForWidth());
        pushButton_n4->setSizePolicy(sizePolicy1);
        QPalette palette39;
        palette39.setBrush(QPalette::Active, QPalette::Button, brush);
        palette39.setBrush(QPalette::Inactive, QPalette::Button, brush);
        palette39.setBrush(QPalette::Disabled, QPalette::Button, brush);
        pushButton_n4->setPalette(palette39);
        pushButton_n4->setFont(font1);

        gridLayout_4->addWidget(pushButton_n4, 1, 3, 1, 1);

        pushButton_n6 = new QPushButton(gridFrame);
        pushButton_n6->setObjectName(QString::fromUtf8("pushButton_n6"));
        sizePolicy1.setHeightForWidth(pushButton_n6->sizePolicy().hasHeightForWidth());
        pushButton_n6->setSizePolicy(sizePolicy1);
        QPalette palette40;
        palette40.setBrush(QPalette::Active, QPalette::Button, brush);
        palette40.setBrush(QPalette::Inactive, QPalette::Button, brush);
        palette40.setBrush(QPalette::Disabled, QPalette::Button, brush);
        pushButton_n6->setPalette(palette40);
        pushButton_n6->setFont(font1);

        gridLayout_4->addWidget(pushButton_n6, 1, 5, 1, 1);

        pushButton_n3 = new QPushButton(gridFrame);
        pushButton_n3->setObjectName(QString::fromUtf8("pushButton_n3"));
        sizePolicy1.setHeightForWidth(pushButton_n3->sizePolicy().hasHeightForWidth());
        pushButton_n3->setSizePolicy(sizePolicy1);
        QPalette palette41;
        palette41.setBrush(QPalette::Active, QPalette::Button, brush);
        palette41.setBrush(QPalette::Inactive, QPalette::Button, brush);
        palette41.setBrush(QPalette::Disabled, QPalette::Button, brush);
        pushButton_n3->setPalette(palette41);
        pushButton_n3->setFont(font1);

        gridLayout_4->addWidget(pushButton_n3, 1, 2, 1, 1);

        pushButton_w = new QPushButton(gridFrame);
        pushButton_w->setObjectName(QString::fromUtf8("pushButton_w"));
        sizePolicy1.setHeightForWidth(pushButton_w->sizePolicy().hasHeightForWidth());
        pushButton_w->setSizePolicy(sizePolicy1);
        QPalette palette42;
        palette42.setBrush(QPalette::Active, QPalette::Button, brush);
        palette42.setBrush(QPalette::Inactive, QPalette::Button, brush);
        palette42.setBrush(QPalette::Disabled, QPalette::Button, brush);
        pushButton_w->setPalette(palette42);
        pushButton_w->setFont(font1);

        gridLayout_4->addWidget(pushButton_w, 2, 1, 1, 1);

        pushButton_deng = new QPushButton(gridFrame);
        pushButton_deng->setObjectName(QString::fromUtf8("pushButton_deng"));
        sizePolicy1.setHeightForWidth(pushButton_deng->sizePolicy().hasHeightForWidth());
        pushButton_deng->setSizePolicy(sizePolicy1);
        QPalette palette43;
        palette43.setBrush(QPalette::Active, QPalette::Button, brush);
        palette43.setBrush(QPalette::Inactive, QPalette::Button, brush);
        palette43.setBrush(QPalette::Disabled, QPalette::Button, brush);
        pushButton_deng->setPalette(palette43);
        pushButton_deng->setFont(font1);

        gridLayout_4->addWidget(pushButton_deng, 1, 11, 1, 1);

        pushButton_hanzi_5 = new QPushButton(gridFrame);
        pushButton_hanzi_5->setObjectName(QString::fromUtf8("pushButton_hanzi_5"));
        sizePolicy1.setHeightForWidth(pushButton_hanzi_5->sizePolicy().hasHeightForWidth());
        pushButton_hanzi_5->setSizePolicy(sizePolicy1);
        QPalette palette44;
        palette44.setBrush(QPalette::Active, QPalette::Button, brush);
        palette44.setBrush(QPalette::Inactive, QPalette::Button, brush);
        palette44.setBrush(QPalette::Disabled, QPalette::Button, brush);
        pushButton_hanzi_5->setPalette(palette44);
        pushButton_hanzi_5->setFont(font2);

        gridLayout_4->addWidget(pushButton_hanzi_5, 0, 4, 1, 1);

        pushButton_q = new QPushButton(gridFrame);
        pushButton_q->setObjectName(QString::fromUtf8("pushButton_q"));
        sizePolicy1.setHeightForWidth(pushButton_q->sizePolicy().hasHeightForWidth());
        pushButton_q->setSizePolicy(sizePolicy1);
        QPalette palette45;
        palette45.setBrush(QPalette::Active, QPalette::Button, brush);
        palette45.setBrush(QPalette::Inactive, QPalette::Button, brush);
        palette45.setBrush(QPalette::Disabled, QPalette::Button, brush);
        pushButton_q->setPalette(palette45);
        pushButton_q->setFont(font1);

        gridLayout_4->addWidget(pushButton_q, 2, 0, 1, 1);

        pushButton_r = new QPushButton(gridFrame);
        pushButton_r->setObjectName(QString::fromUtf8("pushButton_r"));
        sizePolicy1.setHeightForWidth(pushButton_r->sizePolicy().hasHeightForWidth());
        pushButton_r->setSizePolicy(sizePolicy1);
        QPalette palette46;
        palette46.setBrush(QPalette::Active, QPalette::Button, brush);
        palette46.setBrush(QPalette::Inactive, QPalette::Button, brush);
        palette46.setBrush(QPalette::Disabled, QPalette::Button, brush);
        pushButton_r->setPalette(palette46);
        pushButton_r->setFont(font1);

        gridLayout_4->addWidget(pushButton_r, 2, 3, 1, 1);

        pushButton_backspace = new QPushButton(gridFrame);
        pushButton_backspace->setObjectName(QString::fromUtf8("pushButton_backspace"));
        sizePolicy1.setHeightForWidth(pushButton_backspace->sizePolicy().hasHeightForWidth());
        pushButton_backspace->setSizePolicy(sizePolicy1);
        QPalette palette47;
        palette47.setBrush(QPalette::Active, QPalette::Button, brush);
        palette47.setBrush(QPalette::Inactive, QPalette::Button, brush);
        palette47.setBrush(QPalette::Disabled, QPalette::Button, brush);
        pushButton_backspace->setPalette(palette47);
        pushButton_backspace->setFont(font3);

        gridLayout_4->addWidget(pushButton_backspace, 1, 12, 1, 1);

        pushButton_y = new QPushButton(gridFrame);
        pushButton_y->setObjectName(QString::fromUtf8("pushButton_y"));
        sizePolicy1.setHeightForWidth(pushButton_y->sizePolicy().hasHeightForWidth());
        pushButton_y->setSizePolicy(sizePolicy1);
        QPalette palette48;
        palette48.setBrush(QPalette::Active, QPalette::Button, brush);
        palette48.setBrush(QPalette::Inactive, QPalette::Button, brush);
        palette48.setBrush(QPalette::Disabled, QPalette::Button, brush);
        pushButton_y->setPalette(palette48);
        pushButton_y->setFont(font1);

        gridLayout_4->addWidget(pushButton_y, 2, 5, 1, 1);

        pushButton_e = new QPushButton(gridFrame);
        pushButton_e->setObjectName(QString::fromUtf8("pushButton_e"));
        sizePolicy1.setHeightForWidth(pushButton_e->sizePolicy().hasHeightForWidth());
        pushButton_e->setSizePolicy(sizePolicy1);
        QPalette palette49;
        palette49.setBrush(QPalette::Active, QPalette::Button, brush);
        palette49.setBrush(QPalette::Inactive, QPalette::Button, brush);
        palette49.setBrush(QPalette::Disabled, QPalette::Button, brush);
        pushButton_e->setPalette(palette49);
        pushButton_e->setFont(font1);

        gridLayout_4->addWidget(pushButton_e, 2, 2, 1, 1);

        pushButton_backsplash = new QPushButton(gridFrame);
        pushButton_backsplash->setObjectName(QString::fromUtf8("pushButton_backsplash"));
        sizePolicy1.setHeightForWidth(pushButton_backsplash->sizePolicy().hasHeightForWidth());
        pushButton_backsplash->setSizePolicy(sizePolicy1);
        QPalette palette50;
        palette50.setBrush(QPalette::Active, QPalette::Button, brush);
        palette50.setBrush(QPalette::Inactive, QPalette::Button, brush);
        palette50.setBrush(QPalette::Disabled, QPalette::Button, brush);
        pushButton_backsplash->setPalette(palette50);
        pushButton_backsplash->setFont(font1);

        gridLayout_4->addWidget(pushButton_backsplash, 2, 12, 1, 1);

        pushButton_i = new QPushButton(gridFrame);
        pushButton_i->setObjectName(QString::fromUtf8("pushButton_i"));
        sizePolicy1.setHeightForWidth(pushButton_i->sizePolicy().hasHeightForWidth());
        pushButton_i->setSizePolicy(sizePolicy1);
        QPalette palette51;
        palette51.setBrush(QPalette::Active, QPalette::Button, brush);
        palette51.setBrush(QPalette::Inactive, QPalette::Button, brush);
        palette51.setBrush(QPalette::Disabled, QPalette::Button, brush);
        pushButton_i->setPalette(palette51);
        pushButton_i->setFont(font1);

        gridLayout_4->addWidget(pushButton_i, 2, 7, 1, 1);

        pushButton_hanzi_3 = new QPushButton(gridFrame);
        pushButton_hanzi_3->setObjectName(QString::fromUtf8("pushButton_hanzi_3"));
        sizePolicy1.setHeightForWidth(pushButton_hanzi_3->sizePolicy().hasHeightForWidth());
        pushButton_hanzi_3->setSizePolicy(sizePolicy1);
        QPalette palette52;
        palette52.setBrush(QPalette::Active, QPalette::Button, brush);
        palette52.setBrush(QPalette::Inactive, QPalette::Button, brush);
        palette52.setBrush(QPalette::Disabled, QPalette::Button, brush);
        pushButton_hanzi_3->setPalette(palette52);
        pushButton_hanzi_3->setFont(font2);

        gridLayout_4->addWidget(pushButton_hanzi_3, 0, 2, 1, 1);

        pushButton_youkuo = new QPushButton(gridFrame);
        pushButton_youkuo->setObjectName(QString::fromUtf8("pushButton_youkuo"));
        sizePolicy1.setHeightForWidth(pushButton_youkuo->sizePolicy().hasHeightForWidth());
        pushButton_youkuo->setSizePolicy(sizePolicy1);
        QPalette palette53;
        palette53.setBrush(QPalette::Active, QPalette::Button, brush);
        palette53.setBrush(QPalette::Inactive, QPalette::Button, brush);
        palette53.setBrush(QPalette::Disabled, QPalette::Button, brush);
        pushButton_youkuo->setPalette(palette53);
        pushButton_youkuo->setFont(font1);

        gridLayout_4->addWidget(pushButton_youkuo, 2, 11, 1, 1);

        pushButton_p = new QPushButton(gridFrame);
        pushButton_p->setObjectName(QString::fromUtf8("pushButton_p"));
        sizePolicy1.setHeightForWidth(pushButton_p->sizePolicy().hasHeightForWidth());
        pushButton_p->setSizePolicy(sizePolicy1);
        QPalette palette54;
        palette54.setBrush(QPalette::Active, QPalette::Button, brush);
        palette54.setBrush(QPalette::Inactive, QPalette::Button, brush);
        palette54.setBrush(QPalette::Disabled, QPalette::Button, brush);
        pushButton_p->setPalette(palette54);
        pushButton_p->setFont(font1);

        gridLayout_4->addWidget(pushButton_p, 2, 9, 1, 1);

        pushButton_up = new QPushButton(gridFrame);
        pushButton_up->setObjectName(QString::fromUtf8("pushButton_up"));
        sizePolicy1.setHeightForWidth(pushButton_up->sizePolicy().hasHeightForWidth());
        pushButton_up->setSizePolicy(sizePolicy1);
        pushButton_up->setFont(font1);

        gridLayout_4->addWidget(pushButton_up, 1, 13, 1, 1);

        pushButton_shift = new QPushButton(gridFrame);
        pushButton_shift->setObjectName(QString::fromUtf8("pushButton_shift"));
        sizePolicy1.setHeightForWidth(pushButton_shift->sizePolicy().hasHeightForWidth());
        pushButton_shift->setSizePolicy(sizePolicy1);
        QPalette palette55;
        palette55.setBrush(QPalette::Active, QPalette::Button, brush);
        palette55.setBrush(QPalette::Inactive, QPalette::Button, brush);
        palette55.setBrush(QPalette::Disabled, QPalette::Button, brush);
        pushButton_shift->setPalette(palette55);
        QFont font4;
        font4.setPointSize(9);
        font4.setBold(true);
        font4.setWeight(75);
        pushButton_shift->setFont(font4);

        gridLayout_4->addWidget(pushButton_shift, 4, 12, 1, 1);

        pushButton_enter = new QPushButton(gridFrame);
        pushButton_enter->setObjectName(QString::fromUtf8("pushButton_enter"));
        sizePolicy1.setHeightForWidth(pushButton_enter->sizePolicy().hasHeightForWidth());
        pushButton_enter->setSizePolicy(sizePolicy1);
        QPalette palette56;
        palette56.setBrush(QPalette::Active, QPalette::Button, brush);
        palette56.setBrush(QPalette::Inactive, QPalette::Button, brush);
        palette56.setBrush(QPalette::Disabled, QPalette::Button, brush);
        pushButton_enter->setPalette(palette56);
        QFont font5;
        font5.setPointSize(11);
        font5.setBold(true);
        font5.setWeight(75);
        pushButton_enter->setFont(font5);

        gridLayout_4->addWidget(pushButton_enter, 3, 11, 1, 2);

        pushButton_down = new QPushButton(gridFrame);
        pushButton_down->setObjectName(QString::fromUtf8("pushButton_down"));
        sizePolicy1.setHeightForWidth(pushButton_down->sizePolicy().hasHeightForWidth());
        pushButton_down->setSizePolicy(sizePolicy1);
        pushButton_down->setFont(font1);

        gridLayout_4->addWidget(pushButton_down, 2, 13, 1, 1);

        pushButton_ok = new QPushButton(gridFrame);
        pushButton_ok->setObjectName(QString::fromUtf8("pushButton_ok"));
        sizePolicy1.setHeightForWidth(pushButton_ok->sizePolicy().hasHeightForWidth());
        pushButton_ok->setSizePolicy(sizePolicy1);
        QPalette palette57;
        QBrush brush6(QColor(0, 255, 0, 255));
        brush6.setStyle(Qt::SolidPattern);
        palette57.setBrush(QPalette::Active, QPalette::ButtonText, brush6);
        palette57.setBrush(QPalette::Inactive, QPalette::ButtonText, brush6);
        QBrush brush7(QColor(118, 116, 108, 255));
        brush7.setStyle(Qt::SolidPattern);
        palette57.setBrush(QPalette::Disabled, QPalette::ButtonText, brush7);
        pushButton_ok->setPalette(palette57);
        QFont font6;
        font6.setPointSize(30);
        font6.setBold(true);
        font6.setWeight(75);
        pushButton_ok->setFont(font6);

        gridLayout_4->addWidget(pushButton_ok, 4, 13, 1, 1);

        pushButton_c = new QPushButton(gridFrame);
        pushButton_c->setObjectName(QString::fromUtf8("pushButton_c"));
        sizePolicy1.setHeightForWidth(pushButton_c->sizePolicy().hasHeightForWidth());
        pushButton_c->setSizePolicy(sizePolicy1);
        QPalette palette58;
        palette58.setBrush(QPalette::Active, QPalette::Button, brush);
        palette58.setBrush(QPalette::Inactive, QPalette::Button, brush);
        palette58.setBrush(QPalette::Disabled, QPalette::Button, brush);
        pushButton_c->setPalette(palette58);
        pushButton_c->setFont(font1);

        gridLayout_4->addWidget(pushButton_c, 4, 2, 1, 1);

        pushButton_whitespace = new QPushButton(gridFrame);
        pushButton_whitespace->setObjectName(QString::fromUtf8("pushButton_whitespace"));
        sizePolicy1.setHeightForWidth(pushButton_whitespace->sizePolicy().hasHeightForWidth());
        pushButton_whitespace->setSizePolicy(sizePolicy1);
        QPalette palette59;
        palette59.setBrush(QPalette::Active, QPalette::Button, brush);
        palette59.setBrush(QPalette::Inactive, QPalette::Button, brush);
        palette59.setBrush(QPalette::Disabled, QPalette::Button, brush);
        pushButton_whitespace->setPalette(palette59);
        pushButton_whitespace->setFont(font4);

        gridLayout_4->addWidget(pushButton_whitespace, 4, 10, 1, 1);

        pushButton_left = new QPushButton(gridFrame);
        pushButton_left->setObjectName(QString::fromUtf8("pushButton_left"));
        sizePolicy1.setHeightForWidth(pushButton_left->sizePolicy().hasHeightForWidth());
        pushButton_left->setSizePolicy(sizePolicy1);
        pushButton_left->setFont(font1);

        gridLayout_4->addWidget(pushButton_left, 0, 13, 1, 1);

        pushButton_hanzi_1 = new QPushButton(gridFrame);
        pushButton_hanzi_1->setObjectName(QString::fromUtf8("pushButton_hanzi_1"));
        sizePolicy1.setHeightForWidth(pushButton_hanzi_1->sizePolicy().hasHeightForWidth());
        pushButton_hanzi_1->setSizePolicy(sizePolicy1);
        QPalette palette60;
        palette60.setBrush(QPalette::Active, QPalette::Button, brush);
        palette60.setBrush(QPalette::Inactive, QPalette::Button, brush);
        palette60.setBrush(QPalette::Disabled, QPalette::Button, brush);
        pushButton_hanzi_1->setPalette(palette60);
        pushButton_hanzi_1->setFont(font2);
        pushButton_hanzi_1->setAutoExclusive(true);

        gridLayout_4->addWidget(pushButton_hanzi_1, 0, 0, 1, 1);

        pushButton_gang = new QPushButton(gridFrame);
        pushButton_gang->setObjectName(QString::fromUtf8("pushButton_gang"));
        sizePolicy1.setHeightForWidth(pushButton_gang->sizePolicy().hasHeightForWidth());
        pushButton_gang->setSizePolicy(sizePolicy1);
        QPalette palette61;
        palette61.setBrush(QPalette::Active, QPalette::Button, brush);
        palette61.setBrush(QPalette::Inactive, QPalette::Button, brush);
        palette61.setBrush(QPalette::Disabled, QPalette::Button, brush);
        pushButton_gang->setPalette(palette61);
        pushButton_gang->setFont(font1);

        gridLayout_4->addWidget(pushButton_gang, 1, 10, 1, 1);

        lineEdit_pinyin = new QLineEdit(gridFrame);
        lineEdit_pinyin->setObjectName(QString::fromUtf8("lineEdit_pinyin"));
        sizePolicy.setHeightForWidth(lineEdit_pinyin->sizePolicy().hasHeightForWidth());
        lineEdit_pinyin->setSizePolicy(sizePolicy);
        QFont font7;
        font7.setFamily(QString::fromUtf8("\345\276\256\350\275\257\351\233\205\351\273\221"));
        font7.setPointSize(21);
        font7.setBold(true);
        font7.setWeight(75);
        lineEdit_pinyin->setFont(font7);
        lineEdit_pinyin->setFrame(false);

        gridLayout_4->addWidget(lineEdit_pinyin, 0, 10, 1, 3);

        QWidget::setTabOrder(pushButton_hanzi_left, pushButton_hanzi_1);
        QWidget::setTabOrder(pushButton_hanzi_1, pushButton_hanzi_2);
        QWidget::setTabOrder(pushButton_hanzi_2, pushButton_hanzi_3);
        QWidget::setTabOrder(pushButton_hanzi_3, pushButton_hanzi_4);
        QWidget::setTabOrder(pushButton_hanzi_4, pushButton_hanzi_5);
        QWidget::setTabOrder(pushButton_hanzi_5, pushButton_hanzi_6);
        QWidget::setTabOrder(pushButton_hanzi_6, pushButton_hanzi_7);
        QWidget::setTabOrder(pushButton_hanzi_7, pushButton_hanzi_8);
        QWidget::setTabOrder(pushButton_hanzi_8, pushButton_hanzi_right);
        QWidget::setTabOrder(pushButton_hanzi_right, pushButton_n1);
        QWidget::setTabOrder(pushButton_n1, pushButton_n2);
        QWidget::setTabOrder(pushButton_n2, pushButton_n3);
        QWidget::setTabOrder(pushButton_n3, pushButton_n4);
        QWidget::setTabOrder(pushButton_n4, pushButton_n5);
        QWidget::setTabOrder(pushButton_n5, pushButton_n6);
        QWidget::setTabOrder(pushButton_n6, pushButton_n7);
        QWidget::setTabOrder(pushButton_n7, pushButton_n8);
        QWidget::setTabOrder(pushButton_n8, pushButton_n9);
        QWidget::setTabOrder(pushButton_n9, pushButton_n0);
        QWidget::setTabOrder(pushButton_n0, pushButton_gang);
        QWidget::setTabOrder(pushButton_gang, pushButton_deng);
        QWidget::setTabOrder(pushButton_deng, pushButton_backspace);
        QWidget::setTabOrder(pushButton_backspace, pushButton_q);
        QWidget::setTabOrder(pushButton_q, pushButton_w);
        QWidget::setTabOrder(pushButton_w, pushButton_e);
        QWidget::setTabOrder(pushButton_e, pushButton_r);
        QWidget::setTabOrder(pushButton_r, pushButton_t);
        QWidget::setTabOrder(pushButton_t, pushButton_y);
        QWidget::setTabOrder(pushButton_y, pushButton_u);
        QWidget::setTabOrder(pushButton_u, pushButton_i);
        QWidget::setTabOrder(pushButton_i, pushButton_o);
        QWidget::setTabOrder(pushButton_o, pushButton_p);
        QWidget::setTabOrder(pushButton_p, pushButton_zuokuo);
        QWidget::setTabOrder(pushButton_zuokuo, pushButton_youkuo);
        QWidget::setTabOrder(pushButton_youkuo, pushButton_backsplash);
        QWidget::setTabOrder(pushButton_backsplash, pushButton_a);
        QWidget::setTabOrder(pushButton_a, pushButton_s);
        QWidget::setTabOrder(pushButton_s, pushButton_d);
        QWidget::setTabOrder(pushButton_d, pushButton_f);
        QWidget::setTabOrder(pushButton_f, pushButton_g);
        QWidget::setTabOrder(pushButton_g, pushButton_h);
        QWidget::setTabOrder(pushButton_h, pushButton_j);
        QWidget::setTabOrder(pushButton_j, pushButton_k);
        QWidget::setTabOrder(pushButton_k, pushButton_l);
        QWidget::setTabOrder(pushButton_l, pushButton_semicolon);
        QWidget::setTabOrder(pushButton_semicolon, pushButton_quote);
        QWidget::setTabOrder(pushButton_quote, pushButton_enter);
        QWidget::setTabOrder(pushButton_enter, pushButton_z);
        QWidget::setTabOrder(pushButton_z, pushButton_x);
        QWidget::setTabOrder(pushButton_x, pushButton_c);
        QWidget::setTabOrder(pushButton_c, pushButton_v);
        QWidget::setTabOrder(pushButton_v, pushButton_b);
        QWidget::setTabOrder(pushButton_b, pushButton_n);
        QWidget::setTabOrder(pushButton_n, pushButton_m);
        QWidget::setTabOrder(pushButton_m, pushButton_comma);
        QWidget::setTabOrder(pushButton_comma, pushButton_period);
        QWidget::setTabOrder(pushButton_period, pushButton_splash);
        QWidget::setTabOrder(pushButton_splash, pushButton_shift);
        QWidget::setTabOrder(pushButton_shift, pushButton_whitespace);
        QWidget::setTabOrder(pushButton_whitespace, pushButton_is_hanzi);
        QWidget::setTabOrder(pushButton_is_hanzi, pushButton_ok);
        QWidget::setTabOrder(pushButton_ok, pushButton_left);
        QWidget::setTabOrder(pushButton_left, pushButton_down);
        QWidget::setTabOrder(pushButton_down, pushButton_right);
        QWidget::setTabOrder(pushButton_right, pushButton_up);
        QWidget::setTabOrder(pushButton_up, lineEdit_pinyin);
        QWidget::setTabOrder(lineEdit_pinyin, lineEdit_window);

        retranslateUi(Dialog);

        QMetaObject::connectSlotsByName(Dialog);
    } // setupUi

    void retranslateUi(QDialog *Dialog)
    {
        Dialog->setWindowTitle(QApplication::translate("Dialog", "Dialog", 0, QApplication::UnicodeUTF8));
        lineEdit_window->setText(QString());
        pushButton_right->setText(QApplication::translate("Dialog", "\342\206\222", 0, QApplication::UnicodeUTF8));
        pushButton_quote->setText(QApplication::translate("Dialog", "'", 0, QApplication::UnicodeUTF8));
        pushButton_h->setText(QApplication::translate("Dialog", "h", 0, QApplication::UnicodeUTF8));
        pushButton_f->setText(QApplication::translate("Dialog", "f", 0, QApplication::UnicodeUTF8));
        pushButton_hanzi_right->setText(QApplication::translate("Dialog", "\342\206\222", 0, QApplication::UnicodeUTF8));
        pushButton_semicolon->setText(QApplication::translate("Dialog", ";", 0, QApplication::UnicodeUTF8));
        pushButton_g->setText(QApplication::translate("Dialog", "g", 0, QApplication::UnicodeUTF8));
        pushButton_hanzi_2->setText(QString());
        pushButton_hanzi_6->setText(QString());
        pushButton_j->setText(QApplication::translate("Dialog", "j", 0, QApplication::UnicodeUTF8));
        pushButton_hanzi_left->setText(QApplication::translate("Dialog", "\342\206\220", 0, QApplication::UnicodeUTF8));
        pushButton_m->setText(QApplication::translate("Dialog", "m", 0, QApplication::UnicodeUTF8));
        pushButton_zuokuo->setText(QApplication::translate("Dialog", "[", 0, QApplication::UnicodeUTF8));
        pushButton_is_hanzi->setText(QApplication::translate("Dialog", "En", 0, QApplication::UnicodeUTF8));
        pushButton_t->setText(QApplication::translate("Dialog", "t", 0, QApplication::UnicodeUTF8));
        pushButton_k->setText(QApplication::translate("Dialog", "k", 0, QApplication::UnicodeUTF8));
        pushButton_n1->setText(QApplication::translate("Dialog", "1", 0, QApplication::UnicodeUTF8));
        pushButton_n->setText(QApplication::translate("Dialog", "n", 0, QApplication::UnicodeUTF8));
        pushButton_x->setText(QApplication::translate("Dialog", "x", 0, QApplication::UnicodeUTF8));
        pushButton_l->setText(QApplication::translate("Dialog", "l", 0, QApplication::UnicodeUTF8));
        pushButton_a->setText(QApplication::translate("Dialog", "a", 0, QApplication::UnicodeUTF8));
        pushButton_z->setText(QApplication::translate("Dialog", "z", 0, QApplication::UnicodeUTF8));
        pushButton_v->setText(QApplication::translate("Dialog", "v", 0, QApplication::UnicodeUTF8));
        pushButton_u->setText(QApplication::translate("Dialog", "u", 0, QApplication::UnicodeUTF8));
        pushButton_hanzi_8->setText(QString());
        pushButton_s->setText(QApplication::translate("Dialog", "s", 0, QApplication::UnicodeUTF8));
        pushButton_o->setText(QApplication::translate("Dialog", "o", 0, QApplication::UnicodeUTF8));
        pushButton_d->setText(QApplication::translate("Dialog", "d", 0, QApplication::UnicodeUTF8));
        pushButton_n2->setText(QApplication::translate("Dialog", "2", 0, QApplication::UnicodeUTF8));
        pushButton_hanzi_7->setText(QString());
        pushButton_n9->setText(QApplication::translate("Dialog", "9", 0, QApplication::UnicodeUTF8));
        pushButton_b->setText(QApplication::translate("Dialog", "b", 0, QApplication::UnicodeUTF8));
        pushButton_comma->setText(QApplication::translate("Dialog", ",", 0, QApplication::UnicodeUTF8));
        pushButton_hanzi_4->setText(QString());
        pushButton_period->setText(QApplication::translate("Dialog", ".", 0, QApplication::UnicodeUTF8));
        pushButton_splash->setText(QApplication::translate("Dialog", "/", 0, QApplication::UnicodeUTF8));
        pushButton_n7->setText(QApplication::translate("Dialog", "7", 0, QApplication::UnicodeUTF8));
        pushButton_n8->setText(QApplication::translate("Dialog", "8", 0, QApplication::UnicodeUTF8));
        pushButton_n0->setText(QApplication::translate("Dialog", "0", 0, QApplication::UnicodeUTF8));
        pushButton_n5->setText(QApplication::translate("Dialog", "5", 0, QApplication::UnicodeUTF8));
        pushButton_n4->setText(QApplication::translate("Dialog", "4", 0, QApplication::UnicodeUTF8));
        pushButton_n6->setText(QApplication::translate("Dialog", "6", 0, QApplication::UnicodeUTF8));
        pushButton_n3->setText(QApplication::translate("Dialog", "3", 0, QApplication::UnicodeUTF8));
        pushButton_w->setText(QApplication::translate("Dialog", "w", 0, QApplication::UnicodeUTF8));
        pushButton_deng->setText(QApplication::translate("Dialog", "=", 0, QApplication::UnicodeUTF8));
        pushButton_hanzi_5->setText(QString());
        pushButton_q->setText(QApplication::translate("Dialog", "q", 0, QApplication::UnicodeUTF8));
        pushButton_r->setText(QApplication::translate("Dialog", "r", 0, QApplication::UnicodeUTF8));
        pushButton_backspace->setText(QApplication::translate("Dialog", "\351\200\200\346\240\274", 0, QApplication::UnicodeUTF8));
        pushButton_y->setText(QApplication::translate("Dialog", "y", 0, QApplication::UnicodeUTF8));
        pushButton_e->setText(QApplication::translate("Dialog", "e", 0, QApplication::UnicodeUTF8));
        pushButton_backsplash->setText(QApplication::translate("Dialog", "\\", 0, QApplication::UnicodeUTF8));
        pushButton_i->setText(QApplication::translate("Dialog", "i", 0, QApplication::UnicodeUTF8));
        pushButton_hanzi_3->setText(QString());
        pushButton_youkuo->setText(QApplication::translate("Dialog", "]", 0, QApplication::UnicodeUTF8));
        pushButton_p->setText(QApplication::translate("Dialog", "p", 0, QApplication::UnicodeUTF8));
        pushButton_up->setText(QApplication::translate("Dialog", "\342\206\221", 0, QApplication::UnicodeUTF8));
        pushButton_shift->setText(QApplication::translate("Dialog", "\345\210\207\346\215\242", 0, QApplication::UnicodeUTF8));
        pushButton_enter->setText(QApplication::translate("Dialog", "enter", 0, QApplication::UnicodeUTF8));
        pushButton_down->setText(QApplication::translate("Dialog", "\342\206\223", 0, QApplication::UnicodeUTF8));
        pushButton_ok->setText(QApplication::translate("Dialog", "\342\210\232", 0, QApplication::UnicodeUTF8));
        pushButton_c->setText(QApplication::translate("Dialog", "c", 0, QApplication::UnicodeUTF8));
        pushButton_whitespace->setText(QApplication::translate("Dialog", "\347\251\272\346\240\274", 0, QApplication::UnicodeUTF8));
        pushButton_left->setText(QApplication::translate("Dialog", "\342\206\220", 0, QApplication::UnicodeUTF8));
        pushButton_hanzi_1->setText(QString());
        pushButton_gang->setText(QApplication::translate("Dialog", "-", 0, QApplication::UnicodeUTF8));
        lineEdit_pinyin->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class Dialog: public Ui_Dialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SYSZUXPINYIN_H

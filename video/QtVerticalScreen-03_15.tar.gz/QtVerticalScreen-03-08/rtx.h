#ifndef RTX_H
#define RTX_H

#define BUFSIZE 1024*1024*2
#define PACKAGE_SIZE 1024

#define PORT 3333
#define SERVICE_ADDR "192.168.1.111"


struct package{
    char	heard[16];
    int 	id;
    int		cmd;
    int 	length;
    char	md5[32];
    char	value[128];
};

extern int wd_fd;
extern int exit_flag;
void TGSaveImage(char *file,unsigned char* bmp,int w ,int h);

unsigned char **bmp_Make2DArray_uint8(int row,int col);

void bmp_Free2DArray_uint8(unsigned char **a,int row);

void XorEncryptDecrypt(unsigned char * Veindata, int length, int flag);

void write_data_hex(unsigned char * my_array,int length,char *string);

void read_data_hex(unsigned char *buf,int length,char *string);

void trans_encrypt(unsigned char * data,int length);

int initComm(char* ttyDir,unsigned speed);

int writeComm(int fd, char* buf, int len);

int readComm(int fd, char* buf, int len, int timeout );

void StrToHex(unsigned char *pbDest,unsigned char *pbSrc, int nLen);

void HexToStr(unsigned char *pbDest,unsigned  char *pbSrc, int nLen);

int Compute_string_md5(unsigned char *dest_str, unsigned int dest_len, char *md5_str);

int file_size(char* filename) ;

int file_save(struct package *pack,char *buf);

int sendPackage(int fd,char *heard,int id,int cmd,char *value);

int sendDataPackage(int fd,char *data,int len);

int receivePackage(int fd,char *pack,int timeout);

int receiveDataBlock(int fd,char *data,int len,int timeout);

int resolvePacgage(struct package *pack,char *dat);

int TG_RecvPackage(int fd,char *heard,int *id,int *cmd,int *length,char* value,char*buf);

int TG_SendPackage(int fd,char *heard,int id,int cmd,int length,char* value,char* buf);

int init_Device();

int release_Device(int fd);

int init_watchdog(int timeout);

int feed_watchdog();

int release_watchdog();

int TG_NetRecvPackage(int fd,char *heard,int *id,int *cmd,int *length,char* value,char*buf);
int TG_NetSendPackage(int fd,char *heard,int id,int cmd,int length,char* value,char* buf);
int net_client_connect(char *addr,int port);

#endif


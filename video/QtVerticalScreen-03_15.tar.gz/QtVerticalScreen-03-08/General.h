#ifndef GENERAL_H
#define GENERAL_H

//#include "Database.h"

//变量声明
//extern VeinDB Veindb;
//管理员操作标志位
extern int Root_flag;



#endif // GENERAL_H


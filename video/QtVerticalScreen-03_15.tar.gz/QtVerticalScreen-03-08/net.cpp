#include <stdlib.h>
#include <stdio.h>
#include <errno.h>
#include <string.h>
#include <netdb.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <arpa/inet.h> //inet_ntoa()函数的头文件
#include <unistd.h>
#include <pthread.h>
#include <signal.h>

#include "rtx.h"

int net_client_connect(char *addr,int port)
{
      int sockfd;

      struct sockaddr_in server_addr;
      struct hostent *host;
      int nbytes;

      if((host=gethostbyname(addr))==NULL)
      {
          fprintf(stderr,"Gethostname error\n");
          return -1;
      }

      if((sockfd=socket(AF_INET,SOCK_STREAM,0))==-1) // AF_INET:Internet;SOCK_STREAM:TCP
      {
          fprintf(stderr,"Socket Error:%s\a\n",strerror(errno));
          return -1;
      }

      bzero(&server_addr,sizeof(server_addr));
      server_addr.sin_family=AF_INET; // IPV4
      server_addr.sin_port=htons(port);
      server_addr.sin_addr=*((struct in_addr *)host->h_addr); //

      if(connect(sockfd,(struct sockaddr *)(&server_addr),sizeof(struct sockaddr))==-1)
      {
          fprintf(stderr,"Connect Error:%s\a\n",strerror(errno));
          close(sockfd);
          return -1;
      }

      return sockfd;

}
int net_service_init(char *addr,int port)
{
    int sockfd;
    struct sockaddr_in server_addr; //

    if((sockfd=socket(AF_INET,SOCK_STREAM,0))==-1) // AF_INET:IPV4;SOCK_STREAM:TCP
    {
        fprintf(stderr,"Socket error:%s\n\a",strerror(errno));
        exit(1);
    }

    bzero(&server_addr,sizeof(struct sockaddr_in)); // 初始化,置0
    server_addr.sin_family=AF_INET; // Internet
    if(addr!=NULL)
        server_addr.sin_addr.s_addr=inet_addr(addr); //用于绑定到一个固定IP,inet_addr用于把数字加格式的ip转化为整形ip
    else
        server_addr.sin_addr.s_addr=htonl(INADDR_ANY); // (将本机器上的long数据转化为网络上的long数据)和任何主机通信 //INADDR_ANY 表示可以接收任意IP地址的数据，即绑定到所有的IP

    server_addr.sin_port=htons(port); // (将本机器上的short数据转化为网络上的short数据)端口号

    unsigned int value = 0x1;
    setsockopt(sockfd,SOL_SOCKET,SO_REUSEADDR,(void *)&value,sizeof(value));

    if(bind(sockfd,(struct sockaddr *)(&server_addr),sizeof(struct sockaddr))==-1)
    {
        fprintf(stderr,"Bind error:%s\n\a",strerror(errno));
        exit(1);
    }

    if(listen(sockfd,5)==-1)
    {
        fprintf(stderr,"Listen error:%s\n\a",strerror(errno));
        exit(1);
    }

    return sockfd;

}
int net_service_accept(int sockfd)
{
    int new_fd;
    struct sockaddr_in client_addr;
//    int sin_size;
    socklen_t sin_size;

    sin_size=sizeof(struct sockaddr_in);
    if((new_fd=accept(sockfd,(struct sockaddr *)(&client_addr),&sin_size))==-1)
    {
        fprintf(stderr,"Accept error:%s\n\a",strerror(errno));
        return -1;
    }
    fprintf(stderr,"Server get connection from %s\n",inet_ntoa(client_addr.sin_addr)); // 将网络地址转换成.字符串，并打印到输出终端

    return new_fd;
}
int TG_NetRecvPackage(int fd,char *heard,int *id,int *cmd,int *length,char* value,char*buf)
{
    char rx[PACKAGE_SIZE],md5[32];
    int len,ret=1;
    struct package pack;

    if(fd<0) return -5;
    memset(rx,0,sizeof(rx));
    memset(&pack,0,sizeof(pack));

    len=receivePackage(fd,rx,200);
    //printf("rx =  %s\n",rx);
    if(len==0) return 0;
    if(len<0) return -2;

    resolvePacgage(&pack,rx);

    if(pack.cmd==21&&pack.length>0)
    {//file or data block receive
        //if(sendPackage(fd,pack.heard,pack.id,pack.cmd,"ok")>=0) {
            receiveDataBlock(fd,buf,pack.length,500);
            Compute_string_md5((unsigned char*)buf,pack.length,md5);
            //printf("%s ", md5);
            //write_data_hex1(buf,pack.length,"/home/fa/a");
            if(strncmp(pack.md5,md5,32)==0){//success
                //file_save(&pack,buf);
                ret=1;
            }
            else {//fail
                ret=-3;
            }
        //}
        //else ret=-4;
    }
    if(pack.id==0&&pack.cmd==0)ret=-6;

    *id = pack.id;
    *cmd = pack.cmd;
    *length = pack.length;
    strcpy(value,pack.value);
    strcpy(heard,pack.heard);

    return ret;
}


int TG_NetSendPackage(int fd,char *heard,int id,int cmd,int length,char* value,char* buf)
{
    int ret=1;
    char rx[PACKAGE_SIZE],cmdline[PACKAGE_SIZE],md5[32];
    struct package pack;

    if(fd<0) return -5;
    memset(rx,0,sizeof(rx));
    memset(&pack,0,sizeof(pack));
    memset(cmdline,0,sizeof(cmdline));

    if(cmd==21&&length>0){//send file or data block
        Compute_string_md5((unsigned char*)buf,length,pack.md5);
        //printf("%s\n", pack.md5);

        sprintf(cmdline,"%s length:%ld md5:%s",value,length,pack.md5);

        if(sendPackage(fd,heard,id,cmd,cmdline)>=0){
        /*	if(receivePackage(fd,rx,2000)<0){
                printf("receivePackage fail ack !!\n");
                ret=-2;
            }
            else{
                resolvePacgage(&pack,rx);
                if(strcmp(pack.value,"ok")==0){
                    ret=sendDataPackage(fd,buf,length);
                }
                else ret=-3;
            }*/
            ret=sendDataPackage(fd,buf,length);
        }
        else ret=-4;
    }
    else{//normal cmd data
        if(value!=NULL) sprintf(cmdline,"%s",value);
        if(sendPackage(fd,heard,id,cmd,cmdline)<0)
            ret=-4;
    }

    return ret;
}


#include "Database.h"
#include "tg_main.h"

/************************************************
 * creator  : @xu
 * function : 建立sqlite数据库连接
 * Date     : 2017-06-17
 * parameter: 无
*************************************************/
VeinDB::VeinDB()
{
    //连接名
    connName = "my_sqlite";
    DBName = "TG_data.db";
    db = NULL;
    query = NULL;
    db = new QSqlDatabase();
}
VeinDB::~VeinDB()
{

}
/*******************************************
*   creator    : @xu
*   function   :
*   parameter  :
*   Date       :2017/06/17
********************************************/
/*
bool VeinDB::createConnection()
{
    //以后就可以用"sqlite"与数据库进行连接了
    *db = QSqlDatabase::addDatabase("QSQLITE","my_sqlite");
    db->setDatabaseName(DBName);
    if(!db->open())
    {
        qDebug() << "无法建立数据库连接";
        printf("******************Establish database failed!!!\n");
        db->close();
        return false;
    }
    printf("******************Establish database success!!!\n");
    db->close();

    return true;
}
*/
bool VeinDB::createConnection()
{
//判断这个连接是否存在
   if(QSqlDatabase::contains(connName))
   {
      *db = QSqlDatabase::database(connName);
   }
   else
   {
      *db = QSqlDatabase::addDatabase("QSQLITE",connName);
   }
   db->setDatabaseName(DBName);
   if(!db->open())
   {
       qDebug() << "无法建立数据库连接";
       printf("******************Establish database failed!!!\n");
//       db->close();
       return false;
   }
   printf("******************Establish database success!!!\n");
//   db->close();

   return true;
}
/************************************************
 * creator  : @xu
 * function : 创建数据库列表，每个用户的特征点存在一列
 * Date     : 2017-06-17
 * parameter: 无
*************************************************/
bool VeinDB::createTable()
{
    *db = QSqlDatabase::database(connName); //建立数据库连接
//    qDebug()<<"open db "<<db.open();
    bool success;
    query = new QSqlQuery(*db);
//    query(db);

    success = query->exec("CREATE TABLE if not exists my_table(work_num int PRIMARY KEY,name varchar,"
                             "department varchar,authority varchar,password int,"
                              "vein QByteArray)");
    if(success)
    {
        qDebug() << QObject::tr("******************database my_table create success!******************");
        db->close();
        return true;
    }
    else
    {
        qDebug() << QObject::tr("******************database my_table create failed******************");
        db->close();
        return false;
    }

    qDebug()<<query->lastError();
}

/************************************************
 * creator  : @xu
 * function : 向数据库表中插入数据
 * parameter: 插入数据库中指静脉特征点类型为QByteArray
 *
 * Date     : 2017-07-01
 * parameter: 指静脉特征点存储类型：QByteArray
*************************************************/
bool VeinDB::insertByte(int work_num,QString str_name,QString str_department,QString str_authority,int password,QByteArray veinData)
{
    *db = QSqlDatabase::database(connName); //建立数据库连接
    query = new QSqlQuery(*db);
//    query(db);

    query->prepare("INSERT INTO my_table VALUES(?, ?, ?, ?, ?,?)");
    query->bindValue(0, work_num);             //1：工号
    query->bindValue(1, str_name);           //2：姓名
    query->bindValue(2, str_department);     //3：部门
    query->bindValue(3, str_authority);      //4：权限
    query->bindValue(4, password);             //7：密码

    qDebug()<<"**************VeinSize === "<<veinData.size();

    query->bindValue(5,veinData,QSql::Binary);   //用户指静脉特征点(.dat)二进制文件
    bool success = query->exec();
//    db.close();
    if(!success)
    {
        QSqlError lastError = query->lastError();
        qDebug() << lastError.driverText() << QString(QObject::tr("insert failed"));
        db->close();
        return false;
    }
    qDebug()<<"**************Insert New Register SUCCEESSFULLY!";
    db->close();

    return true;
}

/************************************************
 * creator  : @xu
 * function : 向数据库表中插入数据
 * parameter: parameter:
 * Date     : 2017-09-13
 * parameter: 指静脉特征点存储类型：unsigned char *
*************************************************/
bool VeinDB::insertUchar(int work_num,QString str_name,QString str_department,QString str_authority,int password,unsigned char* veinData)
{
    *db = QSqlDatabase::database(connName); //建立数据库连接
    query = new QSqlQuery(*db);
//    query(db);
    char vein_Buf[CHARACTER_SIZE];
    memset(vein_Buf,'\0',CHARACTER_SIZE*sizeof(char));
    memcpy(vein_Buf,veinData,CHARACTER_SIZE*sizeof(char));

    QByteArray byte;
    byte = QByteArray(vein_Buf,CHARACTER_SIZE);
    qDebug()<<"**************VeinSize == "<<byte.size();

    query->prepare("INSERT INTO my_table VALUES(?, ?, ?, ?, ?, ?)");
    query->bindValue(0, work_num);           //1：工号
    query->bindValue(1, str_name);           //2：姓名
    query->bindValue(2, str_department);     //3：部门
    query->bindValue(3, str_authority);      //4：权限
    query->bindValue(4, password);           //5：密码
    query->bindValue(5,byte,QSql::Binary);   //6：用户指静脉特征点(.dat)二进制文件

    bool success = query->exec();
    if(!success)
    {
        QSqlError lastError = query->lastError();
        qDebug() << lastError.driverText() << QString(QObject::tr("insert failed"));
        db->close();
        return false;
    }
    qDebug()<<"**************Insert New Register SUCCEESSFULLY!";
    db->close();

    return true;
}

/************************************************
 * creator  : @xu
 * function : 获得数据库中的用户个数
 * 已经注册的用户数
 * Date     : 2017-06-17
 * parameter:
 *           usersNum:用户个数
*************************************************/
bool VeinDB::get_usersNum(int *usersNum)
{
//建立数据库连接
    *db = QSqlDatabase::database(connName);
    query = new QSqlQuery(*db);
//    query(db);

    query->exec("select * from my_table");
    QSqlRecord rec = query->record();
    qDebug() << QObject::tr("my_table field numbers = " ) << rec.count();
//数据库定位到最后一条记录
    if(query->last())
    {
        qDebug()<<"***************Users Number: "<<query->at()+1;

        *usersNum = query->at()+1;
    }
    db->close();

    return true;
}

/************************************************
 * creator  : @xu
 * function : 查询遍历所有用户
 * Date     : 2017-06-12
 * parameter: 无
*************************************************/
bool VeinDB::queryAll()
{
    QByteArray veinData;
    *db = QSqlDatabase::database(connName); //建立数据库连接
    query = new QSqlQuery(*db);
//    query(db);
    query->exec("SELECT * FROM my_table");
    QSqlRecord rec = query->record();
//打印字段数
    qDebug() << QObject::tr("numbers of field my_table " ) << rec.count();
//    qDebug()<<"column of name = "<<query.record().indexOf("name");//获取"name"的列号
    while(query->next())
    {
//        for(int index = 0; index < 6; index++)
//            qDebug() << query.value(index).toString() << " ";
        qDebug()<<"at = "<<query->at();  //每条记录的编号

        qDebug() << query->value(0).toInt();     //1:工号
        qDebug() << query->value(1).toString();  //2:姓名
        qDebug() << query->value(2).toString();  //3:部门
        qDebug() << query->value(3).toString();  //4:权限
        qDebug() << query->value(4).toInt();     //5:密码
        veinData = query->value(5).toByteArray();//6:指静脉

        qDebug()<<"veinData.size = "<<veinData.size();
        qDebug() << "\n";

    }
    db->close();

    return true;
}
/*******************************************
*   creator    : @xu
*   function   : 遍历数据库中所有用户，查询管理员
*   parameter  :
*   return     :
*               0:
*               1:
*
*   Date       :2017/09/15
********************************************/
int VeinDB::queryRoot(int userloc)
{
   int ret = 0;
   int retCompare;
   QString Root;
   Root = QString::fromUtf8("管理员");
   *db = QSqlDatabase::database(connName); //建立数据库连接
   query = new QSqlQuery(*db);
//   query(db);
   query->exec("SELECT * FROM my_table");
   qDebug()<<"***************DB userLoc: "<<userloc;
   QSqlRecord rec = query->record();
//打印字段数
   qDebug() << QObject::tr("numbers of field my_table " ) << rec.count();
   while(query->next())
   {
      qDebug()<<"*************** Authority: "<<query->value(3);
      qDebug()<<"*************** Query.at: "<<query->at();

      if((0 != userloc)&&(userloc == (query->at()+1)))
      {
//        return 1;
         qDebug()<<"*************** Authority: "<<query->value(3);
//         if(Root == query.value(3))  //判断是否是管理员
         retCompare = Root.compare(Root,query->value(3).toString());
         printf("*************** retcompare: %d\n",retCompare);
         if(0 == retCompare)
         {
            qDebug()<<"*************** Authority Root***************";
            db->close();
            return 1;
         }
         else
         {
            qDebug()<<"*************** Common User Root***************";
//            ret = 0;
            db->close();
            return 0;
         }
     }
     else
     {
        db->close();
        ret = -1;
     }
    }

    db->close();
    return ret;
}

/*******************************************
*   creator    : @xu
*   function   : 查询数据库中所有用户ID
*                比较待存入的用户ID与数据库中
*                用户ID是否重复
*   parameter  :
*   return     :
*               返回1,重复
*               返回非1,未重复
*   Date       :2017/09/11
********************************************/
int VeinDB::queryId(QString ID)
{
    int ret;
    QString UserID;
    *db = QSqlDatabase::database(connName); //建立数据库连接
    query = new QSqlQuery(*db);
//    query(db);
    query->exec("SELECT * FROM my_table");
    QSqlRecord rec = query->record();
//打印字段数
    qDebug() << QObject::tr("numbers of field my_table " ) << rec.count();
    while(query->next())
    {
        qDebug() <<"***************ID: "<<query->value(0).toString();     //1:工号
        UserID = query->value(0).toString();
        if(ID == UserID)
        {
//            ret = 1;
            db->close();
            return 1;
        }
        else
        {
            db->close();
            ret = 0;
        }
    }
//    db.close();
    return ret;

}
/*******************************************
 * creator  : @xu
 * function : 从数据库中，获取已经注册的所有用户的特征点，
 * 存入unsigned char buf[]缓冲区(算法要求的接口)
 *
 * Date     : 2017-07-05
 * parameter: 无
********************************************/
bool VeinDB::getAllData(unsigned char * UcharBuf)
{
    int i=0;
    int UserNum = 0;
    int Size = 0;
//每个用户的指静脉特征点大小
    QByteArray eachByte;
//已经存入数据库的所有用户的指静脉特征点大小
    QByteArray totalByte;
    char *chVein;
    chVein = NULL;

    *db = QSqlDatabase::database(connName); //建立数据库连接
    query = new QSqlQuery(*db);
//    query(db);
    query->exec("SELECT * FROM my_table");
    QSqlRecord rec = query->record();
//打印字段数
    qDebug() << QObject::tr("numbers of field my_table " ) << rec.count();
//    qDebug()<<"column of name = "<<query.record().indexOf("name");//获取"name"的列号

    while(query->next())
    {
//        for(int index = 0; index < 6; index++)
//            qDebug() << query.value(index).toString() << " ";
//每条记录的编号
//        qDebug()<<"at = "<<query.at();

        qDebug() << query->value(0).toInt();      //1:工号
        qDebug() << query->value(1).toString();   //2:姓名
        qDebug() << query->value(2).toString();   //3:部门
        qDebug() << query->value(3).toString();   //4:权限
        qDebug() << query->value(4).toInt();      //5:密码
//数据库中依次获取每个用户的指静脉特征点
        eachByte = query->value(5).toByteArray(); //6:指静脉
//数据库中获取所有用户指静脉特征点（拼接起来）
        totalByte.append(eachByte);
    }
    Size = totalByte.size();
    get_usersNum(&UserNum);
    qDebug()<<"***************All UserNum = "<<UserNum;
    qDebug()<<"***************AllUsers Size = "<<Size;
    chVein = totalByte.data();
    memcpy(UcharBuf,chVein,Size);
    db->close();

    return true;
}

/************************************************
 * creator  : @xu
 * function : //根据用户工号，删除用户
 * Date     : 2017-07-05
 * parameter: 无
*************************************************/
bool VeinDB::deleteById(int id)
{
    *db = QSqlDatabase::database(connName); //建立数据库连接
    if(!db->open())
    {
        qDebug() << "can't connect the database";
//        qDebug() << mydb.lastError();
//        return false;
    }
    query = new QSqlQuery(*db);
    query->prepare(QString("DELETE FROM my_table WHERE work_num = %1").arg(id));
    if(!query->exec())
    {
        qDebug() << "删除记录失败！";
        db->close();
        return false;
    }
    db->close();

    return true;
}

/************************************************
 * creator  : @xu
 * function : 根据用户工号，
 * 更新记录（未包含指静脉特征点的存储）
 *
 * Date     : 2017-07-05
 * parameter: 无
*************************************************/
bool VeinDB::updateEssentialMsg(int work_num,QString str_name,QString str_department,QString str_authority,int password)
{
    *db = QSqlDatabase::database(connName); //建立数据库连接
    query = new QSqlQuery(*db);
//    query(db);
    query->prepare(QString("UPDATE my_table SET work_num=?,name=?,department=?, authority=?,"
                             "password=? WHERE work_num=%1").arg(work_num));
    query->bindValue(0, work_num);       //1：工号
    query->bindValue(1, str_name);       //2：姓名
    query->bindValue(2, str_department); //3：部门
    query->bindValue(3, str_authority);  //4：权限
    query->bindValue(4, password);       //5：密码

    bool success = query->exec();
    if(!success)
    {
        QSqlError lastError = query->lastError();
        qDebug() << lastError.driverText() << QString(QObject::tr("update failed"));
        db->close();
        return false;
    }
    db->close();

    return true;
}

/************************************************
 * creator  : @xu
 * function : 根据用户工号ID，
 * 更新数据库中用户所有信息
 *（包含指用户指静脉特征点的更新）
 *
 * Date     : 2017-09-11
 * parameter:
 * 指静脉特征点存储类型：QByteArray
*************************************************/
bool VeinDB::updateData_Byte(int work_num, QString str_name, QString str_department, QString str_authority, int password,QByteArray veinData)
{
    *db = QSqlDatabase::database(connName); //建立数据库连接
    query = new QSqlQuery(*db);
//    query(db);
    query->prepare(QString("UPDATE my_table SET work_num=?,name=?,department=?, authority=?,"
                             "password=?,vein=? WHERE work_num=%1").arg(work_num));
    query->bindValue(0, work_num);       //1：工号
    query->bindValue(1, str_name);       //2：姓名
    query->bindValue(2, str_department); //3：部门
    query->bindValue(3, str_authority);  //4：权限
    query->bindValue(4, password);       //6：密码
    query->bindValue(5,veinData,QSql::Binary);   //用户指静脉特征点(.dat)二进制文件

    bool success = query->exec();
    if(!success)
    {
       QSqlError lastError = query->lastError();
       qDebug() << lastError.driverText() << QString(QObject::tr("update failed"));
       db->close();
       return false;
    }
    qDebug()<<"**************UPDATE Register User SUCCEESSFULLY!";
    db->close();
    return true;
}
/************************************************
 * creator  : @xu
 * function : 根据用户工号ID，
 * 更新数据库中用户所有信息
 *（包含指用户指静脉特征点的更新）
 *
 * Date     : 2017-09-13
 * parameter:
 * 指静脉特征点存储类型：unsigned char *
*************************************************/
bool VeinDB::updateData_Uchar(int work_num, QString str_name, QString str_department, QString str_authority, int password, unsigned char*veinData)
{
    QByteArray byte;
    char vein_Buf[CHARACTER_SIZE];
    memset(vein_Buf,'\0',CHARACTER_SIZE*sizeof(char));
    memcpy(vein_Buf,veinData,CHARACTER_SIZE*sizeof(char));
    byte = QByteArray(vein_Buf,CHARACTER_SIZE);
    *db = QSqlDatabase::database(connName); //建立数据库连接
    query = new QSqlQuery(*db);
//    query(db);
    query->prepare(QString("UPDATE my_table SET work_num=?,name=?,department=?, authority=?,"
                             "password=?,vein=? WHERE work_num=%1").arg(work_num));
    query->bindValue(0, work_num);       //1：工号
    query->bindValue(1, str_name);       //2：姓名
    query->bindValue(2, str_department); //3：部门
    query->bindValue(3, str_authority);  //4：权限
    query->bindValue(4, password);       //6：密码
    query->bindValue(5,byte,QSql::Binary);   //用户指静脉特征点(.dat)二进制文件

    bool success = query->exec();
    if(!success)
    {
       QSqlError lastError = query->lastError();
       qDebug() << lastError.driverText() << QString(QObject::tr("update failed"));
       db->close();
       return false;
    }
    qDebug()<<"**************UPDATE Register User SUCCEESSFULLY!";
    db->close();
    return true;
}

//排序
bool VeinDB::sortById()
{
    *db = QSqlDatabase::database(connName); //建立数据库连接
    query = new QSqlQuery(*db);
//    query(db);
    bool success = query->exec("SELECT * FROM my_table ORDER BY work_num DESC");

    if(success)
    {
        qDebug() << "sort successed";
        return true;
    }
    else
    {
        qDebug() <<"sort failed";
        return false;
    }
}

/*******************************************
*   creator    : @xu
*   function   : Attend_DB.db:
*                               建立考勤记录的数据库
*   parameter  :
*   Date       :2017/11/01
********************************************/
AttendanceDB::AttendanceDB()
{
    //连接名
    connName = "Attend_sqlite";
    DBName = "AttendDB.db";
    db = NULL;
    query = NULL;
}
AttendanceDB::~AttendanceDB()
{

}
bool AttendanceDB::createConnection()
{
//判断这个连接是否存在
    if(QSqlDatabase::contains(connName))
    {
       *db = QSqlDatabase::database(connName);
    }
    else
    {
       *db = QSqlDatabase::addDatabase("QSQLITE",connName);
    }
    db->setDatabaseName(DBName);
    if(!db->open())
    {
       qDebug() << "无法建立数据库连接";
       printf("******************Establish database failed!!!\n");
//       db->close();
       return false;
    }
    printf("******************Establish database success!!!\n");
//   db->close();

    return true;
}





















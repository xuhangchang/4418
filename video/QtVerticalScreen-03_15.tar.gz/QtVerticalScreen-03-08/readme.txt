

壁挂式设备（ud661）:
要求：
 屏幕尺寸：480*800（竖屏）

代码：使用sqlite数据库

1.加入线程，（测试一下），编译通过；

2.加入算法静态库，成功编译通过；

3.加入软键盘输入法;
4.加入sqlite数据库，连接数据库成功，数据库表创建成功,；建立表成功；
5.采集图像数据，注册，验证线程可以运行；现在注册不成功（可能原因：算法中有加解密，需要调整）；
6.注册线程中，有些指针释放有问题
7.比之前版本相比，ui改用布局
8.IP地址设置功能添加中：
成功创建Linux系统下的ini后缀的IP配置文件，可实现读写
可获取到本地IP地址，及MAC地址
9.注册与验证流程算法调试，跑通，已经可以实现注册，比对；
10.采集图像，采用了新的采集函数；
11.数据库更新函数之前存在些问题，进行了更新，调试通过；
 数据库用户插入函数，更新信息函数进行了优化，已经调试通过；
12.点击菜单按钮,可进行管理员身份验证,从而实现管理员相关功能的操作(即界面跳转),也可进行普通的验证,测试通过;
13.主界面按钮抬起或按下的背景色效果,添加验证操作提示,验证状态显示;注册界面上注册提示和注册状态显示;
14.更新了图像采集程序,即去掉了采集图像线程(2017/10/18)
15.更新用户基本信息功能实现(包括:name,department,Authority,PassWord)(10/19),优化了(所有)用户信息显示界面;
16.优化了查询用户,删除用户;
17.整个程序中,摄像头采集图像程序进行了简化,删繁就简.数据库操作进行了优化;




2017/11/01 17:49

待讨论或解决的关键点：
摄像头芯片：OV5640
1.指静脉特征点大小16k或17k

3.算法已经是最新算法接口,算法更新于2017/09/05
(.so动态库的形式,程序在编译,运行的时候,都需要调用到.so动态库)
如果需要更算法,则需要将算法动态库.so要拷贝到板子的系统相应的目录下,如拷贝到/usr/lib/下









说明：
该工程的编译运行通过终端命令实现，因为要运行在ARM板上
相关的几条命令：
（１）生成.pro文件

/usr/local/Trolltech/QtEmbeded-4.8.7-arm/bin/qmake -project

（２）生成Makefile文件
/usr/local/Trolltech/QtEmbeded-4.8.7-arm/bin/qmake QtVerticalScreen.pro

注意：如果报错如下：
QMAKESPEC has not been set, so configuration cannot be deduced.
Error processing project file: XXXX.pro
这是因为QMAKESPEC变量没有设置好，
在终端输入命令：export QMAKESPEC=/usr/local/Trolltech/QtEmbedded-4.8.7-arm/mkspecs/linux-g++
或者
在/root/.bash_profile里加入一行：
export QMAKESPEC=/usr/local/Trolltech/QtEmbedded-4.8.7-arm/mkspecs/linux-g++（即是linux-g++的路径）。

（３）修改Makefile（Makefile中编译器）
CC            = gcc
CXX           = g++
.
.
LINK          = g++
.
AR            = ar cqs
以上四项修改为下面：
CC            = arm-linux-gcc
CXX           = arm-linux-g++
.
.
LINK          = arm-linux-g++
.
AR            = arm-linux-ar cqs

（４）保存Makefile内容，终端执行命令：make -j4　即可生成可执行文件，该执行文件通过网络传入板子，即可运行在
arm开发板上。
（５）在工程目录下，运行脚本to_device，会将可执行文件QtVerticalScreen通过网络传入板子。
板端通过Linux系统终端minicom进入，打开minicom,输入命令：sudo minicom
板子账号：root
密码：fa
可执行文件在/home/fa/目录下，然后运行脚本run.sh（即终端输入命令：./run.sh）



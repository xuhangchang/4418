#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <termios.h>
#include <linux/watchdog.h>
#include <ctype.h>
#include <errno.h>
#include "md5.h"
#include "rtx.h"

#include <linux/types.h>
#include <linux/input.h>
#include <linux/hidraw.h>
#include "tg_main.h"

int wd_fd;

void TGSaveImage(char *file,unsigned char* bmp,int w ,int h)
{
    int i = 0;
    char color = 0;
    char end[2] = {0,0};
    char patte[1024] = {0};
    int pos = 0;

    unsigned char heard[54] = {0x42,0x4d,0x30,0x0C,0x01,0,0,0,0,0,0x36,4,0,0,0x28,0,0,0,0xF5,0,0,0,0x46,0,0,0,0x01,0,8,0,0,0,0,0,0xF8,0x0b,0x01,0,0x12,0x0b,0,0,0x12,0x0b,0,0,0,0,0,0,0,0,0,0};
    int size = w*h;
    int allsize = size +1080;

    heard[2] = allsize&0xFF;
    heard[3] = (allsize>>8)&0xFF;
    heard[4] = (allsize>>16)&0xFF;
    heard[5] = (allsize>>24)&0xFF;

    heard[18] = w&0xFF;
    heard[19] = (w>>8)&0xFF;
    heard[20] = (w>>16)&0xFF;
    heard[21] = (w>>24)&0xFF;

    heard[22] = h&0xFF;
    heard[23] = (h>>8)&0xFF;
    heard[24] = (h>>16)&0xFF;
    heard[25] = (h>>24)&0xFF;

    allsize -=1078;
    heard[34] = allsize&0xFF;
    heard[35] = (allsize>>8)&0xFF;
    heard[36] = (allsize>>16)&0xFF;
    heard[37] = (allsize>>24)&0xFF;

    for(i=0;i<1024;i+=4)
    {
        patte[pos++] = color;
        patte[pos++] = color;
        patte[pos++] = color;
        patte[pos++] = 0;
        color++;
    }

    FILE* fd = NULL;

    fd = fopen(file,"wb+");
    if(fd == NULL)
    {
        return;
    }
    else
    {
        fwrite(heard,54,1,fd);
        fwrite(patte,1024,1,fd);
        fwrite(bmp,size,1,fd);
        fwrite(end,2,1,fd);
    }
    fclose(fd);
}

unsigned char **bmp_Make2DArray_uint8(int row,int col){
    unsigned char **a;
    int i;
    a=(unsigned char **)calloc(row,sizeof(unsigned char *));
    for(i=0;i<row;i++)
    {
        a[i]=(unsigned char *)calloc(col,sizeof(unsigned char));
    }
    return a;

}


void bmp_Free2DArray_uint8(unsigned char **a,int row)
{
    int i;
    for(i=0;i<row;i++)
    {
        free(a[i]);
        a[i] = NULL;
    }
    free(a);
    a = NULL;
}
void XorEncryptDecrypt(unsigned char * Veindata, int length, int flag)
{
    int i, j, temp1, temp2;
    //unsigned char key[32] = { 0xb9, 0xda, 0x5e, 0x15, 0x46, 0x57, 0xa7, 0x8d, 0x9d, 0x84,0x90, 0xd8, 0xab, 0x00, 0x8c, 0xbc, 0xd3, 0x0a, 0xf7, 0xe4, 0x58, 0x05, 0xb8, 0xb3, 0x45, 0x06,0xd0, 0x2c, 0x1e, 0x8f, 0xca, 0x3f };
    unsigned char key[128] = {  0x3F, 0xE2, 0x58, 0x26, 0xD9, 0x74, 0x40, 0x5B, 0xFE, 0x9F, 0x43, 0xE3, 0xF9, 0xA5, 0xDF, 0x07,
                                0xEF, 0x93, 0x2D, 0xD0, 0x05, 0xE3, 0x89, 0x37, 0x7B, 0xD4, 0x2B, 0x54, 0x2D, 0xD4, 0xCD, 0xEA,
                                0x9A, 0x3F, 0x0D, 0x43, 0x95, 0x0C, 0x26, 0x60, 0xCF, 0xC0, 0x3B, 0xD6, 0x08, 0x64, 0x1C, 0xE3,
                                0x8E, 0x6F, 0xFD, 0x59, 0x20, 0x43, 0x59, 0xCE, 0x42, 0x18, 0x21, 0x3A, 0x5A, 0x64, 0x19, 0xB5,
                                0x9D, 0xA9, 0x1B, 0xF8, 0x8E, 0xFF, 0xAA, 0xB0, 0xEF, 0x5E, 0xCC, 0x8F, 0x05, 0xB8, 0x4F, 0x6D,
                                0x9A, 0x8E, 0xCC, 0x1F, 0x5B, 0x84, 0x13, 0x8B, 0xC2, 0xD6, 0xB2, 0xA3, 0xD4, 0x6A, 0x60, 0x0B,
                                0x4E, 0x8D, 0xE5, 0x09, 0x99, 0xC8, 0x11, 0x96, 0x20, 0xB7, 0x9C, 0xB9, 0x73, 0x40, 0xCE, 0xEC,
                                0x41, 0x2C, 0xC0, 0x1C, 0x3A, 0x2E, 0xCE, 0x6E, 0x8E, 0x11, 0xA9, 0xFD, 0x4A, 0x00, 0xC6, 0x65 };
    if (1 == flag)
    {
        temp1 = length / 128;
        temp2 = length % 128;
        for (i = 0;i < temp1;i++)
        {
            for (j = 0;j < 128;j++)
            {
                Veindata[i * 128 + j] ^= key[j];
            }
        }
        for (j = 0;j < temp2;j++)
        {
            Veindata[i * 128 + j] ^= key[j];
        }
    }
    else if (2 == flag)
    {
        unsigned char * tempData = (unsigned char *)malloc((length - 16) * sizeof(unsigned char));//ÌØÕ÷Öµ¼õÈ¥Í·Î²8¸ö×Ö½Ú
        memcpy(tempData, Veindata + 8, length - 16);
        temp1 = (length - 16) / 128;
        temp2 = (length - 16) % 128;
        for (i = 0;i < temp1;i++)
        {
            for (j = 0;j < 128;j++)
            {
                tempData[i * 128 + j] ^= key[j];
            }
        }
        for (j = 0;j < temp2;j++)
        {
            tempData[i * 128 + j] ^= key[j];
        }
        memcpy(Veindata + 8, tempData, length - 16);
        free(tempData);
    }
}



void write_data_hex(unsigned char * my_array,int length,char *string)
{
    int i = 0;
    FILE *fp;
    fp = fopen(string,"wb+");
    if(NULL == fp)
    {
        printf("file open Fail!\n");
    }

    while(i < length)
    {
        fwrite(&my_array[i],sizeof(unsigned char ),1,fp);
        i++;
    }

    fclose(fp);
}

void read_data_hex(unsigned char *buf,int length,char *string)
{
    int i = 0;
    int re;
    FILE *fp;
    fp = fopen(string,"rb");
    if(NULL == fp)
    {
        printf("file open Fail!\n");
    }
    fread(buf,sizeof(unsigned char),length,fp);
    fclose(fp);
}

void trans_encrypt(unsigned char * data,int length)
{
    int i,j,temp1,temp2;
    unsigned char key[32] = {0xb9, 0xda, 0x5e, 0x15, 0x46, 0x57, 0xa7, 0x8d, 0x9d, 0x84,0x90, 0xd8, 0xab, 0x00, 0x8c, 0xbc, 0xd3, 0x0a, 0xf7, 0xe4, 0x58, 0x05, 0xb8, 0xb3, 0x45, 0x06,0xd0, 0x2c, 0x1e, 0x8f, 0xca, 0x3f};

    temp1 = length / 32;
    temp2 = length % 32;
    for(i = 0;i < temp1;i++)
    {
        for(j = 0;j < 32;j++)
        {
            data[i*32+j] ^= key[j];
        }
    }
    for(j = 0;j < temp2;j++)
    {
        data[i*32+j] ^=  key[j];
    }
}

int initComm(char* ttyDir,unsigned speed)
{
  int retry = 60;


  int mfd = open(ttyDir, O_RDWR | O_NOCTTY /*| O_NDELAY*/);
  if(mfd < 0)
  {
    perror(ttyDir);
    return -1;
  }


  while(lockf(mfd, F_TLOCK, 0) < 0)
  {
    sleep(1);
    retry--;
    if(retry <= 0)
    {
      printf("Devcie %s locked.\n", ttyDir);
      close(mfd);
      return -1;
    }
  }
    switch(speed)
    {
        case 4800:speed=B4800;break;
        case 9600:speed=B9600;break;
        case 19200:speed=B19200;break;
        case 38400:speed=B38400;break;
        case 57600:speed=B57600;break;
        case 115200:speed=B115200;break;
        case 230400:speed=B230400;break;
        case 460800:speed=B460800;break;
        default:printf("speed eer");return -1;
    }
  struct termios Opt;
  tcgetattr(mfd, &Opt);
  cfsetispeed(&Opt,speed);
  cfsetospeed(&Opt,speed);
  tcsetattr(mfd, TCSANOW, &Opt);
  tcflush(mfd, TCIOFLUSH);

  tcgetattr(mfd, &Opt);

  Opt.c_cflag &= ~CSIZE;
  Opt.c_cflag |= CS8;
 // Opt.c_cflag |=CBAUD;
  Opt.c_cflag   |= IXON|IXOFF|IXANY;                                 /* 脢媒戮脻脦禄 8 */
  Opt.c_cflag &= ~PARENB;                               /* Clear parity enable */
  Opt.c_cflag &= ~CSTOPB;                               /* 脥拢脰鹿脦禄 1 */
  Opt.c_lflag &= ~(ICANON | ECHO | ECHOE | ISIG);
  Opt.c_iflag &= ~(BRKINT | ICRNL | INPCK | ISTRIP | IXON);
  Opt.c_oflag  &= ~OPOST;

  Opt.c_cc[VTIME] = 150;                                /* 脡猫脰脙鲁卢脢卤15 seconds*/
  Opt.c_cc[VMIN] = 0;                                   /* Update the options and do it NOW */

  if(tcsetattr(mfd, TCSANOW, &Opt) < 0)
  {
    perror(ttyDir);
    close(mfd);
    return -1;
  }
  tcflush(mfd, TCIOFLUSH);

  return mfd;
}
int writeComm(int fd, char* buf, int len)
{

  int rs = write(fd, buf, len);
  if(rs == -1)
  {
    perror("writeComm:");
    return -1;
  }

  return 0;
}
int readComm(int fd, char* buf, int len, int timeout /* 潞脕脙毛 */)
{
  fd_set fds;
  FD_ZERO(&fds);
  FD_SET(fd, &fds);
  struct timeval tv = {0, 1000*timeout};
  int total1=0,total = len,err_count=len/1000,i;
  char* startRev = buf;

  while(total > 0)
  {
    int res = select(fd+1, &fds, NULL, NULL, &tv);
    if(res == -1)
    {
      if(errno == EINTR)
        continue;
      else
      {
        printf("socket error %d with select", errno);
        return -1;
      }
    }
    else if(res == 0)
    {err_count=0;
      buf[len - total] = '\0';
    //printf("[timeout]\n");


    return len - total;

    }

    if(FD_ISSET(fd, &fds))
    {
    int rs,rs1;


    rs = read(fd, startRev, len);

      if(rs < 0)
      {
        buf[len - total] = '\0';
        perror("readComm:");
        return -1;
      }
    total1+=rs;
      // printf("total:[ %d %d %d %d ]\n", total,total1,rs,rs1);
      total -= rs;
      startRev += rs;
    }


    if(err_count--<0)
    {
        //qDebug()<<res<<len/1000<<err_count--;
        //usleep(100000);
        return -1;
    }

  }



//  printf("readComm: %d %d\n", len,total);
  return len - total;
}
void StrToHex(unsigned char *pbDest, unsigned char *pbSrc, int nLen)
{
    unsigned char h1,h2;
    unsigned char s1,s2;
    int i;

    for (i=0; i<nLen; i++)
    {
        h1 = pbSrc[2*i];
        h2 = pbSrc[2*i+1];

        s1 = toupper(h1) - 0x30;
        if (s1 > 9)
        s1 -= 7;

        s2 = toupper(h2) - 0x30;
        if (s2 > 9)
        s2 -= 7;

        pbDest[i] = s1*16 + s2;
    }
}
void HexToStr(unsigned char *pbDest, unsigned char *pbSrc, int nLen)
{
    unsigned char ddl,ddh;
    int i;

    for (i=0; i<nLen; i++)
    {
        ddh = 48 + pbSrc[i] / 16;
        ddl = 48 + pbSrc[i] % 16;
        if (ddh > 57) ddh = ddh + 7;
        if (ddl > 57) ddl = ddl + 7;
        pbDest[i*2] = ddh;
        pbDest[i*2+1] = ddl;
    }

    pbDest[nLen*2] = '\0';
}

/**
 * compute the value of a string
 * @param  dest_str
 * @param  dest_len
 * @param  md5_str
 */
int Compute_string_md5(unsigned char *dest_str, unsigned int dest_len, char *md5_str)
{
    int i;
    unsigned char md5_value[MD5_SIZE];
    MD5_CTX md5;

    // init md5
    MD5Init(&md5);

    MD5Update(&md5, dest_str, dest_len);

    MD5Final(&md5, md5_value);

    // convert md5 value to md5 string
    for(i = 0; i < MD5_SIZE; i++)
    {
        snprintf(md5_str + i*2, 2+1, "%02x", md5_value[i]);
    }

    return 0;
}
int file_size(char* filename)
{
    //int fd,r;
        /*FILE *fp=fopen(filename,"r");
        if(!fp) return -1;
        fseek(fp,0L,SEEK_END);
        int size=ftell(fp);
        fclose(fp);
          */
    struct stat statbuf;
    stat(filename,&statbuf);
    int size=statbuf.st_size;
/*
    fd=open(filename,O_RDONLY);
    if(fd<0) return -1;
    read(fd,str_to_pc,size);
    printf("[%d %d]\n",size,r);
    close(fd);*/
    return size;
}

/*
int file_save(struct package *pack,char *buf)
{
    int fd;

    fd=open(pack->value,O_RDWR|O_CREAT);
    if(fd<0) return -1;
    write(fd,buf,pack->length);
    close(fd);
    chmod(pack->value, S_IRWXU|S_IRWXG|S_IRWXO);
}
*/

int sendPackage(int fd,char *heard,int id,int cmd,char *value)
{
    char dat[PACKAGE_SIZE];
    memset(dat,'\0',sizeof(dat));
    sprintf(dat,"device:%s id:%d cmd:%d value:%s",heard,id,cmd,value);
//	printf("%d %s\n",strlen(dat),dat);
//	printf("sendPackage,dat = %s\n length = %d\n",dat,strlen(dat));
    trans_encrypt((unsigned char*)dat,strlen(dat));

    return writeComm(fd,dat,strlen(dat));

}
int sendDataPackage(int fd,char *data,int len)
{

    usleep(1000*250);

    return writeComm(fd,data,len);
}
int receivePackage(int fd,char *pack,int timeout)
{
    int ret ;
    ret =  readComm(fd,pack,PACKAGE_SIZE,timeout);
    trans_encrypt((unsigned char*)pack,ret);
    return ret;
}
int receiveDataBlock(int fd,char *data,int len,int timeout)
{
    int r,length=0,cnt=50;
    while(cnt--){
        r=readComm(fd,&data[length],len-length,timeout);
        if(r>0) length+=r;
        printf("-----block:%d--%d---%d-\n",r,len-length,len);
        if(length>=len||r<=0) break;
    }
//	trans_encrypt(data,length);
    return length;
}
int resolvePacgage(struct package *pack,char *dat)
{
        char *p,n;
        memset(pack,0,sizeof(pack));
             p=strstr(dat,"device:");
        if(p!=NULL){
            n=0;p+=7;
            while(*(p+n)!=' '&&n<32) n++;
            memcpy(pack->heard,p,n+1);
        }else return -1;
        p=strstr(dat,"id:");
        if(p!=NULL){
            n=0;p+=3;
            while(*(p+n)!=' '&&n<32) n++;
            pack->id=atoi(p);
        }else return -2;
        p=strstr(dat,"cmd:");
        if(p!=NULL){
            n=0;p+=4;
            while(*(p+n)!=' '&&n<32) n++;
            pack->cmd=atoi(p);
        }else return -3;
        p=strstr(dat,"value:");
        if(p!=NULL){
            n=0;p+=6;
            while(*(p+n)!=' '&&n<32) n++;
            memcpy(pack->value,p,n);
        }else return -4;
        p=strstr(dat,"length:");
        if(p!=NULL){
            n=0;p+=7;
            while(*(p+n)!=' '&&n<32) n++;
            pack->length=atoi(p);
        }
        p=strstr(dat,"md5:");
        if(p!=NULL){
            n=0;p+=4;
            while(*(p+n)!=' '&&n<32) n++;
            memcpy(pack->md5,p,n);
        }

//		printf("client connetct  --> device:%s id:%d cmd:%d value:%s length:%d %s\n",
//		pack->heard,pack->id,pack->cmd,pack->value,pack->length,pack->md5);
}
int TG_RecvPackage(int fd,char *heard,int *id,int *cmd,int *length,char* value,char*buf)
{
    char rx[PACKAGE_SIZE],md5[32],*tmp=NULL;
    int len,ret=1;
    struct package pack;

    if(fd<0) return -5;
    memset(rx,0,sizeof(rx));
    memset(&pack,0,sizeof(pack));

    len=receivePackage(fd,rx,200);
    if(len==0) return 0;


    if(len<0) return -2;
//printf("%d %s\n",len,rx);
    resolvePacgage(&pack,rx);

    if(pack.cmd==21){//file or data block receive
//		if(sendPackage(fd,pack.heard,pack.id,pack.cmd,"ok")>=0) {


            tmp=(char *)malloc(pack.length*2+2);if(tmp==NULL) return -1;

            receiveDataBlock(fd,tmp,pack.length,500);
            StrToHex((unsigned char*)buf,(unsigned char*)tmp,pack.length);
            //printf("%d %d \n[%s]\n",len,pack.length,tmp);
            pack.length=(pack.length>>1);
            //buf++;//skip 1B data
            Compute_string_md5((unsigned char*)buf,pack.length,md5);
            //printf("%s ",md5);

            if(strncmp(pack.md5,md5,32)==0){//success
                //file_save(&pack,buf);
                ret=1;
            }
            else {//fail
                ret=-3;
            }
        //	printf("%s %d %d %s %d %d %s\n",pack.heard,pack.id,pack.cmd,pack.value,pack.length,len,md5);
//		}
//		else ret=-4;
    }

    if(pack.id==0&&pack.cmd==0)
        ret=-6;

    *id = pack.id;
    *cmd = pack.cmd;
    *length = pack.length;
    strcpy(value,pack.value);
    strcpy(heard,pack.heard);
    if(tmp!=NULL) free(tmp);

    return ret;
}


int TG_SendPackage(int fd,char *heard,int id,int cmd,int length,char* value,char* buf)
{
    int ret=1;
    char rx[PACKAGE_SIZE],cmdline[PACKAGE_SIZE],md5[32],*tmp=NULL;
    struct package pack;

    if(fd<0) return -5;

    memset(rx,0,sizeof(rx));
    memset(&pack,0,sizeof(pack));
    memset(cmdline,0,sizeof(cmdline));

    if(cmd==21){//send file or data block
        tmp=(char *)malloc(length*2+2);if(tmp==NULL) return-1;
        Compute_string_md5((unsigned char*)buf,length,pack.md5);
        printf("%s\n", pack.md5);

        HexToStr((unsigned char*)tmp,(unsigned char*)buf,length);
        length*=2;

        sprintf(cmdline,"%s length:%ld md5:%s",value,length,pack.md5);

        if(sendPackage(fd,heard,id,cmd,cmdline)>=0){
        /*	if(receivePackage(fd,rx,2000)<0){
                printf("-----------receivePackage fail ack !!---------------\n");
                ret=-2;
            }
            else{
                resolvePacgage(&pack,rx);
                if(strcmp(pack.value,"ok")==0){
                    ret=sendDataPackage(fd,tmp,length);
                }
                else ret=-3;
            }*/
            ret=sendDataPackage(fd,tmp,length);
        }
        else ret=-4;
    }
    else{//normal cmd data
        sprintf(cmdline,"%s",value);
        if(sendPackage(fd,heard,id,cmd,cmdline)<0)
            ret=-4;
    }


    if(tmp!=NULL)
    {
        free(tmp);
        tmp = NULL;
    }
    return ret;
}

int init_Device()
{
    int fd,i,res;
    char dev[64];


#ifdef COM_DEV
        for(i=0;i<5;i++){
            memset(dev,0,sizeof(dev));
            sprintf(dev,"/dev/ttyACM%d",i);
            fd=initComm(dev,9600);
            if(fd>0) return fd;

            memset(dev,0,sizeof(dev));
            sprintf(dev,"/dev/ttyGS%d",i);
            fd=initComm(dev,115200);
            if(fd>0) return fd;

        }

#endif

    return -1;
}

int release_Device(int fd)
{
    close(fd);
    return 1;
}

int init_watchdog(int timeout)
{
    wd_fd = open("/dev/watchdog",O_RDWR);
    if(wd_fd < 0)
    {
        printf("wd open failed\n");
        return wd_fd;
    }

    ioctl(wd_fd, WDIOC_SETOPTIONS, WDIOS_ENABLECARD);
    ioctl(wd_fd, WDIOC_SETTIMEOUT, &timeout);
    return wd_fd;
}
int feed_watchdog()
{
    ioctl(wd_fd,WDIOC_KEEPALIVE,NULL);
}
int release_watchdog()
{
    close(wd_fd);
}





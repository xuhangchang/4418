#ifndef THREAD_H
#define THREAD_H

#include <QDebug>
#include <QThread>
//接收数据线程
class RecvPthread : public QThread
{
    Q_OBJECT

public:

    RecvPthread();
    ~RecvPthread();

    virtual void run();

};
//注册线程
class RegisterThread : public QThread
{
    Q_OBJECT

public:

    RegisterThread();
    ~RegisterThread();

    virtual void run();
    void register_exit();

    int WorkNum;
    QString Name;
    QString Department;
    QString Authority;
    int Psw;


private:

signals:
    //注册结束后，重启验证线程
    void compareRestart();
    //显示指静脉图片
    void picture_update(QString pic);
    //操作tips
    void operateTips(QString);
    //注册状态（成功与否）
    void outMsg_Status(QString);
};

//验证线程
class CompareThread: public QThread
{
    Q_OBJECT

public:

    int capture_flag;
    CompareThread();
    ~CompareThread();

    virtual void run();
    void compare_exit();

private:

signals:
//显示指静脉图片
    void picture_update(QString pic);
    void video_update(const QImage &img);
//操作提示
    void operateTips(QString);
//验证状态（成功与否）
    void outMsg_Status(QString);

//管理员进行管理员相关操作前,需进行管理员身份验证
//管理员验证成功
    void SuperIdentity(QString);
//当管理员身份验证失败后,主界面从管理员验证提示切换到普通用户验证操作提示
    void SuperIDerror();

};


#endif // THREAD_H


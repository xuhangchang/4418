#ifndef TG_MAIN_H
#define TG_MAIN_H

#define DEV_TYPE "****"

//#define WDT_DEV

#define IMAGE_SIZE 307200 	//480*640
#define CAMERA_WIDTH 640
#define CAMERA_HEIGHT 480
#define CAMERA_ROI_WIDTH	500
#define CAMERA_ROI_HEIGHT         220
#define CUT_ROW_START 100
#define CUT_COL_START 100
#define LIGHT_INIT 40
#define LIGHT_STEP 4
#define GRAY_LOW 100
#define GRAY_HIGH 125

#define FILE_RECV_PATH "/home/fa"
#define FILE_RECV_PATH_TF "/mnt/sd"

#define CON_PATH "/etc/config"

#define SN_PATH "/etc/tg/sn"
#define FW_PATH "/etc/tg/fw"
#define MODE_SETTING_PATH "/etc/tg/mode"

//总特征点大小（大概）
#define CHARACTER_SIZE  17328   // 17k   //5776*3
//一个特征点大小
#define ONECHARACTER_SIZE   5776
#define CAMERA_ROI_SIZE     110000 //220*500

/******************************************************************************
*以下为设备播放语音内容
******************************************************************************/
#define BI					0x00	//Bi
#define BIBI				0x01	//BiBi
#define REG_SUCCESS			0x02	//登记成功
#define REG_FAIL 			0x03	//登记失败
#define PLS_REPUT			0x04	//请再放一次
#define PLS_PUT_CRUCLY     	0x05	//请正确放入手指
#define PLS_PUT_SOFTLY		0x06	//请自然轻放手指
#define IDENT_SUCCESS		0x07	//验证成功
#define IDENT_FAIL			0x08	//验证失败
#define PLS_REDO			0x09	//请重试
#define DEL_SUCCESS			0x0A	//删除成功
#define DEL_FAIL			0x0B	//删除失败
#define VEIN_FULL			0x0C	//指静脉已满
#define VOLUME0				0xE0	//最小音量级别0
#define VOLUME1				0xE1	//中间音量级别1
#define VOLUME2				0xE2	//中间音量级别2
#define VOLUME3				0xE3	//中间音量级别3
#define VOLUME4				0xE4	//中间音量级别4
#define VOLUME5				0xE5	//中间音量级别5
#define VOLUME6				0xE6	//中间音量级别6
#define VOLUME7				0xE7	//最大音量级别7

#endif

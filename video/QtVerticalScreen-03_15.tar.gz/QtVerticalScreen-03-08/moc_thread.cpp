/****************************************************************************
** Meta object code from reading C++ file 'thread.h'
**
** Created by: The Qt Meta Object Compiler version 63 (Qt 4.8.7)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "thread.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'thread.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 63
#error "This file was generated using the moc from 4.8.7. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_RecvPthread[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

static const char qt_meta_stringdata_RecvPthread[] = {
    "RecvPthread\0"
};

void RecvPthread::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObjectExtraData RecvPthread::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject RecvPthread::staticMetaObject = {
    { &QThread::staticMetaObject, qt_meta_stringdata_RecvPthread,
      qt_meta_data_RecvPthread, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &RecvPthread::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *RecvPthread::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *RecvPthread::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_RecvPthread))
        return static_cast<void*>(const_cast< RecvPthread*>(this));
    return QThread::qt_metacast(_clname);
}

int RecvPthread::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QThread::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    return _id;
}
static const uint qt_meta_data_RegisterThread[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       4,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       4,       // signalCount

 // signals: signature, parameters, type, tag, flags
      16,   15,   15,   15, 0x05,
      37,   33,   15,   15, 0x05,
      61,   15,   15,   15, 0x05,
      82,   15,   15,   15, 0x05,

       0        // eod
};

static const char qt_meta_stringdata_RegisterThread[] = {
    "RegisterThread\0\0compareRestart()\0pic\0"
    "picture_update(QString)\0operateTips(QString)\0"
    "outMsg_Status(QString)\0"
};

void RegisterThread::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        RegisterThread *_t = static_cast<RegisterThread *>(_o);
        switch (_id) {
        case 0: _t->compareRestart(); break;
        case 1: _t->picture_update((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 2: _t->operateTips((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 3: _t->outMsg_Status((*reinterpret_cast< QString(*)>(_a[1]))); break;
        default: ;
        }
    }
}

const QMetaObjectExtraData RegisterThread::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject RegisterThread::staticMetaObject = {
    { &QThread::staticMetaObject, qt_meta_stringdata_RegisterThread,
      qt_meta_data_RegisterThread, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &RegisterThread::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *RegisterThread::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *RegisterThread::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_RegisterThread))
        return static_cast<void*>(const_cast< RegisterThread*>(this));
    return QThread::qt_metacast(_clname);
}

int RegisterThread::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QThread::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 4)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 4;
    }
    return _id;
}

// SIGNAL 0
void RegisterThread::compareRestart()
{
    QMetaObject::activate(this, &staticMetaObject, 0, 0);
}

// SIGNAL 1
void RegisterThread::picture_update(QString _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void RegisterThread::operateTips(QString _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void RegisterThread::outMsg_Status(QString _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}
static const uint qt_meta_data_CompareThread[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       6,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       6,       // signalCount

 // signals: signature, parameters, type, tag, flags
      19,   15,   14,   14, 0x05,
      47,   43,   14,   14, 0x05,
      68,   14,   14,   14, 0x05,
      89,   14,   14,   14, 0x05,
     112,   14,   14,   14, 0x05,
     135,   14,   14,   14, 0x05,

       0        // eod
};

static const char qt_meta_stringdata_CompareThread[] = {
    "CompareThread\0\0pic\0picture_update(QString)\0"
    "img\0video_update(QImage)\0operateTips(QString)\0"
    "outMsg_Status(QString)\0SuperIdentity(QString)\0"
    "SuperIDerror()\0"
};

void CompareThread::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        CompareThread *_t = static_cast<CompareThread *>(_o);
        switch (_id) {
        case 0: _t->picture_update((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 1: _t->video_update((*reinterpret_cast< const QImage(*)>(_a[1]))); break;
        case 2: _t->operateTips((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 3: _t->outMsg_Status((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 4: _t->SuperIdentity((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 5: _t->SuperIDerror(); break;
        default: ;
        }
    }
}

const QMetaObjectExtraData CompareThread::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject CompareThread::staticMetaObject = {
    { &QThread::staticMetaObject, qt_meta_stringdata_CompareThread,
      qt_meta_data_CompareThread, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &CompareThread::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *CompareThread::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *CompareThread::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_CompareThread))
        return static_cast<void*>(const_cast< CompareThread*>(this));
    return QThread::qt_metacast(_clname);
}

int CompareThread::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QThread::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 6)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 6;
    }
    return _id;
}

// SIGNAL 0
void CompareThread::picture_update(QString _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void CompareThread::video_update(const QImage & _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void CompareThread::operateTips(QString _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void CompareThread::outMsg_Status(QString _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}

// SIGNAL 4
void CompareThread::SuperIdentity(QString _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 4, _a);
}

// SIGNAL 5
void CompareThread::SuperIDerror()
{
    QMetaObject::activate(this, &staticMetaObject, 5, 0);
}
QT_END_MOC_NAMESPACE

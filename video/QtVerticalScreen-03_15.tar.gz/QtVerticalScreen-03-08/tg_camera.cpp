#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/mman.h>
#include <QImage>

#include "tg_camera.h"
#include "tg_main.h"
#include "gpio.h"
#include "rtx.h"

extern "C" {
#include <stdbool.h>
#include "./include/linux/v4l2-mediabus.h"
#include "./include/linux/videodev2.h"
#include "./include/linux/videodev2_nxp_media.h"
#include "./include/linux/nxp_ion.h"

#include "./include/ion.h"
#include "./include/nx_fourcc.h"
#include "./include/libnxjpeghw.h"
#include "./include/nxp-v4l2.h"
#include "./include/nx_video_api.h"
#include "./include/nx_align.h"
}

//#include <linux/videodev2.h>



#define ALIGN(x, a)		(((x) + (a) - 1) & ~((a) - 1))

#define dbg(level, fmt, arg...)		\
    do {							\
        if (debug >= (level))		\
            fprintf(stderr, "D/%.3d: " fmt, __LINE__, ## arg);	\
    } while (0)

#define err(fmt, arg...)			\
    fprintf(stderr, "E/%.3d: " fmt, __LINE__, ## arg)


//#define MAX_BUFFER_COUNT	4
#define MAX_BUFFER_COUNT	1
#define FMT_SENDOR			V4L2_MBUS_FMT_YUYV8_2X8
#define FMT_PREVIEW		V4L2_PIX_FMT_YUV422P

static int debug = 1;

#define __V4L2_S(cmd)		\
    do {					\
        int ret = cmd;		\
        if (ret < 0) {		\
            fprintf(stderr, "%.3d: `%s' = %d\n", __LINE__, #cmd, ret);	\
            return ret;		\
        }					\
    } while (0)

static int sensor_frmsize_list[][2] = {
    {  640,  480, },
    {  800,  600, },
    { 1280,  720, },
    { 1600, 1200, },
    { 2592, 1944, },
};

int width_c = 0, height_c = 0,ion_fd;
struct V4l2UsageScheme s;
struct nxp_vid_buffer bufs[MAX_BUFFER_COUNT];
struct nxp_vid_buffer *buf;


int tg_light;
int first_cut_row;
int first_cut_col;

static char hardware[32]="nanopi2";
static int cpu_is_s5p6818(void)
{
    return !strcmp(hardware, "nanopi3");
}



static inline int get_size(int format, int num, int width, int height)
{
    int size;

    width = ALIGN(width, 128);
    height = ALIGN(height, 128);

    switch (format) {
        case V4L2_PIX_FMT_YUYV:
            if (num > 0) return 0;
            size = (width * height) * 2;
            break;
        case V4L2_PIX_FMT_YUV420M:
        case V4L2_PIX_FMT_YUV422P:
            if (num == 0)
                size = width * height;
            else
                size = (width * height) >> 1;
            break;
        case V4L2_PIX_FMT_YUV444:
            size = width * height;
            break;
        default:
            size = width * height * 2;
            break;
    }

    return size;
}


int alloc_buffers(int ion_fd, int count, struct nxp_vid_buffer *bufs,
        int width, int height, int format)
{
    struct nxp_vid_buffer *vb;
    int plane_num;
    int i, j;
    int ret;

    if (format == V4L2_PIX_FMT_YUYV || format == V4L2_PIX_FMT_RGB565)
        plane_num = 1;
    else
        plane_num = 3;

    int size[plane_num];
    for (j = 0; j < plane_num; j++)
//        size[j] = get_size(format, j, width, height);
    {
        size[j] = get_size(format, j, width, height);
        printf("j = %d,size[j] = %d\n",j, size[j]);
    }

    dbg(3, "Alloc buffer: count(%d), plane(%d), format(%x)\n", count, plane_num, format);
    for (i = 0; i < count; i++) {
        vb = &bufs[i];
        vb->plane_num = plane_num;
        dbg(3, "[Buffer %d] --->\n", i);
        for (j = 0; j < plane_num; j++) {
            ret = ion_alloc_fd(ion_fd, size[j], 0,
                    ION_HEAP_NXP_CONTIG_MASK, 0, &vb->fds[j]);
            if (ret < 0) {
                err("failed to ion alloc %d\n", size[j]);
                return ret;
            }
            vb->virt[j] = (char *)mmap(NULL, size[j],
                    PROT_READ | PROT_WRITE, MAP_SHARED, vb->fds[j], 0);
            if (!vb->virt[j]) {
                err("failed to mmap\n");
                return -1;
            }
            ret = ion_get_phys(ion_fd, vb->fds[j], &vb->phys[j]);
            if (ret < 0) {
                err("failed to get phys\n");
                return ret;
            }
            vb->sizes[j] = size[j];
            dbg(3, "\tplane %d: fd(%d), size(%d), phys(0x%lx), virt(%p)\n",
                    j, vb->fds[j], vb->sizes[j], vb->phys[j], vb->virt[j]);
        }
    }

    return 0;
}



/*
 * Note:
 *  - S5P4418: clipper0 + YUV422P, or decimator0 + YUV420M
 *  - S5P6818: clipper0 + YUV420M
 */
static int init_capture(int width, int height)
{
    int format = V4L2_PIX_FMT_YUV422P;
    if (cpu_is_s5p6818())
        format = V4L2_PIX_FMT_YUV420M;

    __V4L2_S(v4l2_set_format(nxp_v4l2_clipper0, width, height, format));
    __V4L2_S(v4l2_set_crop(nxp_v4l2_clipper0, 0, 0, width, height));

    // Set to default format (800x600) at first
//	if (width != 800)
//		__V4L2_S(v4l2_set_format(nxp_v4l2_sensor0, 800, 600, FMT_SENDOR));
    __V4L2_S(v4l2_set_format(nxp_v4l2_sensor0, width, height, FMT_SENDOR));

    __V4L2_S(v4l2_reqbuf(nxp_v4l2_clipper0, MAX_BUFFER_COUNT));
    return 0;
}

int do_capture(struct nxp_vid_buffer *bufs, int width, int height,
        int skip_frames, char *jpeg_file)
{
    struct nxp_vid_buffer *buf;
    int i;

    dbg(1, "capture image %dx%d --> %s\n", width, height, jpeg_file);

    for (i = 0; i < MAX_BUFFER_COUNT; i++) {
        buf = &bufs[i];
        dbg(3, "queue buffer %d\n", i);
        v4l2_qbuf(nxp_v4l2_clipper0, buf->plane_num, i, buf, -1, NULL);
    }

    __V4L2_S(v4l2_streamon(nxp_v4l2_clipper0));

    int index = 0;
    for (i = 0; i < skip_frames; i++) {
        v4l2_dqbuf(nxp_v4l2_clipper0, buf->plane_num, &index, NULL);
        buf = &bufs[index];
        v4l2_qbuf(nxp_v4l2_clipper0, buf->plane_num, index, buf, -1, NULL);
        dbg(2, "skip buffer %d (%p)\n", index, buf);
    }

    __V4L2_S(v4l2_streamoff(nxp_v4l2_clipper0));
    return 0;
    //return save_handle_to_jpeg1(buf, jpeg_file, width, height);
}

static void get_capture_size(int n, int *width, int *height)
{
    *width = sensor_frmsize_list[n][0];
    *height = sensor_frmsize_list[n][1];
}


int cam_open()
{
    int ret=0,i;
    get_capture_size(0, &width_c, &height_c);

    ion_fd = ion_open();
    if (ion_fd < 0)
    {
        err("failed to ion_open, errno = %d\n", errno);
        return -EINVAL;
    }

    memset(&s, 0, sizeof(s));
    s.useDecimator0 = true;
    s.useClipper0 = true;
    s.useMlc0Video = true;

    ret = v4l2_init(&s);
    if ( ret < 0)
    {
        err("initialize V4L2 failed, %d\n", ret);
        close(ion_fd);
        return ret;
    }

    ret = alloc_buffers(ion_fd, MAX_BUFFER_COUNT, bufs,
            width_c ,height_c , FMT_PREVIEW);
    if (ret < 0)
    {
        v4l2_exit();
        close(ion_fd);
        err("alloc_buffers failed, %d\n", ret);
        return -1;
    }

    if (init_capture(width_c, height_c))
    {
        err("init_capture failed\n");
        return -2;
    }

    for (i = 0; i < MAX_BUFFER_COUNT; i++)
    {
        buf = &bufs[i];
        dbg(3, "queue buffer %d\n", i);
        v4l2_qbuf(nxp_v4l2_clipper0, buf->plane_num, i, buf, -1, NULL);
    }
    __V4L2_S(v4l2_streamon(nxp_v4l2_clipper0));

    return ret;

}


int cam_close()
{
    __V4L2_S(v4l2_streamoff(nxp_v4l2_clipper0));
    v4l2_exit();
    close(ion_fd);
}
int cam_select(int index)
{
    return index;
}
int cam_init()
{
    cam_open();
    cam_select(0);

    return 0;
}
int cam_get_image(u8* out_buffer, int out_buffer_size)
{
    int index=0;

    v4l2_dqbuf(nxp_v4l2_clipper0, buf->plane_num, &index, NULL);
    buf = &bufs[index];
    v4l2_qbuf(nxp_v4l2_clipper0, buf->plane_num, index, buf, -1, NULL);

    dbg(2, "num buffer %d (%p) %d %x\n", index, buf,buf->sizes[0],buf->phys[0]);

    memcpy(out_buffer,buf->virt[0],out_buffer_size);


}
int cam_get_frame(unsigned char *data,int flag)
{


    int ret,j,k,i=0,index=0;
    long light=0;

    int row_start = first_cut_row;
    int col_start = first_cut_col;

    int row_size = CAMERA_ROI_HEIGHT;
    int col_size = CAMERA_ROI_WIDTH;

    v4l2_dqbuf(nxp_v4l2_clipper0, buf->plane_num, &index, NULL);
    buf = &bufs[index];
    v4l2_qbuf(nxp_v4l2_clipper0, buf->plane_num, index, buf, -1, NULL);

    dbg(2, "num buffer %d (%p) %d %x\n", index, buf,buf->sizes[0],buf->phys[0]);
    //TG_SaveBmp(buf->virt[0],CAMERA_HEIGHT,CAMERA_WIDTH,"tt.bmp");
    TGSaveImage("tt.bmp",(unsigned char *)buf->virt[0],CAMERA_WIDTH,CAMERA_HEIGHT)  ;
/*
    unsigned char rgb[640*480*3];
    yuvtorgbO((unsigned char **)buf->virt,rgb,640,480);//yuyv杞崲鎴怰GB
    QImage img = QImage(rgb,640,480,QImage::Format_RGB888);
    emit image_data(img);
*/
    write_data_hex((unsigned char *)buf->virt[0],CAMERA_WIDTH*CAMERA_HEIGHT,"./Y.dat");
    write_data_hex((unsigned char *)buf->virt[1],CAMERA_WIDTH*CAMERA_HEIGHT/2,"./U.dat");
    write_data_hex((unsigned char *)buf->virt[2],CAMERA_WIDTH*CAMERA_HEIGHT/2,"./V.dat");


    return light;

}

void  YUV2Y(unsigned char * yuyv,int w,int h,unsigned char *y)
{
    int i, j,pos,z=0;
    for(i=0;i< h;i++) {
        for (j = 0; j < w; j++) {
    /*	        if(!z)
                    *(y++) = yuyv[0];
                else
                    *(y++) = yuyv[2];

                if(z++) {
                    z = 0;
                    yuyv += 4;
                }
*/
            *(y++)=yuyv[2];yuyv+=2;

        }
    }
}


/*******************************************
*   creator    : @fengge
*   function   : 抓取图像函数
*   parameter  :
*   Date       :2017/09/07
********************************************/
void tg_image_grab(int fd,unsigned char *data)
{
    int i;
    int gray;

 //   pwm_send(fd,0,60);
    gray = cam_get_frame(data,0);//skip
    gray = cam_get_frame(data,0);//skip
    gray = cam_get_frame(data,0);//skip
    gray =cam_get_frame(data,1);
}
/*******************************************
*   creator    : @xu
*   function   : 获取图像
*               将检测touch信号,和采集图像封装在该函数
*   parameter  :
*   Date       :2017/09/07
********************************************/

int Get_Image(int fd_gpio,unsigned char * Image_Buf)
{

//抓取图像数据
     tg_image_grab(fd_gpio,Image_Buf);
     TGSaveImage("camera.bmp",Image_Buf,CAMERA_ROI_WIDTH,CAMERA_ROI_HEIGHT);
     return 0;

}


int video_frame(unsigned char *data,int flag)
{
    int ret,j,k,i=0,index=0;

    v4l2_dqbuf(nxp_v4l2_clipper0, buf->plane_num, &index, NULL);
    buf = &bufs[index];
    v4l2_qbuf(nxp_v4l2_clipper0, buf->plane_num, index, buf, -1, NULL);

    dbg(2, "num buffer %d (%p) %d %x\n", index, buf,buf->sizes[0],buf->phys[0]);
    //TG_SaveBmp(buf->virt[0],CAMERA_HEIGHT,CAMERA_WIDTH,"tt.bmp");
    yuvtorgbO((unsigned char **)buf->virt,data,640,480);//yuyv杞崲鎴怰GB
    return 0;
}


int yuvtorgbO(unsigned char **yuv422, unsigned char *rgb, unsigned int width,unsigned int height)
{
//     unsigned char *yuv = (unsigned char *)(framebuf[buf.index].start);
     unsigned char *src_y = *(yuv422 + 0);
     unsigned char *src_u = *(yuv422 + 1);
     unsigned char *src_v = *(yuv422 + 2);
     unsigned int in, out;
     int y0, u, y1, v;
     unsigned int pixel24;
     unsigned char *pixel = (unsigned char *)&pixel24;
     unsigned int size = width*height;

     for(in = 0, out = 0; in < size; in ++, out += 6)
     {
//         printf("in = %d\n",in);
          y0 = src_y[in*2+0];
          u  = src_u[in];
          y1 = src_y[in*2+1];
          v  = src_v[in];

  //        sign3 = true;
          pixel24 = yuvtorgb(y0, u, v,1);
          rgb[out+0] = pixel[0];    //for QT
          rgb[out+1] = pixel[1];
          rgb[out+2] = pixel[2];
          //rgb[out+0] = pixel[2];  //for iplimage
          //rgb[out+1] = pixel[1];
          //rgb[out+2] = pixel[0];

          //sign3 = true;
          pixel24 = yuvtorgb(y1, u, v,0);
          rgb[out+3] = pixel[0];
          rgb[out+4] = pixel[1];
          rgb[out+5] = pixel[2];
          //rgb[out+3] = pixel[2];
          //rgb[out+4] = pixel[1];
          //rgb[out+5] = pixel[0];
     }
     return 0;
}

int yuvtorgb(int y, int u, int v,int flag)
{
     unsigned int pixel24 = 0;
     unsigned char *pixel = (unsigned char *)&pixel24;
     int r, g, b;
     static long int ruv, guv, buv;

     if(flag)
     {
  //       sign3 = false;
         ruv = 1159*(v-128);
         guv = 380*(u-128) + 813*(v-128);
         buv = 2018*(u-128);
     }

     r = (1164*(y-16) + ruv) / 1000;
     g = (1164*(y-16) - guv) / 1000;
     b = (1164*(y-16) + buv) / 1000;

     if(r > 255) r = 255;
     if(g > 255) g = 255;
     if(b > 255) b = 255;
     if(r < 0) r = 0;
     if(g < 0) g = 0;
     if(b < 0) b = 0;

     pixel[0] = r;
     pixel[1] = g;
     pixel[2] = b;

     return pixel24;
}



﻿#include <QDebug>

//#include "Database.h"
#include "widget.h"
#include "General.h"
#include "thread.h"
#include "gpio.h"
#include "tg_camera.h"
#include "tg_main.h"
#include "rtx.h"


extern "C" {
#include "./inc/TGFingerVeinApi.h"
}

/*******************************************
                全局变量定义
********************************************/
//VeinDB Veindb;         //定义一个数据库对象
int fd_gpio;
int camera_flag = 0;   //1: ready to capture camera data ;  0: none
int exit_flag = 0;     //1:跳出检查touch循环　　　　　　　　　　　0:与检查touch并行控制图像数据采集
int Root_flag = 0;     //管理员操作时标志位
unsigned char camera_data[CAMERA_WIDTH*CAMERA_HEIGHT] = {0};//capture camera data//640*480
int fd;
QMutex mutex_pack;     //互斥锁

int touch_check = 0;
int beat_check = 0;
unsigned char mode_flag='1';
char save_addr[128];

/*******************************************

 * creator      : @xu
 * function     : 接收线程(进行Pc与Device之间的通信)
 * Date         : 2017-09-06
 * parameter    : 无
********************************************/
RecvPthread::RecvPthread()
{
    printf("******************new RecvPthread******************\n");
    fd_gpio = open("/dev/gpio_ctl",O_RDWR);
    if(fd_gpio < 0)
    {
       printf("can't open gpio\n");
    }

    //摄像头初始化
    cam_init();
}

RecvPthread::~RecvPthread()
{

}

void RecvPthread::run()
{
    printf("******************this is the RecvPthread******************\n");
    fd_gpio = open("/dev/gpio_ctl",O_RDWR);

    if(fd_gpio < 0)
    {
       printf("can't open gpio\n");
    }
    pwm_send(fd_gpio,0,100);
}

/*******************************************
 * creator      : @xu
 * function     : 注册线程
 * Date         : 2017-06-12
 * parameter    : 无
********************************************/
RegisterThread::RegisterThread()
{

}

/*******************************************
 * creator      : @xu
 * function     : 注册析构函数
 * Date         : 2017-06-12
 * parameter    : 无
********************************************/
RegisterThread::~RegisterThread()
{

}
/*******************************************
 * creator      : @xu
 * function     : 结束注册线程
 * Date         : 2017/09/07
 * parameter    : 无
********************************************/
void RegisterThread::register_exit()
{
    exit_flag = 1;
}

/*******************************************
*   creator    : @xu
*   function   : 注册线程
*   parameter  :
*   Date       :2017/09/13
********************************************/
void RegisterThread::run()
{
    int loc;
    int m = 0;
    int i,j,ret;
    int usr_num = 0;
    QString UserID;
    int userName = 0,sizeFeature3 = 0;
    QByteArray byte;
    //指静脉（同一个手指三次特征点总大小）
    sizeFeature3 = CHARACTER_SIZE;  // 3*OneCharacter

    unsigned char ** pic_data;
    unsigned char ** feature;

    unsigned char * registerData = NULL;
    unsigned char * Image_data= NULL;
    unsigned char * tempRegisterData;
    unsigned char * tempUpdateData;

    pic_data = bmp_Make2DArray_uint8(3,CAMERA_ROI_HEIGHT*CAMERA_ROI_WIDTH); //src camera data
    feature = bmp_Make2DArray_uint8(3, ONECHARACTER_SIZE*3);
    Image_data = (unsigned char*)malloc(CAMERA_ROI_HEIGHT*CAMERA_ROI_WIDTH*sizeof(unsigned char));
    tempRegisterData = (unsigned char *)malloc(sizeFeature3 * sizeof(unsigned char));
    tempUpdateData = (unsigned char *)malloc(sizeFeature3 * sizeof(unsigned char));
    //开启采集图像标志位
    exit_flag = 0;

    //获取已经注册的用户个数
//    Veindb.get_usersNum(&usr_num);
    printf("数据库已经注册成功的用户数usr_num = %d\n",usr_num);
//    registerData = (unsigned char *)malloc(sizeFeature3*usr_num * sizeof(unsigned char));
    //得到数据库中所有用户的（指静脉）数据
//    Veindb.getAllData(registerData);

    printf("---------------Begin To Register---------------\n");
    printf("---------------开　　始　　注　　册---------------\n");
//    userName = usr_num;

    //调节语音音量
    sound_send(fd_gpio,VOLUME5);
    for(i=0,j=0;i<6;i++)
    {
        if (0 == i)
        {
            printf("**************Please Put Your Finger Lightly (First)**************\n");
            printf("**************请自然轻放手指**************\n");
            sound_send(fd_gpio,PLS_PUT_SOFTLY);
            emit operateTips(QString::fromUtf8("请自然轻放手指"));
        }
        //获取图像
        ret = Get_Image(fd_gpio,Image_data);
        printf("**************Register*****Get_Image:ret= %d\n",ret);
        if(0 == ret)    //成功获取到图像
        {
//           printf("***************** j == %d\n",j);
           memcpy(*(pic_data+j),Image_data,CAMERA_ROI_SIZE*sizeof(char));
          // TG_SaveBmp(Image_data,CAMERA_ROI_HEIGHT,CAMERA_ROI_WIDTH,"register.bmp");
           TGSaveImage("register.bmp",Image_data,CAMERA_ROI_WIDTH,CAMERA_ROI_HEIGHT);
           emit picture_update("register.bmp");
//           printf("RRRRRRRRRRRRRRRRRRRRRRRRRRR\n");
           //提取特征点
           ret = TGImgExtractFeature(*(pic_data+j),CAMERA_ROI_WIDTH,CAMERA_ROI_HEIGHT,*(feature+j));
           printf("**************注册中产生特征点ret1 === %d\n",ret);
           if((0 != ret)&&(i < 5)) //提取特征点失败
           {
              m++;                 //m: 失败次数
              printf("***************** m == %d\n",m);
              if(m > 3)
              {
//                 printf("登记失败\n");
                 printf("**************Register Failed**************\n");
                 sound_send(fd_gpio,REG_FAIL);
                 emit outMsg_Status(QString::fromUtf8("注册失败"));
                 break;
              }
              else
              {                
                 printf("**************Please put your finger Correctly!**************\n");
                 printf("**************请正确放入手指**************\n");
                 sound_send(fd_gpio,PLS_PUT_CRUCLY);
                 emit operateTips(QString::fromUtf8("请正确放入手指"));
              }
           }
           else                 //成功提取特征点
           {
              j++;
              printf("***************** j == %d\n",j);
              if((j < 3) && (i < 5))
              {
                 printf("**************Please Put Your Finger Again**************\n");
                 printf("**************请再放一次手指**************\n");
                 sound_send(fd_gpio,PLS_REPUT);
                 emit operateTips(QString::fromUtf8("请再放一次手指"));
              }
              else
              {
              //特征点融合：三个特征点融合为特征点
//                 if ((3 == j) && (0 == TGFusionFeature(*(feature), *(feature + 1), *(feature + 2), tempRegisterData)))
                 ret = TGFusionFeature(*(feature), *(feature + 1), *(feature + 2), tempRegisterData);
                 printf("*********Character Fuse ret === %d\n",ret);
                 if((3 == j) && (0 == ret))
                 {
                     ;
                }
                 else
                 {
                     printf("**************Register Failed!**************\n");
                     printf("**************注册失败**************\n");
                     sound_send(fd_gpio,REG_FAIL);
                     emit outMsg_Status(QString::fromUtf8("注册失败"));
                 }
                 break;
              }
           }
        }
        if(-1 == ret) //exit_flag = 1,跳出注册循环
        {
           printf("**************Register*****Get_Image: ret:-1,exit_flag:%d\n",exit_flag);
           goto fail;
        }
        printf("**************This Is Register %d**************\n",i);
    }

fail:
    bmp_Free2DArray_uint8(pic_data,3);
    bmp_Free2DArray_uint8(feature,3);

//    free(registerData);
//    registerData = NULL;
    free(Image_data);
    Image_data = NULL;
    free(tempRegisterData);
    tempRegisterData = NULL;
    free(tempUpdateData);
    tempUpdateData = NULL;

 //   printf("*****Going to CompareRestart*****\n");
//重启比对线程
    emit compareRestart();
}

/*******************************************
 * creator      : @xu
 * function     : 验证线程
 * Date         : 2017-06-12
 * parameter    : 无
********************************************/
CompareThread::CompareThread()
{
    capture_flag = 0;
}
/*******************************************
 * creator      : @xu
 * function     : 验证析构函数
 * Date         : 2017-07-03
 * parameter    : 无
********************************************/
CompareThread::~CompareThread()
{

}
/*******************************************
 * creator      : @xu
 * function     : 结束验证线程
 * Date         : 2017/09/07
 * parameter    : 无
********************************************/
void CompareThread::compare_exit()
{
    exit_flag = 1;
}
/*******************************************
*   creator    : @xu
*   function   : 验证线程
*   parameter  :
*   Date       :2017/09/07
********************************************/
void CompareThread::run()
{
    int ret;
    int ret1,ret2;
    int loc;
    int usr_num = 0;
    int  sizeFeature3 = CHARACTER_SIZE; // 3*OneCharacter

    unsigned char * pic_data;
    unsigned char * feature;
    unsigned char * tempUpdateData;
    unsigned char * registerData;
    unsigned char rgb[640*480*2*3];

    //开启采集图像的标志位
    exit_flag = 0;

    pic_data = (unsigned char*)malloc((CAMERA_ROI_WIDTH*CAMERA_ROI_HEIGHT*3)*sizeof(unsigned char));
    feature = (unsigned char*)malloc((CAMERA_ROI_WIDTH*CAMERA_ROI_HEIGHT)*sizeof(unsigned char));
    tempUpdateData = (unsigned char *)malloc(sizeFeature3*sizeof(unsigned char));

    printf("---------------Begin To Verify---------------\n");
    printf("---------------开　始　　验　　证---------------\n");
    while(1)
    {

  //      memset(rgb,0,sizeof(rgb));
  //         cam_get_frame(pic_data,1);
        video_frame(rgb,1);

        QImage img = QImage(rgb,640,480,QImage::Format_RGB888);
        if(capture_flag)
         {
 //           if(img.save("my_capture.jpg","JPEG")){
            if(img.save("my_capture.png")){
                qDebug("camera capture.save OK!");
                 }else{
                qDebug("camera capture.save error!");
         }

            capture_flag = 0;

         }

        emit video_update(img);
     //   emit video_update("tt.bmp");

//    sleep(1);
    }

end:
    free(pic_data);
    pic_data = NULL;
    free(feature);
    feature = NULL;
    free(tempUpdateData);
    tempUpdateData = NULL;
//    free(registerData);
//    registerData = NULL;
    printf("*****************Verify Pthread END!*****************\n");
}

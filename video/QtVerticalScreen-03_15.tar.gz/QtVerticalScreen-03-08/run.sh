#!/bin/bash

# for LCD st7735s 
# modprobe fbtft_device name=matrix-st7735s gpios=dc:17,reset:3,cs:201
# export QWS_DISPLAY=Transformed:Rot90:Linuxfb:/dev/fb-st7735s:enable=1:mWidth90:mmHeight45:0

# for LCD st7789s
# modprobe fbtft_device name=matrix-st7789s gpios=dc:1,reset:203,cs:67
# export QWS_DISPLAY=Transformed:Rot90:Linuxfb:/dev/fb-st7789s:enable=1:mWidth120:mmHeight92:0

# export LD_LIBRARY_PATH=/usr/local/lib:$LD_LIBRARY_PATH
# export PATH=/bin:/sbin:/usr/bin/:/usr/sbin:/usr/local/bin
# export QWS_MOUSE_PROTO="MouseMan:/dev/input/mice"
# export QWS_KEYBOARD=TTY:/dev/tty1

#killall QtE-Demo

. /usr/bin/setqt4env

# QWS_DISPLAY_SIZE=mmWidth200:mmHeight125:
export QWS_DISPLAY=Transformed:Rot90:Linuxfb:/dev/fb0:${QWS_DISPLAY_SIZE}0

/home/fa/TGWallHangDEV -qws 
#cd /opt/QtE-Demo
#
#./QtE-Demo -qws
